
<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) 
		{
			
			case 'lmobt':
				include "halaman1/obat.php";
				break;
			case 'obtout':
				include "halaman1/obatkeluar.php";
				break;
			case 'add':
				include "halaman1/addobat.php";
				break;
			case 'pr':
				include "halaman1/proseslaporan.php";
				break;
			
			
				
				
			default:
				echo "<center>
				<div>
				<img src='images/maintenance.jpg'>
				</div>
				</center>";
				break;
		}

		}else{
			include "manageapt.php";
		}
?>