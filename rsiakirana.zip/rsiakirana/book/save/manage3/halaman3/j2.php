<?php
include "conkeu.php";
?>

<br>
<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->

	  					<form id="form" role="form" method="post" action="">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>Input Pengeluaran</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s">
													   <div class="col-md-6 col-sm-6">
															<label for="nomor_kredit">Nomor Jurnal</label>
															<input type="text" class="form-control" name="nomor_kredit" placeholder="...." required>
													   </div>
													  
													  
													  <div class="col-md-6 col-sm-6">
															<label for="jenis_kredit">Keterangan</label>
															<input type="text" class="form-control" name="jenis_kredit" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="jumlah_kredit">Jumlah(Rp)</label>

															<input type="text" class="form-control" name="jumlah_kredit" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="kode_kredit">Nomor Transaksi</label>
															<input type="text" class="form-control" name="kode_kredit" placeholder="...." required>
													   </div>
													   <br>
													   <div class="col-md-6 col-sm-6">
															<label for="tanggal_kredit">Tanggal Masuk</label>
															<input type="date" class="form-control" name="tanggal_kredit" placeholder="...." required>
														</div>
								  						<br>
														<div class="col-md-6">
														  <div >
															<label class="input-group-text" for="bulan">Bulan</label>
														  </div>
														  <select class="custom-select" id="bulan" name="bulan" required>
															<option value=>....pilih....</option>
															<option value="Januari">Januari</option>
															<option value="Februari">Februari</option>
															<option value="Maret">Maret</option>
															<option value="April">April</option>
															<option value="Mei">Mei</option>
															<option value="Juni">Juni</option>
															<option value="Juli">Juli</option>
															<option value="Agustus">Agustus</option>
															<option value="September">September</option>
															<option value="Oktober">Oktober</option>
															<option value="November">November</option>
															<option value="Desember">Desember</option>
														  </select>
														</div>
													   <div class="col-md-12 col-sm-12">
															<br>
															<button  class="col-md-2" type="submit" class="form-control" name="tambah">Input</button>
														   <br>
													   </div>
								  
	  
	  
  							</form>
						</div>
	
	  
	  					<!-- validasi yang belum ditampilkan-->
													<?php 
													//if(isset($_GET['nomor_jurnal'])){
													//	if($_GET['nomor_jurnal'] == ""){
													//		echo "<h4 style='color:red'>Nomor Jurnal Belum Di Masukkan !</h4>";
													//	}
													//}
													?>
		   
			 
							<!-- php input -->

							<?php
								include_once "conkeu.php";
							  // Check If form submitted, insert form data into users table.
							  if(isset($_POST['tambah'])) {
								$nomor_kredit = $_POST['nomor_kredit'];
								$jenis_kredit = $_POST['jenis_kredit'];
								$jumlah_kredit = $_POST['jumlah_kredit'];
								$kode_kredit = $_POST['kode_kredit'];
								$tanggal_kredit = $_POST['tanggal_kredit'];
								$bulan = $_POST['bulan'];
								  
								//koneksi.phpr data into table
								$query="INSERT INTO jurnal_keluar SET nomor_kredit='$nomor_kredit', jenis_kredit='$jenis_kredit', jumlah_kredit='$jumlah_kredit', kode_kredit='$kode_kredit', tanggal_kredit='$tanggal_kredit', bulan='$bulan'";
								  mysqli_query($koneksi, $query); 

								  
								  echo "<script>alert('Input Berhasil Rp. :$jumlah_kredit');window.location=''</script>";
								}
							?>
</div>
</div>
</div>
<br>
<br>
<br>
<br>
<br>

    