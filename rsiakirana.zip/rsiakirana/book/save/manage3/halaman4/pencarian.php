<?php 
include "koneksi.php";
?>

<?php
	include('bar128.php');
	echo '<div style="border:3px double #ababab; padding:10px;margin:10px auto;width:400px; background-color: salmon">';
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien where no_rekamedis='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<table border="0" cellpadding="4" cellspacing="3" align="center" width="100%">
<tr>
<td colspan="3" align="center">
<b>Nomor:&nbsp;<?php echo $data['no_rekamedis']; ?></b>
<hr>
</td>
</tr>
<tr>
<td>Nama Pasien</td>
<td>:<?php echo $data['nama_pasien']; ?></td>
</tr>
<tr>
<td>Golongan Darah</td>
<td>:<?php echo $data['golongan_darah']; ?></td>
</tr>
<tr>
<tr>
<td>Jenis Kelamin</td>
<td>:<?php echo $data['jenis_kelamin']; ?></td>
</tr>
<tr>
<td>GR Barcode </td><td><?php echo bar128(stripslashes($_GET['kode'])); ?></td>
</tr>
</table>

<?php } ?>

<?php

echo '</div>';
?>

<center><button><a href="/rsudprovsulut/aksesadmin/manage3/adminrmedis.php">Selesai</a></button></center>
<center><button><a href="/rsudprovsulut/aksesadmin/manage3/halaman4/printbarcode.php">Print</a></button></center>					


