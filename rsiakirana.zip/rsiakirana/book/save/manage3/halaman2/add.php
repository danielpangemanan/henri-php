<?php
include "koneksi.php";
?>

<br>
<div class="container">
<div class="row">
<div class="col-md- col-sm-12">
			 
<form id="form" role="form" method="post" action="" enctype="multipart/form-data">
  <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
       <h2>Input Sumberdaya Manusia</h2>
  </div>

  
   <div class="col-md-10 col-sm-12">
    <label for="nis">NIP</label>
      <input type="text" class="form-control" name="nis" placeholder="...." required>
   </div>

   <div class="col-md-10 col-sm-12">
    <label for="nama">Nama</label>
      <input type="text" class="form-control" name="nama" placeholder="...." required>
   </div>


   <div class="col-md-10 col-sm-12">
    <label for="pendidikan">Pendidikan</label>
      <select class="form-control" name="pendidikan" required>
        <option value='0'>--pilih--</option>
          <?php
         //Membuat koneksi ke database
         $koneksi = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
         if (!$koneksi){
            die("Koneksi database gagal:" .mysqli_connect_error());
         }
        
         //Perintah sql untuk menampilkan semua data pada tabel 
          $sql="select * from ket2";

          $hasil=mysqli_query($koneksi,$sql);
          $no=0;
          while ($data = mysqli_fetch_array($hasil)) {
          $no++;
         ?>
          <option value="<?php echo $data['pendidikan'];?>"><?php echo $data['pendidikan'];?></option>
        <?php 
        }
        ?>
    </select>
   </div>


   <div class="col-md-10 col-sm-12">
    <label for="kompetensi">Kompetensi</label>
      <select class="form-control" name="kompetensi" required>
        <option value='0'>--pilih--</option>
          <?php
         //Membuat koneksi ke database
         $koneksi = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
         if (!$koneksi){
            die("Koneksi database gagal:" .mysqli_connect_error());
         }
        
         //Perintah sql untuk menampilkan semua data pada tabel 
          $sql="select * from ket1";

          $hasil=mysqli_query($koneksi,$sql);
          $no=0;
          while ($data = mysqli_fetch_array($hasil)) {
          $no++;
         ?>
          <option value="<?php echo $data['kompetensi'];?>"><?php echo $data['kompetensi'];?></option>
        <?php 
        }
        ?>
    </select>
   </div>

   <div class="col-md-10 col-sm-12">
    <label for="masa_kerja">Masa Kerja</label>
      <input type="text" class="form-control" name="masa_kerja" placeholder="...." required>
   </div>

   
   <div class="col-md-10 col-sm-12">
    <label for="diklat">Diklat</label>
      <select class="form-control" name="diklat" required>
        <option value='0'>--pilih--</option>
          <?php
         //Membuat koneksi ke database
         $koneksi = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
         if (!$koneksi){
            die("Koneksi database gagal:" .mysqli_connect_error());
         }
        
         //Perintah sql untuk menampilkan semua data pada tabel 
          $sql="select * from ket5";

          $hasil=mysqli_query($koneksi,$sql);
          $no=0;
          while ($data = mysqli_fetch_array($hasil)) {
          $no++;
         ?>
          <option value="<?php echo $data['diklat'];?>"><?php echo $data['diklat'];?></option>
        <?php 
        }
        ?>
    </select>
   </div>

   <div class="col-md-10 col-sm-12">
    <label for="status">Status</label>
    <select class="form-control" name="status" required>
      <option value="">.....</option>
      <option value="ASN">ASN</option>
      <option value="THL">THL</option>
    </select>
  </div>

  <div class="col-md-10 col-sm-12">
    <label for="alamat">Alamat</label>
      <input type="text" class="form-control" name="alamat" placeholder="...." required>
   </div>

   <div class="col-md-10 col-sm-12">
    <label for="wnegara">Kewarganegaraan</label>
    <select class="form-control" name="wnegara" required>
      <option value="">.....</option>
      <option value="Warga Negara Indonesia (WNI)">Warga Negara Indonesia (WNI)</option>
      <option value="Warga Negara Asing (WNA)">Warga Negara Asing (WNA)</option>
    </select>
  </div>


  <div class="col-md-10 col-sm-12">
    <label for="gambar">Gambar</label>
      <input type="file" class="form-control" name="gambar">
   </div>
   <br>
   <br>

   <div class="col-md-10 col-sm-12">
    <button type="submit" class="btn btn-primary" name="tambah">Input</button>
    <button type="reset" class="btn btn-danger">Batal</button>
  </div>

</form>


	
</div>
</div>
</div>
<br>





<?php
include "koneksi.php";
if(isset($_POST['tambah'])) {
$nis = $_POST['nis'];
$nama = $_POST['nama'];
$pendidikan = $_POST['pendidikan'];
$kompetensi = $_POST['kompetensi'];
$masa_kerja = $_POST['masa_kerja'];
$diklat = $_POST['diklat'];
$status = $_POST['status'];
$alamat = $_POST['alamat'];
$wnegara = $_POST['wnegara'];
$gambar = $_FILES['gambar']['name'];

$query="INSERT INTO stafsdm SET nis='$nis', nama='$nama',pendidikan='$pendidikan',kompetensi='$kompetensi',masa_kerja='$masa_kerja',diklat='$diklat',status='$status',alamat='$alamat',wnegara='$wnegara',gambar='$gambar' "; 
mysqli_query($koneksi, $query); 

move_uploaded_file($_FILES['gambar']['tmp_name'], 'filegambar/'.$gambar);
	
echo "<script>alert('Data dengan Nis: $nis berhasil di Masukkan');</script>";
}
?> 

