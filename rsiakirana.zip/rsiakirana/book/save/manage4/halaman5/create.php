<?php
	require './koneksi.php';
	
	
	function hai(){
		echo "Folder berhasil di buat";
	}
 
	mkdir('tes buat file',hai());
	
?>