<?php 
include "koneksi.php";
?>

<div class="main-grid">
		<div class="agile-grids">	
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th>DATA PASIEN</th>
				 <th>Nomor R.Medis</th>
				 <th>NIK</th>
				 <th>Nama Pasien</th>
				 <th>Jenis Kelamin</th>
				 <th>G. Darah</th>
				 <th>Tempat/ Tanggal Lahir</th>
				 <th>Nama Ibu</th>	
				 <th>Alamat</th>	
				 <th>Agama</th>	
				 <th>Dokter</th>
				 <th>Tujuan</th>
				 <th>Pembiayaan</th>
				</tr>
					
				<?php
				
				$sql = $koneksi->query("select *from tbl_pasien1 order by no_rekamedis desc");
				while ($data=$sql->fetch_assoc())
				{
				?>											
					
				<tr>
				 <td><a href="/rsudprovsulut/aksesadmin/manage1/adminrmedis.php?page=idpsn&kode=<?php echo $data['no_rekamedis'];?>" class="label label-info">Akses Tindakan</a><br>
				 	<a href="/rsudprovsulut/aksesadmin/manage1/adminrmedis.php?page=idpsnedit&kode=<?php echo $data['id'];?>" class="label label-info">Edit Tindakan</a>
				 </td>
				 <td bgcolor="#ffffff"><?php echo $data['no_rekamedis'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nik'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama_pasien'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jenis_kelamin'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['golongan_darah'];?></td>
					
				 <td bgcolor="#ffffff"><?php echo $data['tempat_lahir'];?>,
				 <?php echo $data['tanggal_lahir'];?></td>
					
				 <td bgcolor="#ffffff"><?php echo $data['nama_ibu'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['alamat'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['agama'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['dokter'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['tujuan'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['pembiayaan'];?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div>