


<?php
	include "conaset.php";
	// perintah php untuk akses ke database
	$con = mysqli_connect($host, $user, $password, $database);

	if (!$con){
	die ("Database Tidak Ada : " . mysqli_connect_error());
		}
	$kueri = mysqli_query($con, "SELECT * FROM aset1 WHERE keterangan LIKE '%operasional%' ");

		$data = array ();
		while (($row = mysqli_fetch_array($kueri)) != null){
			$data[] = $row;
		}
	$contopr = count ($data);
	{	
?>

<?php } ?>
