<?php
include "conkeu.php";
?>
<br><br>
<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
	  					<form id="form" role="form" method="post" action="#">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>Input PPTK</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s">
													   <div>
															<label for="nama">Nama</label>
															<input type="text" class="form-control" name="nama" placeholder="...." required>
													   </div>
													  
													  
													  <div>
															<label for="keterangan">Keterangan</label>
															<input type="text" class="form-control" name="keterangan" placeholder="...." required>
													   </div>

													   

													   <div>
															<br>&nbsp; <a href="#"> </a>
															<button class="btn btn-success" type="submit" class="form-control" name="tambah">Input</button>
														   <br>
													   </div>
								  
  							</form>
						</div>
	
	  
	  					<!-- validasi yang belum ditampilkan-->
													<?php 
													//if(isset($_GET['nomor_jurnal'])){
													//	if($_GET['nomor_jurnal'] == ""){
													//		echo "<h4 style='color:red'>Nomor Jurnal Belum Di Masukkan !</h4>";
													//	}
													//}
													?>
		   
			 
							<!-- php input -->

							<?php

							  // Check If form submitted, insert form data into users table.
							  if(isset($_POST['tambah'])) {
								$nama = htmlspecialchars($_POST['nama']);	
								$keterangan = htmlspecialchars($_POST['keterangan']);
								  
								//koneksi.phpr data into table
								$query="INSERT INTO pptk SET nama='$nama', keterangan='$keterangan'";
								  mysqli_query($koneksi, $query); 

								  
								  echo "<script>alert('Input PPTK :$nama');window.location='/aksesadmin/halaman9/dataentry.php'</script>";
								}
							?>


</div>
</div>    
</div>
<br>