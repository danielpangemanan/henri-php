<?php
include "./koneksi.php";
$jumlahDataPerHalaman = 10;
$jumlahData = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tabel_pesan"));
$jumlahHalaman = ceil($jumlahData / $jumlahDataPerHalaman);
$halamanAktif = (isset ($_GET["halaman"])) ? $_GET["halaman"] : 1;
$awalData = ($jumlahDataPerHalaman * $halamanAktif) - $jumlahDataPerHalaman;

$data = mysqli_query($koneksi, "SELECT * FROM tabel_pesan LIMIT $awalData, $jumlahDataPerHalaman");				
?>



<section class="">
<br>
<br>
<center><h2>KONFIRMASI PEMASUKKAN</h2></center>
<div id="main">
<br>	
<div class="container-fluid">
   <div class="table-responsive">
			<table class="table table-bordered" style="background-color: white;">
				<thead>
		   			<tr>
						<th>Konfirmasi</th>
						<th>Keterangan Pemasukkan</th>
						<th>Jumlah (Rp)</th>
						<th>Status Konfirmasi</th>
					</tr>
				</thead>

				<tbody>
							   
						<?php 
							$username = $_SESSION['username'];
							$pesan = $koneksi->query("SELECT * FROM tabel_pesan ORDER BY pesan DESC LIMIT $awalData, $jumlahDataPerHalaman");
							while ($data=$pesan->fetch_assoc()) {

						?>

						<tr>

							
							<td>
								<a href="?page=konf1&nomor=<?php echo $data['nomor']; ?>&waktu=<?php echo $data['waktu']; ?>&jumlah=<?php echo $data['jumlah']; ?>&keterangan=<?php echo $data['keterangan']; ?>" class="label label-warning">Konfirm</a>
							</td>

							<td>
								<?php echo $data['keterangan']; ?>
							</td>

							<td align="left">
								<?php echo "Rp." . number_format($data['jumlah']).",-"; ?>
							</td>
							<td>
								<a class="label label-success"><?php echo $data['sudahbaca']; ?></a>
							</td>

						</tr>

					 	<?php
						}

						?>

					</tbody>
				</table>

					 		<center>
					 		<?php if ($halamanAktif > 1 ) : ?>
								<a class="btn btn-primary"  href="spvkasir.php?page=spv1&halaman=<?= $halamanAktif - 1 ?>" role="button">Prev</a>
							<?php endif ; ?>|

					  		<?php if ($halamanAktif < $jumlahHalaman ) : ?>
								<a class="btn btn-primary" href="spvkasir.php?page=spv1&halaman=<?= $halamanAktif + 1 ?>" role="button">Next</a>
							<?php endif ; ?>
							</center>
						</div>
					</div>
				</div>

			</div>
		</div>
</section>
						
</div>
<br>


