<?php

$db = new Mysqli("localhost", "root", "", "medkesne_rsudaset1");
?>

<br>

<?php

                            if(isset($_GET["kode_aset"])){
                                $search = $_GET['kode_aset'];
								$text=$_GET['kode_aset'];
								
                                $query = $db->query("SELECT * FROM aset2 WHERE kode_aset LIKE '%$search%' ORDER BY id ASC");
                            }
						
						
						 else {
                                $query = $db->query("SELECT * FROM aset2 ORDER BY id ASC");
                            }
						


                            while($data = mysqli_fetch_assoc($query)) {
						

?>

<center>
	<strong align="center"><?php echo $data['nama']; ?></strong>
		<hr>
	<br>
</center>
<table class="table table-hover">
  
  <thead>
	    <tr>
	      <th scope="col">Nomor Kode Aset</th>
	      <th scope="col">Keterangan Aset</th>
	      <th scope="col">Tanggal Masuk</th>
	      <th scope="col">Barcode</th>
	    </tr>
  </thead>
  <tbody>
	    <tr align="center">
	      <td><?php echo $data['kode_aset']; ?></td>
	      <td><?php echo $data['keterangan']; ?></td>
	      <td><?php echo $data['tanggal_masuk']; ?></td>
	      <td><?php echo "<img src='/aksesadmin/manage1/halaman1/barcode.php?codetype=Code39&size=40&text=".$text."&print=true'/>"?></td>
	    </tr>
  </tbody>
</table>

    <center><a href="/rsiakirana/aksesadmin/manage1/adminrs.php?page=aset2" class="btn btn-primary">selesai</a></center>
    	<br>
    <center><a href="" class="btn btn-primary">Print</a></center>
  

<?php } ?>
<br>