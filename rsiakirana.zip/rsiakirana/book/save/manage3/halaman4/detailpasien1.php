
<?php
	include "koneksi.php";

	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = "select * from tbl_pasien1 where id='$no'";
	$result = mysqli_query($koneksi,$sql);
	}
	while($data = mysqli_fetch_array($result))
	{
		
?>

<br>
<div class="container-fluid" class="col-md-12">
	
<div class="container-fluid">
   		<div class="table-responsive">
			<form method="POST">
				<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">
					<thead>
					<tr>
						<th><h3 class="th1" style="text-align: center">RSIA-KIRANA</h3></th>
						<th><h3 class="th1" style="text-align: center">REKAM MEDIS PASIEN</h3></th>
						<th></th>
					</tr>
		   			<tr>
						<th><center>DATA PASIEN</center></th>
						<th><center>KETERANGAN</center></th>
						<th><center>PROSES PASIEN</center></th>
					</tr>
				   </thead>

				   <tbody>
					<tr class="odd gradeX">

						<input type="hidden" class="form-control" name="id" value="<?php echo $data['id'];?>">
						<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">
						<td>Nomor Rekamedis</td>
						<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>

					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">

						<input type="hidden" class="form-control" name="id_registrasi" value="<?php echo $data['id_registrasi'];?>">
						<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">
						<td>Nomor Induk Kependudukan</td>
						<td><?php echo $data['nik']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="ruangan">
						        <option value='<?php echo $data['ruangan'];?>'><?php echo $data['ruangan'];?></option>
						        <option value="Pasien Rawat Jalan">Pasien Rawat Jalan</option>
								<option value="Pasien Rawat Inap dan Perawatan">Pasien Rawat Inap dan Perawatan</option>
								<option value="Pasien Gawat Darurat">Pasien Gawat Darurat</option>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nama_pasien" value="<?php echo $data['nama_pasien'];?>">
						<td>Nama Pasien</td>
						<td><?php echo $data['nama_pasien']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="dokter_lain">
						        <option value='<?php echo $data['dokter_lain'];?>'><?php echo $data['dokter_lain'];?></option>
						          <?php
						         //Membuat koneksi ke database
						         $kondokter = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
						         if (!$kondokter){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%'";

						          $hasil=mysqli_query($kondokter,$sql);
						          
						          while ($dokter1 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?>"><?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="jenis_kelamin" value="<?php echo $data['jenis_kelamin'];?>">
						<td>Jenis Kelamin</td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="triage">
						        <option value='<?php echo $data['triage'];?>'><?php echo $data['triage'];?></option>
						        <option value="Merah">Merah</option>
								<option value="Kuning">Kuning</option>
								<option value="Hijau">Hijau</option>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="golongan_darah" value="<?php echo $data['golongan_darah'];?>">
						<td>Golongan Darah</td>
						<td><?php echo $data['golongan_darah']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="ruang_inap">
						        <option value='<?php echo $data['ruang_inap'];?>'><?php echo $data['ruang_inap'];?></option>
						          <?php
						         //Membuat koneksi ke database
						         $rinap = mysqli_connect("localhost",'root',"","medkesne_rsudroom");
						         if (!$rinap){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="SELECT * FROM ruangan ORDER BY id_ruangan";

						          $hasil=mysqli_query($rinap,$sql);
						          
						          while ($ruanginap = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $ruanginap['nama'];?>"><?php echo $ruanginap['nama'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="tempat_lahir" value="<?php echo $data['tempat_lahir'];?>">
						<input type="hidden" class="form-control" name="tanggal_lahir" value="<?php echo $data['tanggal_lahir'];?>">
						<td>Tempat, Tanggal Lahir</td>
						<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="alamat" value="<?php echo $data['alamat'];?>">
						<td>Alamat</td>
						<td><?php echo $data['alamat']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nama_ibu" value="<?php echo $data['nama_ibu'];?>">
						<td>Nama Ibu Kandung</td>
						<td><?php echo $data['nama_ibu']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="agama" value="<?php echo $data['agama'];?>">
						<td>Agama</td>
						<td><?php echo $data['agama']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Status</td>
						<td><input style="border: none;" type="text" class="form-control" name="status_menikah" value="<?php echo $data['status_menikah'];?>"></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Telp/Hp</td>
						<td><input style="border: none;" type="text" class="form-control" name="no_hp" value="<?php echo $data['no_hp'];?>"></td>
					</tr>
				   	</tbody>

				   	
				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pekerjaan</td>
						<td><input style="border: none;" type="text" class="form-control" name="id_pekerjaan" value="<?php echo $data['id_pekerjaan'];?>"></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pembiayaan</td>
						<td>
							<select style="border: none;" name="pembiayaan" class="form-control" name="pembiayaan" required>
								<option value="<?php echo $data['pembiayaan'];?>"><?php echo $data['pembiayaan'];?></option>
								<option value="Mandiri">Mandiri</option>
								<option value="BPJS">BPJS</option>
							</select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Ruang Penanganan Pasien</td>
						<td>
						<select style="border: none;" class="form-control" name="tujuan" required>
					        <option value='<?php echo $data['tujuan'];?>'><?php echo $data['tujuan'];?></option>
					          <?php
					         //Membuat koneksi ke database
					         $kontujuan = mysqli_connect("localhost",'root',"","medkesne_rsudroom");
					         if (!$kontujuan){
					            die("Koneksi database gagal:" .mysqli_connect_error());
					         }
					        
					         //Perintah sql untuk menampilkan semua data pada tabel 
					          $sql="select * from tujuan_pasien";

					          $hasil=mysqli_query($kontujuan,$sql);
					          
					          while ($ptujuan = mysqli_fetch_array($hasil)) {
					          
					         ?>
					          <option value="<?php echo $ptujuan['nama_tujuan'];?>"><?php echo $ptujuan['nama_tujuan'];?></option>
					        <?php 
					        }
					        ?>
					    </select>
					</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Registrasi</td>						
						<td><?php echo $data['id_registrasi'];?></td>
						
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Dokter</td>
						<td><select style="border: none;" class="form-control" name="dokter" required>
									        <option value='<?php echo $data['dokter'];?>'><?php echo $data['dokter'];?></option>
									          <?php
									         //Membuat koneksi ke database
									         $koneksi = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
									         if (!$koneksi){
									            die("Koneksi database gagal:" .mysqli_connect_error());
									         }
									        
									         //Perintah sql untuk menampilkan semua data pada tabel 
									          $sql="SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%'";

									          $hasil=mysqli_query($koneksi,$sql);
									          $no=0;
									          while ($data = mysqli_fetch_array($hasil)) {
									          $no++;
									         ?>
									          <option value="<?php echo $data['nama'];?>&nbsp:<?php echo $data['kompetensi'];?>"><?php echo $data['nama'];?>&nbsp:<?php echo $data['kompetensi'];?></option>
									        <?php 
									        }
									        ?>
									    </select></td>
					</tr>
				   	</tbody>
				 	</table>

				 	<div>
						<button type="submit" name="input" class="btn btn-primary">Proses Perubahan Data Pasien</button>
						<!-- <a class="btn btn-primary" href="/aksesadmin/manage1/halaman4/printbarcode.php?page=printbarcode&kode=<?php echo $data['no_rekamedis'];?>" role="button">Print</a> -->
					</div>
				 </form>
				<?php } ?>
		</div>
	</div>
</div>
<hr>



<!-- <style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
	.th1{
		position: relative;
		top: -40px;
	}
</style> -->

 <?php


	  if(isset($_POST['input'])) {
	  	$id= $_POST['id'];
	  	$no_rekamedis=$_POST['no_rekamedis'];
		$id_registrasi= $_POST['id_registrasi'];
		$nik= $_POST['nik'];
		$nama_pasien=$_POST['nama_pasien'];
		$jenis_kelamin=$_POST['jenis_kelamin'];
		$golongan_darah=$_POST['golongan_darah'];
		$tempat_lahir=$_POST['tempat_lahir'];
		$tanggal_lahir=$_POST['tanggal_lahir'];
		$nama_ibu=$_POST['nama_ibu'];
		$alamat=$_POST['alamat'];
		$agama=$_POST['agama'];
		$status_menikah=$_POST['status_menikah'];
		$no_hp=$_POST['no_hp'];
		$id_pekerjaan=$_POST['id_pekerjaan'];
		$dokter=$_POST['dokter'];
		$tujuan=$_POST['tujuan'];
		$pembiayaan=$_POST['pembiayaan'];
		$ruangan=$_POST['ruangan'];
		$dokter_lain=$_POST['dokter_lain'];
		$triage=$_POST['triage'];
		$ruang_inap=$_POST['ruang_inap'];

		// Insert user data into table
		mysqli_query($koneksi, "UPDATE tbl_pasien1 SET 
			no_rekamedis='$no_rekamedis',
			id_registrasi='$id_registrasi',
			nik='$nik',
			nama_pasien='$nama_pasien',
			jenis_kelamin='$jenis_kelamin',
			golongan_darah='$golongan_darah',
			tempat_lahir='$tempat_lahir',
			tanggal_lahir='$tanggal_lahir',
			nama_ibu='$nama_ibu',
			alamat='$alamat',
			agama='$agama',
			status_menikah='$status_menikah',
			no_hp='$no_hp',
			id_pekerjaan='$id_pekerjaan',
			dokter='$dokter',
			tujuan='$tujuan',
			pembiayaan='$pembiayaan',
			ruangan='$ruangan',
			dokter_lain='$dokter_lain',
			triage='$triage',
			ruang_inap='$ruang_inap' 
			WHERE id=$id"); 
		  		
		echo "<script>alert('data pasien $nama_pasien berhasil dirubah || dengan Triage: $triage');window.location='/rsudprovsulut/aksesadmin/manage1/adminrmedis.php?page=datapasien'</script>";
		
	  }
	?>
	



				


