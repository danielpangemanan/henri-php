

<?php  
$db = new Mysqli("localhost", "root", "", "medkesne_rsudsdm1");
 ?>

<div class="container">
	<form method="post" enctype="multipart/form-data">
      <div class="form-group row mt-2" class="form-group row mb-2">
        <div class="col-md-2">
          <label for="cari">No.R.Medis Pasien</label>
          <input type="text" name="keyword" class="form-control" id="">
          <button type="submit" class="btn btn-sm btn-danger" name="cari">cari pasien</button>
      </div>
    </form>
</div>
<br>


<div class="main-grid">
		<div class="agile-grids">
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th>DATA PASIEN</th>
				 <th>Nomor R.Medis</th>
				 <th>NIK</th>
				 <th>Nama Pasien</th>
				 <th>Jenis Kelamin</th>
				 <th>Dokter</th>
				 <th>#</th>
				</tr>
					
					<?php 
                    if(isset($_POST["cari"])){
                        $search = $_POST['keyword'];

                        $query = $db->query("SELECT * FROM tbl_pasien WHERE no_rekamedis LIKE '%$search%' OR nik LIKE '%$search%' OR nama_pasien LIKE '%$search%'");
                    }else {
                        $query = $db->query("SELECT * FROM tbl_pasien1 ORDER BY no_rekamedis");
                    }
				
                   while($data = mysqli_fetch_assoc($query))
					{
					?>	
					
				<tr>
				 <td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=bkeupsn1&kode=<?php echo $data['no_rekamedis'];?>" class="label label-info">Proses Pembayaran Pasien</a></td>
				 <td bgcolor="#ffffff"><?php echo $data['no_rekamedis'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nik'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama_pasien'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jenis_kelamin'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['dokter'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['tujuan'];?></td>
				</tr>
				<?php } ?>
				</table>
			</div>