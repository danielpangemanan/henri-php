<?php
include "conaset.php";
?>


<br>

		<!-- Main -->
	  <div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
						
	  					<form id="form" role="form" method="post" action="#">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>Form Tambah Aset Bergerak</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s" >
                                   
                                        <label for="kode_aset">Kode Aset</label><br>
                                        <input type="text" class="form-control" name="kode_aset" placeholder="...." required>
                                  		<br>
										
										<label for="keterangan">Jenis Aset</label>
										<select name="keterangan" class="form-control" name="keterangan" required>
											<option value="">.....</option>
											<option value="Operasional">Operasional</option>
											<option value="Ambulance">Ambulance</option>
											<option value="Mobil Jenazah">Mobil Jenazah</option>
										</select>
								  
								  		<p>*Tambah Jenis Aset</p>
									    <br>
                                   
                                        <label for="nama">Nama Aset</label><br>
                                        <input type="text" class="form-control" name="nama" placeholder="...."required>
                                  		<br>

                                   
                                        <label for="anggaran">Mata Anggaran</label><br>
                                        <select name="anggaran" class="form-control" name="anggaran" required>
											<option value="">.....</option>
											<option value="Unit RSUD">Unit RSUD</option>
											<option value="Pusat">Pusat</option>
											<option value="Provinsi">Provinsi</option>
											<option value="Daerah">Daerah</option>
										</select>
                                   		<br>

                                   
                                        <label for="tanggal_masuk">Tanggal Masuk</label><br>
                                        <input type="date" class="form-control" name="tanggal_masuk" placeholder="...."required>
								    	<br>
                                                
                                   
                                        <label for="penerima">Penerima</label>
                                        <select name="penerima" class="form-control" name="penerima" required>
											<option value="">.....</option>
											<option value="Administrasi Umum">Administrasi Umum</option>
											<option value="Lain-Lain">Lain-Lain</option>
										</select>
                                        <br>
								  
								  		<label for="harga">Biaya/Harga</label><br>
                                        <input type="text" class="form-control" name="harga" placeholder="....."required>
									   <br>
									  
									   <div>
											<button type="submit" name="tambah"
													class="btn btn-primary" >Input </button>
											<a type="button" href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=aset1" class="btn btn-primary">Selesai</a>
										</div>
								  		
								  </form>
						</div>
	  					
							
				

	  					<?php
						  
						  if(isset($_POST['tambah'])) {
							$kode_aset = htmlspecialchars($_POST['kode_aset']);
							$keterangan= htmlspecialchars($_POST['keterangan']);
							$nama= htmlspecialchars($_POST['nama']);
							$anggaran = htmlspecialchars($_POST['anggaran']);
							$penerima = htmlspecialchars($_POST['penerima']);
							$tanggal_masuk= htmlspecialchars($_POST['tanggal_masuk']);
							$harga= htmlspecialchars($_POST['harga']);

							$cekdulu= "select * from aset1 where kode_aset='$_POST[kode_aset]'"; 
							$prosescek= mysqli_query($koneksi, $cekdulu);
							if (mysqli_num_rows($prosescek)>0) { //proses mengingatkan data sudah ada
								echo "<script>alert('maaf $kode_aset sudah terdaftar'); </script>";
							} else {
							// Insert user data into table
							$result = mysqli_query($koneksi, "INSERT INTO aset1 (kode_aset,keterangan,nama,anggaran,penerima,tanggal_masuk,harga,jumlah) VALUES('$kode_aset','$keterangan','$nama','$anggaran','$penerima','$tanggal_masuk','$harga')"); 
							}
							
							echo "<script>alert('Terima Kasih'); </script>"; 
						  }
						?>

		</div>
	</div>
  </div>  
 </div>
</div>
<br>
    