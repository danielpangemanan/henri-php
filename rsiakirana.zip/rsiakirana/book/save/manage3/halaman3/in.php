<?php
include "conkeu.php";
$jumlahDataPerHalaman = 10;
$jumlahData = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM jurnal_masuk"));
$jumlahHalaman = ceil($jumlahData / $jumlahDataPerHalaman);
$halamanAktif = (isset ($_GET["halaman"])) ? $_GET["halaman"] : 1;
$awalData = ($jumlahDataPerHalaman * $halamanAktif) - $jumlahDataPerHalaman;

$data = mysqli_query($koneksi, "SELECT * FROM jurnal_masuk LIMIT $awalData, $jumlahDataPerHalaman");				
?>

<br>
<br>

	

	
<section class="">
<center><h2>KAS MASUK</h2></center>
<div id="main">
<div class="container-fluid">
   <div class="table-responsive">
	   
				   			<form method="get">
								<label>Pilih Tanggal</label>
								<input type="date" name="tanggal">
								<input type="submit" value="cari">
							</form>
				   			<br>


							<table class="table table-bordered" class="table-condensed" id="">
				   			<tr>
								<th>PEMASUKKAN</th>
								<th>Nomor Jurnal</th>
								<th>Kas</th>
								<th>Jumlah</th>
								<th>Kode Transaksi</th>
								<th>Tanggal</th>

							</tr>
						   </thead>
						   <tbody>

						
							   
						<?php 

							$no= 1;

							$sql = $koneksi->query("select * from jurnal_masuk ORDER BY tanggal_masuk DESC LIMIT $awalData, $jumlahDataPerHalaman");
							while ($data=$sql->fetch_assoc()) {

						?>

						<tr class="odd gradeX">
							<td></td>
							<td><?php echo $data['nomor_jurnal']; ?></td>
							<td><?php echo $data['jenis']; ?></td>
							<td align="left"><?php echo "Rp." . number_format($data['jumlah']).",-"; ?></td>
							<td><?php echo $data['kode_transaksi']; ?></td>
							<td><?php echo $data['tanggal_masuk']; ?></td>

						</tr>

					 	<?php
						}

						?>

					   </tbody>
					 </table>

					 		<center>
					 		<?php if ($halamanAktif > 1 ) : ?>
								<a class="btn btn-primary"  href="adminrs.php?page=inkeu&halaman=<?= $halamanAktif - 1 ?>" role="button">Prev</a>
							<?php endif ; ?>|

							 <!-- <dl class="pagination justify-content pull-right">
							    <dt>
							    	
							    	<?php for ($i=1; $i <= $jumlahHalaman; $i++) : ?>
										<?php if( 0 == $halamanAktif) : ?>
										<a class="page-link" href="adminrs.php?page=inkeu&halaman=<?= $i; ?>" style="font-weight: bold"><?= $i; ?></a>
										<?php else : ?>
								</dt>

					   			<li>
							    	 <a class="page-link" href="adminrs.php?page=inkeu&halaman=<?= $i; ?>"><?= $i; ?></a>
										<?php endif; ?>
									<?php endfor; ?>
							    </li>
					  		</dl> -->

					  		<?php if ($halamanAktif < $jumlahHalaman ) : ?>
								<a class="btn btn-primary" href="adminrs.php?page=inkeu&halaman=<?= $halamanAktif + 1 ?>" role="button">Next</a>
							<?php endif ; ?>
							</center>
						</div>
					</div>
				</div>

			</div>
		</div>
</section>
						
</div>
<br>


