<?php
include "conkeu.php";
?>

<br>
<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
	  					<form id="form" role="form" method="post" action="">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>Input Pemasukkan</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s">
													   <div class="col-md-6 col-sm-6">
															<label for="nomor_jurnal">Nomor Jurnal</label>
															<input type="text" class="form-control" name="nomor_jurnal" placeholder="...." required>
													   </div>
													  
													  
													  <div class="col-md-6 col-sm-6">
															<label for="jenis">Keterangan</label>
															<input type="text" class="form-control" name="jenis" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="jumlah">Jumlah(Rp)</label>
															<input type="text" class="form-control" name="jumlah" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="kode_transaksi">Nomor Transaksi</label>
															<input type="text" class="form-control" name="kode_transaksi" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="tanggal_masuk">Tanggal Masuk</label>
															<input type="date" class="form-control" name="tanggal_masuk" placeholder="...." required>
														</div>
								  						<br>
								  						
								  						<div class="col-md-6">
														  <div >
															<label class="input-group-text" for="inputGroupSelect01">Bulan</label>
														  </div>
														  <select class="custom-select" id="inputGroupSelect01" name="bulan" required>
															<option value=>....pilih....</option>
															<option value="Januari">Januari</option>
															<option value="Februari">Februari</option>
															<option value="Maret">Maret</option>
															<option value="April">April</option>
															<option value="Mei">Mei</option>
															<option value="Juni">Juni</option>
															<option value="Juli">Juli</option>
															<option value="Agustus">Agustus</option>
															<option value="September">September</option>
															<option value="Oktober">Oktober</option>
															<option value="November">November</option>
															<option value="Desember">Desember</option>
														  </select>
														</div>

													   <div class="col-md-12 col-sm-12">
															<br>
															<button  class="col-md-2" type="submit" class="form-control" name="tambah">Input</button>
														   <br>
													   </div>
								  
  							</form>
						</div>
	
	  
	  					<!-- validasi yang belum ditampilkan-->
													<?php 
													//if(isset($_GET['nomor_jurnal'])){
													//	if($_GET['nomor_jurnal'] == ""){
													//		echo "<h4 style='color:red'>Nomor Jurnal Belum Di Masukkan !</h4>";
													//	}
													//}
													?>
		   
			 
							<!-- php input -->

							<?php
								include_once "conkeu.php";
							  // Check If form submitted, insert form data into users table.
							  if(isset($_POST['tambah'])) {
								$nomor_jurnal = $_POST['nomor_jurnal'];
								$jenis = $_POST['jenis'];
								$jumlah = $_POST['jumlah'];
								$kode_transaksi = $_POST['kode_transaksi'];
								$tanggal_masuk = $_POST['tanggal_masuk'];
								$bulan = $_POST['bulan'];

								  
								//koneksi.phpr data into table
								$query="INSERT INTO jurnal_masuk SET nomor_jurnal='$nomor_jurnal', jenis='$jenis',jumlah='$jumlah',kode_transaksi='$kode_transaksi',tanggal_masuk='$tanggal_masuk',bulan='$bulan'";
								  mysqli_query($koneksi, $query); 

								  
								  echo "<script>alert('Input Berhasil Rp. :$jumlah');window.location=''</script>";
								}
							?>  


</div>
</div>    
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

    