<div class="container">
			<div class="row panel2">
				<div class="col-md-12 info-panel">
					<div class="row">