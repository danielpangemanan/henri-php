

<?php
	include "koneksi.php";

	echo '<div style="border:0px double #ababab; padding:5px;margin:5px height:750px;;width:500px;">';
	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
	   		<div class="table-responsive">
				
					<table border="1" cellpadding="1" cellspacing="1" align="center" width="150%">
						<thead>
						<tr>
							<th><center><img src="/rsudprovsulut/images/logo.png" width="135px" height="60px"></center></th>
							<th><h3 style="text-align: center">REKAP PASIEN <br> Nomor Rekam Medis:&nbsp<center><?php echo bar128(stripslashes($data['no_rekamedis'])); ?></center></h3></th>
						</tr>
			   			<tr>
							<th><center>DATA PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   </thead>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Rekamedis</td>
							<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Induk Kependudukan</td>
							<td><?php echo $data['nik']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Pasien</td>
							<td><?php echo $data['nama_pasien']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Petugas Dokter</td>
							<td><strong><?php echo $data['dokter']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Jenis Kelamin</td>
							<td><?php echo $data['jenis_kelamin']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Golongan Darah</td>
							<td><?php echo $data['golongan_darah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Tempat, Tanggal Lahir</td>
							<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Alamat</td>
							<td><?php echo $data['alamat']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Ibu Kandung</td>
							<td><?php echo $data['nama_ibu']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Agama</td>
							<td><?php echo $data['agama']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Status</td>
							<td><?php echo $data['status_menikah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Telp/Hp</td>
							<td><?php echo $data['no_hp']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pekerjaan</td>
							<td><?php echo $data['id_pekerjaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pembiayaan</td>
							<td><?php echo $data['pembiayaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Ruang Penanganan Pasien</td>
							<td><?php echo $data['tujuan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Ruang Inap Pasien</td>
							<td><?php echo $data['ruang_inap']; ?></td>
							
						</tr>
					   	</tbody>
					   	
					 	</table>
					 <?php } ?>
				</div>
			</div>
				

					
		

	<div class="agile-grids">	
			<div class="table-responsive">
					<table border="1" cellpadding="1" cellspacing="1" align="center" width="150%">
							<?php
							include "koneksi.php";

							echo '<div style="border:0px double #ababab; padding:5px;margin:5px height:750px;;width:500px;">';
							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrjalan where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   </table>
					   <?php } ?>
					</div>
			</div>


			<div class="agile-grids">	
			<div class="table-responsive">
					<table border="1" cellpadding="1" cellspacing="1" align="center" width="150%">
							<?php
							include "koneksi.php";

							echo '<div style="border:0px double #ababab; padding:5px;margin:5px height:750px;;width:500px;">';
							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrinap where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   </table>
					   <?php } ?>
					</div>
			</div>


			<div class="agile-grids">	
				<div class="table-responsive">
					<table border="1" cellpadding="1" cellspacing="1" align="center" width="150%">
							<?php
							include "koneksi.php";

							echo '<div style="border:0px double #ababab; padding:5px;margin:5px height:750px;;width:500px;">';
							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrgd where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Keluhan Pasien</td>
							<td><strong><?php echo $data['keluhan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Riwayat Penyakit Pasien</td>
							<td><strong><?php echo $data['rpenyakit']; ?>&nbsp(kode penyakit)</strong></td>
						</tr>
					   	</tbody>
					   	<?php } ?>


					   	<?php

						$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudroom";
						$koneksiroom    = mysqli_connect($host, $user, $password, $database);
						$no = $_GET['kode'];

						$ambildata=mysqli_query($koneksiroom, "SELECT tabel_trnruangpasien.no_rekamedis, tabel_trnruangpasien.id_data, tabel_trnruangpasien.jumlah, data_ruangan.harga, data_ruangan.keterangan FROM tabel_trnruangpasien JOIN data_ruangan ON data_ruangan.id_data = tabel_trnruangpasien.id_data where id_registrasi='$no'");
						
						while($databiayaruangan = mysqli_fetch_array($ambildata)){

							$jumlah=$databiayaruangan['jumlah'];
							$harga=$databiayaruangan['harga'];
							$totalruangan=$jumlah*$harga;

						?>

					<tbody>
						<tr class="odd gradeX">
							<td>Nama Ruangan</td>
							<td><?php echo $databiayaruangan['keterangan'];?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Jumlah Hari Penggunaan Ruangan</td>
							<td><?php echo $databiayaruangan['jumlah'];?></td>
						</tr>
					</tbody>
														
					<tbody>
						<tr class="odd gradeX">
							<td>Biaya Penggunaan Ruangan</td>
							<td><?php echo "Rp." .number_format($databiayaruangan['harga']).",-";?></td>
						</tr>
					</tbody>
					<?php } ?>




					<?php

						$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudobat";
						$koneksiobat    = mysqli_connect($host, $user, $password, $database);
						$no1 = $_GET['kode'];

						$ambildata1=mysqli_query($koneksiobat, "SELECT tabel_trnobatpasien.no_rekamedis, tabel_trnobatpasien.id_obat, tabel_trnobatpasien.jumlah, dataobat.harga_obt, dataobat.nama_obt FROM tabel_trnobatpasien JOIN dataobat ON dataobat.id_obat = tabel_trnobatpasien.id_obat where id_registrasi='$no1'");
						
						while($databiayaobat = mysqli_fetch_array($ambildata1)){

							$jumlah=$databiayaobat['jumlah'];
							$harga_obt=$databiayaobat['harga_obt'];
							$totalobat=$jumlah*$harga_obt;
					?>

					
					<tbody>
						<tr class="odd gradeX">
							<td>Nama Obat</td>
							<td><?php echo $databiayaobat['nama_obt'];?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Jumlah Obat</td>
							<td><?php echo $databiayaobat['jumlah'];?></td>
						</tr>
					</tbody>
														
					<tbody>
						<tr class="odd gradeX">
							<td>Biaya Obat</td>
							<td><?php echo "Rp." .number_format($databiayaobat['harga_obt']).",-";?></td>
						</tr>
					</tbody>
					<?php } ?>

					   </table>
					</div>
				</div>
				

				<div class="agile-grids">	
				<div class="table-responsive">
					<table border="1" cellpadding="1" cellspacing="1" align="center" width="150%">
							<?php
							$host       = "localhost";
							$user       = "root";
							$password   = "";
							$database   = "medkesne_rsudkeu";
							$koneksi    = mysqli_connect($host, $user, $password, $database);

							echo '<div style="border:0px double #ababab; padding:5px;margin:5px height:750px;;width:500px;">';
							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tabel_prspbrpasien where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA PEMBAYARAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Nama Pasien</td>
							<td><strong><?php echo $data['nama_pasien']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>NIK</td>
							<td><strong><?php echo $data['nik']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Total Bayar</td>
							<td><strong><?php echo "Rp." .number_format($data['jumlah']).",-";?></strong></td>
						</tr>
					   	</tbody>


					   </table>
					</div>
				</div>
				<?php } ?>



	</div>
</center>
<br>
<br>
	<center>
		<button><a class="btn btn-primary" href="/rsudprovsulut/aksesadmin/manage1/halaman4/printoutpasien.php?page=printoutpasien&kode=<?php echo $data['no_rekamedis'];?>" role="button">PRINT</a></button>

		<button><a class="btn btn-primary" href="/rsudprovsulut/aksesadmin/manage1/adminrmedis.php" role="button">SELESAI</a></button>
	</center><br>






















<!-- 
<?php
	$host       = "localhost";
	$user       = "medkesne_rsud";
	$password   = "rsudprovsulut123";
	$database   = "medkesne_rsudsdm1";
	$koneksi    = mysqli_connect($host, $user, $password, $database);

	echo '<div style="border:0px double #ababab; padding:5px;margin:5px height:750px;;width:500px;">';
	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien where no_rekamedis='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<center>
<div class="container-fluid" class="col-md-12">
	
<div class="container-fluid">
   		<div class="table-responsive">
		
				<table border="1" cellpadding="1" cellspacing="3" align="center" width="150%">
					<thead>
					<tr>
						<th><center><img src="images/logo.png"></center></th>
						<th><h3 style="text-align: center">REKAM MEDIS PASIEN</h3></th>
						<th></th>
					</tr>
		   			<tr>
						<th><center>DATA PASIEN</center></th>
						<th><center>KETERANGAN</center></th>
						<th></th>
					</tr>
				   </thead>

				   <tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Rekamedis</td>
						<td style="text-align: center"><?php echo $data['no_rekamedis']; ?></td>
						<td><strong>Dokter:&nbsp<?php echo $data['dokter']; ?></strong></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Induk Kependudukan</td>
						<td><?php echo $data['nik']; ?></td>
						<td><?php echo bar128(stripslashes($data['no_rekamedis'])); ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Pasien</td>
						<td><?php echo $data['nama_pasien']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Jenis Kelamin</td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Golongan Darah</td>
						<td><?php echo $data['golongan_darah']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Tempat, Tanggal Lahir</td>
						<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Alamat</td>
						<td><?php echo $data['alamat']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Ibu Kandung</td>
						<td><?php echo $data['nama_ibu']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Agama</td>
						<td><?php echo $data['agama']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Status</td>
						<td><?php echo $data['status_menikah']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Telp/Hp</td>
						<td><?php echo $data['no_hp']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pekerjaan</td>
						<td><?php echo $data['id_pekerjaan']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pembiayaan</td>
						<td><?php echo $data['pembiayaan']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Ruang Penanganan Pasien</td>
						<td><?php echo $data['tujuan']; ?></td>
					</tr>
				   	</tbody>
				   	
				 	</table>
				
		</div>
	</div>
</div>
</center>
<br>
<br>
	<hr><center>
		<button><a class="btn btn-primary" href="/aksesadmin/manage1/halaman4/printoutpasien.php?page=printoutpasien&kode=<?php echo $data['no_rekamedis'];?>" role="button">PRINT</a></button>

		<button><a class="btn btn-primary" href="/aksesadmin/manage1/adminrmedis.php" role="button">SELESAI</a></button>
	</center><hr><br>
<?php } ?> -->



	
















<!-- <?php 
$host       = "localhost";
$user       = "medkesne_rsud";
$password   = "rsudprovsulut123";
$database   = "medkesne_rsudsdm1";
$koneksi    = mysqli_connect($host, $user, $password, $database);
?>



<?php
include('bar128.php');
$sql = $koneksi->query("select *from tbl_pasien order by no_rekamedis desc limit 1");
while ($data=$sql->fetch_assoc())
{
?>

	
	<?php
	}
	?>
	

<br>
<form method="get">
	<label>Masukkan Nomor Rekamedis</label>
	<input type="text" name="no_rekamedis">
	<input type="submit" value="cari">
</form>
<hr>

<?php 
																	
																	
	if(isset($_GET['no_rekamedis'])){
		$pasien = $_GET['no_rekamedis'];
		$sql = mysqli_query($koneksi,"select * from tbl_pasien where no_rekamedis='$pasien'");
	}else{
		$sql = mysqli_query($koneksi,"select * from tbl_pasien order by no_rekamedis desc limit 1");
	}
	while($data = mysqli_fetch_array($sql)){
	?>
<?php echo $data['nama_pasien']; ?><br>
<?php echo bar128(stripslashes($data['no_rekamedis'])); ?>
<?php } ?>



<button><a href="/aksesadmin/manage1/adminrmedis.php">Selesai</a></button> -->				


