




<!-----GRAFIK KEUANGAN------>
<div class="main-grid">
<div class="agile-grids">	
	
	<div class="chart-heading">
		<h2>SIM RSIA KIRANA</h2>
	</div>
		<br>

		
			<div class="w3l-chart events-chart">
				<h3>REKAP KEUANGAN</h3>
				<div class="events-chart-info">
					<div class="table-responsive">
						<table class="table table-bordered" class="table-condensed" id="" style="background-color: white;">
						  <thead>
							<tr style="text-align: center;">
								<th>Debet</th>
								<th>Kredit</th>
								<th>Keterangan</th>
								<th>Saldo Kas</th>
							</tr>
		     				</thead>
						   	<tbody>

							<?php 

								$no= 1;

								$sql = $koneksi->query("select *from jurnal_masuk ");
								while ($data=$sql->fetch_assoc()) {

							?>
							<?php
								$total_masuk=@$total_masuk+$data['jumlah'];
							   // $saldo_akhir=$total_masuk-$total_keluar;
								}
							?>

							<?php 

								$no= 1;

								$sql = $koneksi->query("select *from jurnal_keluar ");
								while ($data=$sql->fetch_assoc()) {

							?>
							<?php
								$total_keluar=@$total_keluar+$data['jumlah_kredit'];
							   // $saldo_akhir=$total_masuk-$total_keluar;
								}
							?>


							<?php 

								$sql = $koneksi->query("select *from jurnal_umum ");
								while ($data=$sql->fetch_assoc()) {

							?>
							<?php 
								}
							?>

							<tr class="odd gradeX" style="text-align: center;">
								<td><?php echo "Rp." .number_format($total_masuk).",-";?></td>
								<td><?php echo "Rp." .number_format($total_keluar).",-";?></td>
								<td>Laporan Jurnal Umum</td>
								<td><?php echo "Rp." .number_format($saldo_akhir=$total_masuk-$total_keluar).",-";?></td>
							</tr>
						  </tbody>
						</table>
					</div>
				</div>
			</div>
					
		
	<div class="w3l-chart events-chart">
			<h3>PEMASUKKAN PER/BULAN</h3>
			<div class="events-chart-info">
				<div id="graph11"></div>
				<script>
				var neg_data = [
				  {"period": "2020-01", "a":<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'januari' OR bulan LIKE '01'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaljan=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaljan"; ?> 
				  },
				  {"period": "2020-02", "a": 					<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'februari' OR bulan LIKE '02'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalfeb=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalfeb"; ?>
				},
				   
				  {"period": "2020-03", "a":<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'maret' OR bulan LIKE '03'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalmar=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalmar"; ?> 
				  },

				   
				  {"period": "2020-04", "a": 					<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'april' OR bulan LIKE '04'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalapr=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalapr"; ?>
				  },
				  {"period": "2020-05", "a": 					<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'mei' OR bulan LIKE '05'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalmei=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalmei"; ?>
				},
				{"period": "2020-06", "a": 					<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'juni' OR bulan LIKE '06'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaljun=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaljun"; ?>
				},
				{"period": "2020-07", "a": 					<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'juli' OR bulan LIKE '07'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaljul=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaljul"; ?>
				},
				{"period": "2020-08", "a": 					<?php
				   												
																?>					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'agustus' OR bulan LIKE '08'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalags=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalags"; ?>
				},
				{"period": "2020-09", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'september' OR bulan LIKE '09'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalsep=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalsep"; ?>
				},
				{"period": "2020-10", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'oktober' OR bulan LIKE '10'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalokt=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalokt"; ?>
				},
				{"period": "2020-11", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'november' OR bulan LIKE '11'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalnov=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalnov"; ?>
				},
				{"period": "2020-012", "a": 									
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'desember' OR bulan LIKE '12'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaldes=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaldes"; ?>
				}
				  
				];
				Morris.Line({
				  element: 'graph11',
				  data: neg_data,
				  xkey: 'period',
				  ykeys: ['a'],
				  labels: ['Pemasukkan'],
				  units: '(Rp)'
				});
				</script>
			</div>
		</div>
	
	<div class="w3l-chart events-chart">
			<h3>PENGELUARAN PER/BULAN</h3>
			<div class="events-chart-info">
				<div id="graph12"></div>
				<script>
				var neg_data = [
				  {"period": "2020-01", "a":					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'januari' OR bulan LIKE '01'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaljan=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaljan"; ?> 
				  },
				  {"period": "2020-02", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'februari' OR bulan LIKE '02'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalfeb=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalfeb"; ?>
				},
				   
				  {"period": "2020-03", "a":					
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'maret' OR bulan LIKE '03'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalmar=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalmar"; ?> 
				  },

				   
				  {"period": "2020-04", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'april'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalapr=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalapr"; ?>
				  },
				  {"period": "2020-05", "a": 									
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'mei'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalmei=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalmei"; ?>
				},
				{"period": "2020-06", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'juni'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaljun=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaljun"; ?>
				},
				{"period": "2020-07", "a": 									
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'juli' OR bulan LIKE '07'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaljul=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaljul"; ?>
				},
				{"period": "2020-08", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'agustus'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalags=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalags"; ?>
				},
				{"period": "2020-09", "a": 									
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'september'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalsep=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalsep"; ?>
				},
				{"period": "2020-10", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'oktober'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalokt=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalokt"; ?>
				},
				{"period": "2020-11", "a": 									
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'november'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totalnov=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totalnov"; ?>
				},
				{"period": "2020-012", "a": 										
				   												<?php 
			   													
																	$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'desember'");
																	while ($data=$sql->fetch_assoc()) {
																	
																?>
				   												
				   												<?php
																	$totaldes=$data['total'];
																	}
																?>
				   												
				   												<?php echo "$totaldes"; ?>
				}
				   
				];
				Morris.Line({
				  element: 'graph12',
				  data: neg_data,
				  xkey: 'period',
				  ykeys: ['a'],
				  labels: ['Pengeluaran'],
				  units: '(Rp)'
				});
				</script>
			</div>
		</div>
















<!-----GRAFIK KEUANGAN2------>
<div class="main-grid">
<div class="agile-grids">
	<div class="w3l-chart events-chart">
			<h3>PEMASUKKAN BULANAN</h3>
			<div class="events-chart-info">

				<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
				<script src="https://code.highcharts.com/highcharts.js"></script>
				<script src="https://code.highcharts.com/highcharts-more.js"></script>
				<script src="https://code.highcharts.com/modules/exporting.js"></script>
				<script src="https://code.highcharts.com/modules/export-data.js"></script>
				<script src="https://code.highcharts.com/modules/accessibility.js"></script>


				<figure class="highcharts-figure">
				    <div id="container"></div><!-- 
				    <button id="inverted0">Grafik Batang</button>
				    <button id="polar0">Grafik Lingkaran</button> -->
				</figure>


				<script>
					var chart = Highcharts.chart('container', {

					    title: {
					        text: 'Tabel Kas Masuk'
					    },

					    subtitle: {
					        text: 'Data Pemasukkan'
					    },
					    
					    credits: {
                             enabled: false
                            },

					    xAxis: {
					        categories: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Augustus', 'September', 'Oktober', 'November', 'Desember']
					    },
					    

					    series: [{
					        type: 'column',
					        colorByPoint: true,
					        data: [<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'januari' OR bulan LIKE '01'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaljan=$data['total'];
							}
							?>								
					   												<?php echo "$totaljan"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'februari' OR bulan LIKE '02'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalfeb=$data['total'];
							}
							?>								
					   												<?php echo "$totalfeb"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'maret' OR bulan LIKE '03'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalmar=$data['total'];
							}
							?>								
					   												<?php echo "$totalmar"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'april' OR bulan LIKE '04'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalapr=$data['total'];
							}
							?>								
					   												<?php echo "$totalapr"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'mei' OR bulan LIKE '05'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalmei=$data['total'];
							}
							?>								
					   												<?php echo "$totalmei"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'juni' OR bulan LIKE '06'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaljuni=$data['total'];
							}
							?>								
					   												<?php echo "$totaljuni"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'juli' OR bulan LIKE '07'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaljul=$data['total'];
							}
							?>								
					   												<?php echo "$totaljul"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'agustus' OR bulan LIKE '08'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalagustus=$data['total'];
							}
							?>								
					   												<?php echo "$totalagustus"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'september' OR bulan LIKE '09'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalsep=$data['total'];
							}
							?>								
					   												<?php echo "$totalsep"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'oktober' OR bulan LIKE '10'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalokt=$data['total'];
							}
							?>								
					   												<?php echo "$totalokt"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'november' OR bulan LIKE '11'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalnov=$data['total'];
							}
							?>								
					   												<?php echo "$totalnov"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_masuk, SUM(jumlah) AS total FROM `jurnal_masuk` GROUP BY bulan LIKE 'desember' OR bulan LIKE '12'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaldes=$data['total'];
							}
							?>								
					   												<?php echo "$totaldes"; ?>],
					        showInLegend: false
					    }]

					});


					
					$('#inverted0').click(function () {
					    chart.update({
					        chart: {
					            inverted: true,
					            polar: false
					        },
					        credits: {
                             enabled: false
                            },
					        subtitle: {
					            text: 'Grafik Batang'
					        }
					    });
					});

					$('#polar0').click(function () {
					    chart.update({
					        chart: {
					            inverted: false,
					            polar: true
					        },
					        credits: {
                             enabled: false
                            },
					        subtitle: {
					            text: 'Grafik Lingkaran'
					        }
					    });
					});
					
				</script>

				

				<style>
				#container {
				 height: auto; 
				}

				.highcharts-figure, .highcharts-data-table table {
				    min-width: 50px; 
				    max-width: 1100px;
				    margin: 0em;
				}

				.highcharts-data-table table {
				    font-family: Verdana, sans-serif;
				    border-collapse: collapse;
				    border: 1px solid #EBEBEB;
				    margin: 10px auto;
				    text-align: center;
				    width: 100%;
				    max-width: auto;
				}
				.highcharts-data-table caption {
				    padding: 1em 0;
				    font-size: 1.2em;
				    color: #555;
				}
				.highcharts-data-table th {
					font-weight: 600;
				    padding: 0.5em;
				}
				.highcharts-data-table td, .highcharts-data-table th, .highcharts-data-table caption {
				    padding: 0.5em;
				}
				.highcharts-data-table thead tr, .highcharts-data-table tr:nth-child(even) {
				    background: #f8f8f8;
				}
				.highcharts-data-table tr:hover {
				    background: #f1f7ff;
				}                  
				
				</style>

			</div>
		</div>

</div>
</div>


<div class="main-grid">
<div class="agile-grids">
	<div class="w3l-chart events-chart">
			<h3>PENGELUARAN BULANAN</h3>
			<div class="events-chart-info">

				<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
				<script src="https://code.highcharts.com/highcharts.js"></script>
				<script src="https://code.highcharts.com/highcharts-more.js"></script>
				<script src="https://code.highcharts.com/modules/exporting.js"></script>
				<script src="https://code.highcharts.com/modules/export-data.js"></script>
				<script src="https://code.highcharts.com/modules/accessibility.js"></script>


				<figure class="highcharts-figure">
				    <div id="containerkeukeluar"></div><!-- 
				    <button id="inverted1">Grafik Batang</button>
				    <button id="polar1">Grafik Lingkaran</button> -->
				</figure>


				<script>
					var chart = Highcharts.chart('containerkeukeluar', {

					    title: {
					        text: 'Tabel Kas Keluar'
					    },

					    subtitle: {
					        text: 'Data Pengeluaran'
					    },
					    
					    credits: {
                             enabled: false
                            },

					    xAxis: {
					        categories: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Augustus', 'September', 'Oktober', 'November', 'Desember']
					    },
					    

					    series: [{
					        type: 'column',
					        colorByPoint: true,
					        data: [<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'januari' OR bulan LIKE '01'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaljan=$data['total'];
							}
							?>								
					   												<?php echo "$totaljan"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'februari' OR bulan LIKE '02'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalfeb=$data['total'];
							}
							?>								
					   												<?php echo "$totalfeb"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'maret' OR bulan LIKE '03'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalmar=$data['total'];
							}
							?>								
					   												<?php echo "$totalmar"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'april' OR bulan LIKE '04'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalapr=$data['total'];
							}
							?>								
					   												<?php echo "$totalapr"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'mei' OR bulan LIKE '05'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalmei=$data['total'];
							}
							?>								
					   												<?php echo "$totalmei"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'juni' OR bulan LIKE '06'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaljuni=$data['total'];
							}
							?>								
					   												<?php echo "$totaljuni"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'juli' OR bulan LIKE '07'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaljul=$data['total'];
							}
							?>								
					   												<?php echo "$totaljul"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'agustus' OR bulan LIKE '08'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalagustus=$data['total'];
							}
							?>								
					   												<?php echo "$totalagustus"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'september' OR bulan LIKE '09'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalsep=$data['total'];
							}
							?>								
					   												<?php echo "$totalsep"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'oktober' OR bulan LIKE '10'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalokt=$data['total'];
							}
							?>								
					   												<?php echo "$totalokt"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'november' OR bulan LIKE '11'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totalnov=$data['total'];
							}
							?>								
					   												<?php echo "$totalnov"; ?>, 

					   												<?php 
			   													
							$sql = $koneksi->query("SELECT tanggal_kredit, SUM(jumlah_kredit) AS total FROM `jurnal_keluar` GROUP BY bulan LIKE 'desember' OR bulan LIKE '12'");
							
							while ($data=$sql->fetch_assoc()) 
							{
							?>
				   												
								<?php $totaldes=$data['total'];
							}
							?>								
					   												<?php echo "$totaldes"; ?>],
					        showInLegend: false
					    }]

					});


					
					$('#inverted1').click(function () {
					    chart.update({
					        chart: {
					            inverted: true,
					            polar: false
					        },
					        credits: {
                             enabled: false
                            },
					        subtitle: {
					            text: 'Grafik Batang'
					        }
					    });
					});

					$('#polar1').click(function () {
					    chart.update({
					        chart: {
					            inverted: false,
					            polar: true
					        },
					        credits: {
                             enabled: false
                            },
					        subtitle: {
					            text: 'Grafik Lingkaran'
					        }
					    });
					});
					
				</script>

				

				<style>
				#containerkeukeluar {
				 height: auto; 
				}

				.highcharts-figure, .highcharts-data-table table {
				    min-width: 50px; 
				    max-width: 1100px;
				    margin: 0em;
				}

				.highcharts-data-table table {
				    font-family: Verdana, sans-serif;
				    border-collapse: collapse;
				    border: 1px solid #EBEBEB;
				    margin: 10px auto;
				    text-align: center;
				    width: 100%;
				    max-width: auto;
				}
				.highcharts-data-table caption {
				    padding: 1em 0;
				    font-size: 1.2em;
				    color: #555;
				}
				.highcharts-data-table th {
					font-weight: 600;
				    padding: 0.5em;
				}
				.highcharts-data-table td, .highcharts-data-table th, .highcharts-data-table caption {
				    padding: 0.5em;
				}
				.highcharts-data-table thead tr, .highcharts-data-table tr:nth-child(even) {
				    background: #f8f8f8;
				}
				.highcharts-data-table tr:hover {
				    background: #f1f7ff;
				}
				
				</style>

			</div>
		</div>

</div>
</div>
		








 


			



