<?php
include "conroom.php";
?>

	 <div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
						
	  					<form id="form" role="form" method="post" action="">
                <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                     <h2>DATA POLI/UMUM/LAINNYA</h2>
                </div>

                	<div class="wow fadeInUp" data-wow-delay="0.8s" >
                     
                          <label for="nama_tujuan">Poli Tujuan/ Umum/ Lainnya</label><br>
                          <input type="text" class="form-control" name="nama_tujuan" placeholder="...." required>
                    		<br>

                    		<label for="gedung">Letak Ruangan (Nama Gedung)</label><br>
                          <input type="text" class="form-control" name="gedung" placeholder="biarkan kosong jika tidak diisi">
                    		<br>

                        <div>
                        <button type="submit" name="input" class="btn btn-primary" >Input </button>
        
                        <button type="reset" name="reset" class="btn btn-primary">Reset </button>
                      </div>
                </div>
              </form>
            </div>
          </div>
        </div>

  

  <?php     
    include "conroom.php";  
    if(isset($_POST['input'])) {
    $nama_tujuan = htmlspecialchars($_POST['nama_tujuan']);
    $gedung= htmlspecialchars($_POST['gedung']);

    $cekdulu= "select * from tujuan_pasien where nama_tujuan='$_POST[nama_tujuan]'"; 
    $prosescek= mysqli_query($koneksi, $cekdulu);
    if (mysqli_num_rows($prosescek)>0) { //proses mengingatkan data sudah ada
      echo "<script>alert('$nama_tujuan sudah di input'); </script>";
    } else {
    // Insert user data into table
    $result = mysqli_query($koneksi, "INSERT INTO tujuan_pasien (nama_tujuan,gedung) VALUES('$nama_tujuan','$gedung')"); 

    echo "<script>alert('input data berhasil'); </script>";
    }
    
    }
  ?>