




	
	       
        <div class="main-grid">
            <div class="agile-grids">   
                <div class="grids">
                    <div class="progressbar-heading grids-heading">
                    </div>
                    <div class="panel panel-widget forms-panel">
                        <br>
                        <h2 style="color: black; text-align: center;">AKUN PENGGUNA</h2>
                        <br>
                        <div class="forms">
                            <div class="form-grids widget-shadow" data-example-id="basic-forms"> 
                                    	<div class="form-title">
                                            <form action="#" method="post">
												<input type="text" name="kode" value="Cari Data User" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}" >
												<button class="button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
											</form>	
                                        </div>

                                        <div class="agile-tables">
                                            <div class="w3l-table-info">
                                               <table id="table" class="table table-bordered">
                                                <thead>
                                                  <tr style="background-color: orange">
													<th>No</th>
													<th>Nama User</th>
													<th>Username</th>
													<th>Password
													<br>
													<i>password dienkripsi, silahkan merubah password jika diperlukan</i>		
													</th>
													<th>Edit Data</th>
													</tr>
														<?php 
															$no=1;
															$sql = $koneksi->query("SELECT * FROM login ORDER BY nama ASC");
															while ($data=$sql->fetch_assoc()) {
														?>								
													<tr>
													 <td><?php echo $no++; ?></td>
													 <td><?php echo $data['nama']; ?></td>
													 <td><?php echo $data['username']; ?></td>
													 <td style="text-align: center"><i>xxxxxxxxxx</i></td>
													 <td><a href="?l=3&id=<?php echo $data['id'];?>">edit</a></td>
													</tr>
													<?php
													
													}
													?>
				
                                                </tbody>
                                              </table>
                                        </div>
                            </div>
                        </div>                            
                </div>
            </div>
        </div>
        <br>
        

        
		
	

	

