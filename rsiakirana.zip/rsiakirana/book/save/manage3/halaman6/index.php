<br>
<br>

<div class="container">	
		<br>
		<div class="col-md-3">
			<form action="adminrs.php?page=add" method="POST">
				<div class="form-group">
					<label>Jenis Arsip</label>
					<input class="form-control" type="text" name="jenis"  required>
				</div>
				
				<button name="save" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span>Buat Arsip</button>
				
			</form>
		</div>

		<div class="col-md-9">
			<div class="table-heading">
					<h2>ARSIP</h2>
				</div>
				<div class="agile-tables">
					<div class="w3l-table-info">

							<table id="table" class="table table-bordered">
								<thead>
									<tr style="background-color: orange">
										<th>Jenis Arsip</th>
										<th>Masuk Ke Arsip</th>
									</tr>
								</thead>
								<tbody>
									<?php
										require 'conn.php';
										$query = mysqli_query($conn, "SELECT * FROM `arsip`");
										while($fetch = mysqli_fetch_array($query)){
									?>
									<tr>
										<td><?php echo $fetch['jenis']?></td>
										<td>
											<a style="color:red" href="halaman6/arsip.php?jenis=<?= $fetch['jenis']?>">Pilih</a>
										</td>
									</tr>
									<?php
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
	</div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
