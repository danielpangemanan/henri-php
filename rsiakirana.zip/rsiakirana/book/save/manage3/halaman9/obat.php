<!-- <?php 
$host      = "localhost";
$user      = "root";
$password  = "";
$database  = "medkesne_rsudobat";
$koneksi   = mysqli_connect($host, $user, $password, $database);
?> -->

<?php
error_reporting(0);
 
define('host','[216.12.199.4]');  //ip address online server
define('user','[medkesne_rsud]');
define('password','[rsudprovsulut123]');
define('database', '[medkesne_rsudobat]');

$db1 = mysqli_connect($host, $user, $password, $database);


?>



<div class="main-grid">
	<div class="agile-grids">	
		
	<h3 style="text-align: center;">DATA OBAT</h3>
	<hr>
	<div class="table-responsive">
		<table class="table table-bordered">
		<thead>
		<tr style="background-color: orange">
			<td>Kode Obat</td>
		 	<td>Nama Obat</td>
		 	<td>Jenis Obat</td>
		 	<td>Keterangan</td>
		 	<td>Harga</td>
		</tr>
		</thead>							
		<tbody>
		<td>
		 	<?php
			        $query = "SELECT * FROM dataobat ORDER BY id_obat ASC";
			        $dewan1 = $db1->prepare($query);
			        $dewan1->execute();
			        $res1 = $dewan1->get_result();
 
			        if ($res1->num_rows > 0) {
				        while ($row = $res1->fetch_assoc()) {
				        	$kode_obt = $row['kode_obt'];
				            $nama_obt = $row['nama_obt'];
				            $jenis_obt = $row['jenis_obt'];
				            $satuan_obt = $row['satuan_obt'];
				            $harga_obt = $row['harga_obt'];
 
							echo "<tr>";
								echo "<td>".$kode_obt."</td>";
								echo "<td>".$nama_obt."</td>";
								echo "<td>".$jenis_obt."</td>";
								echo "<td>".$satuan_obt."</td>";
								echo "<td>".$harga_obt."</td>";
							echo "</tr>";
			    	} } else { 
			    		echo "<tr>";
			    			echo "<td colspan='5'>Tidak ada data ditemukan</td>";
			    		echo "</tr>";
			     	}
			    ?>
		</td>
		</tbody>
		</table>
	</div>
















<!-- 


		<div class="main-grid">
			<div class="agile-grids">	
				
			<h3 style="text-align: center;">DATA OBAT</h3>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th><a href="adminrmedis.php?page=addobt" class="label label-info">Tambah Obat</a></th>
				 <th>Kode</th>
				 <th>Nama Obat</th>
				 <th>Jenis Obat/ Kategori</th>
				 <th>Satuan</th>
				 <th>Harga</th>
				</tr>
					
				<?php
				
				  $sql="SELECT * FROM dataobat";

		          $hasil=mysqli_query($koneksi,$sql);
		          
		          while ($data = mysqli_fetch_array($hasil)) { 
				?>											
					
				<tr>
				 <td></td>
				 <td bgcolor="#ffffff"><?php echo $data['kode_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jenis_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['satuan_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo "Rp." . number_format($data['harga_obt']).",-"; ?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div> -->