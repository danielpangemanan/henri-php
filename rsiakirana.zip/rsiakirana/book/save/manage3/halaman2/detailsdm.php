	<?php
	include "koneksi.php";
	?>

	<?php
	  // Cek apakah parameter ID ada
	  if (isset($_GET['nis'])) {
		// jika ada ambil nilai id
		$nis = $_GET['nis'];
	  } else {
		// jika tidak ada redirect ke index.php
		//header('Location:akseslogin.php');
	  }
	 ?>

	<?php
	// query SQL menampilkan data dari table tbl_biodata
	$sql = "SELECT * FROM stafsdm WHERE nis='$nis'";
	// tampung data (dalam array) kedalam variable $biodata
	$biodata = mysqli_query($koneksi, $sql);
	// cek apakah $biodata nilai kosong atau tidak
	if (mysqli_num_rows($biodata) > 0) {
	// jika ada tampilkan kedalam tabel
	$m = mysqli_fetch_assoc($biodata);
	}?>


	  
<br>
			


<div class="row">
  <div class="col-md-4 columns">
    <p>
		<center>
			<h3><?php echo $m['nama']; ?></h3>
			<!-- <button><h6><a onclick="history.back(-1)">KEMBALI DATA SDM</a></h6></button> -->
			<hr>
      <img src="/rsiakirana/aksesadmin/manage1/filegambar/<?php echo $m['gambar'];?>" alt="" class="media-object" style="width:30%" style="height: auto">
		</center>
    </p>
  </div>



  <div class="col-md-2 agile-grid-right">
    
      <div class="area-grids-heading">
		<h3>DATA SDM</h3>
	  </div>
	  
		<p>NIP</p>
		<p>Pendidikan</p>
		<p>kompetensi</p>
		<p>Diklat</p>
    
  </div>
  
  <div class="col-md-4 agile-grid-left">
    
      <div class="area-grids-heading">
		  <br><br>
	  </div>
	  
		<p>:<?php echo $m['nis']; ?></p>
		<p>:<?php echo $m['pendidikan']; ?></p>
		<p>:<?php echo $m['kompetensi']; ?></p>
		<p>:<?php echo $m['diklat']; ?><br>
    
  </div>

 
<td><a href="/rsiakirana/aksesadmin/manage1/halaman2/delete.php?page=delete&nis=<?php echo $m['nis'];?>" class="label label-info" onclick="return confirm('DATA AKAN DIHAPUS?')">hapus data</a></td>
<br>
<td><a href="/rsiakirana/aksesadmin/manage1/halaman2/bar.php?page=bar&kode=<?php echo $m['nis'];?>" class="label label-info">cetak barcode</a></td>

</div>

<br><br><br><br><br>
   
			
			