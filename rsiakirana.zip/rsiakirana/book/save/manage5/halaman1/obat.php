

<


		<div class="main-grid">
			<div class="agile-grids">	
				
			<h3 style="text-align: center;">DATA OBAT</h3>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: white;">
				 <th>Kode</th>
				 <th>Nama Obat</th>
				 <th>Jenis Obat/ Kategori</th>
				 <th>Satuan</th>
				 <th>Harga</th>
				 <th style="background-color: lightblue;">Stok</th>
				</tr>
					
				<?php
				
				  $sql="SELECT * FROM dataobat";

		          $hasil=mysqli_query($koneksi,$sql);
		          
		          while ($data = mysqli_fetch_array($hasil)) { 
				?>											
					
				<tr>
				 <td bgcolor="#ffffff"><?php echo $data['kode_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jenis_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['satuan_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo "Rp." . number_format($data['harga_obt']).",-"; ?></td>
				 <td style="background-color: lightblue;"><?php echo $data['stok'];?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div>