
<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) {
			

			case 'addtujuan':
				include "halaman1/roompolilainnya.php";
				break;
			case 'datapoli':
				include "halaman1/dataroompolilainnya.php";
				break;

			case 'addp':
				include "halaman4/datapasien.php";
				break;
			case 'idpsn':
				include "halaman4/detailpasien.php";
				break;
			case 'idpsnedit':
				include "halaman4/detailpasien1.php";
				break;
			case 'datapasien':
				include "halaman4/pasien.php";
				break;
			case 'prosespasien':
				include "halaman4/pasienbaru.php";
				break;
			case 'psbaru':
				include "halaman4/prosespasienbaru.php";
				break;
			case 'prspasien':
				include "halaman4/pasienout.php";
				break;
			case 'rekpsn':
				include "halaman4/rekappasien.php";
				break;
			case 'outpsn':
				include "halaman4/pasienoutkeu.php";
				break;
			case 'outpsnkeu':
				include "halaman4/rekappasienkeu.php";
				break;
			case 'prkeupsn':
				include "halaman4/carikeuanganpsn.php";
				break;

			case 'dkt':
				include "halaman8/dokter.php";
				break;

			case 'obt':
				include "halaman9/obat.php";
				break;
			case 'addobt':
				include "halaman9/addobat.php";
				break;
			
				
				
				
				
			default:
				echo "<center>
				<div>
				<img src='images/maintenance.jpg'>
				</div>
				</center>";
				break;
		}
	}else{
		include "managermedis.php";
	}
 
	 ?>