



<!DOCTYPE html>
<html>
<head>
 <title>RSUD ARSIP</title>
 <style type="text/css">
 body {
  font-family: verdana;
  font-size: 12px;
 }
 a {
  text-decoration: none;
  color: #3050F3;
 }
 a:hover {
  color: #000F5E;
 } 
</style>
</head>
<body>
    
<?php
include_once("../koneksi.php");
$name = $_GET['name'];
$result = mysqli_query($koneksi, "SELECT * FROM data_file WHERE nama_file='$name' ");
?>

<h1>Detail PDF</h1>
<hr>
<b>Judul:</b> <?php echo $name;?> | <a href='/rsiakirana/aksesadmin/manage1/adminrs.php?page=arsip'> Kembali </a>
<hr>
 <embed src="file/<?php echo $name;?>.pdf" type="application/pdf" width="800" height="600" >
 
</body>
</html>