	

	<br>
	<div class="chart-heading">
		<h2>SUMBERDAYA MANUSIA</h2>
	</div>
	<br>
		
	<div class="container-fluid" class="col-md-12">

				<div class="col-md-6" >
				   <div class="table-responsive">
						
						<table class="table table-bordered" class="table-condensed" id="" style="background-color: white">
						  <thead>
							<tr>
							  <th>STAF</th>
							  <th>NIP</th>
							  <th>Nama</th>
							  <th>Kompetensi</th>
							  <th>Alamat</th>
							</tr>
						  </thead>

						  <?php
							include "koneksi.php";

							$sql = mysqli_query($koneksi,"SELECT * FROM stafsdm where kompetensi not like '%dokter%' AND kompetensi not like '%spesialis%' ");
							
							while($data = mysqli_fetch_array($sql)){
						   ?>

						  <tbody>
						  	<td></td>
						  	<td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=detailsdm&nis=<?php echo $data['nis'];?>" class="label label-info"><?php echo $data['nis'];?></a></td>
						  	<td><?php echo $data['nama'];?></td>
						  	<td><?php echo $data['kompetensi'];?></td>
						  	<td><?php echo $data['alamat'];?></td>
						  </tbody>
						  <?php } ?>
						</table>
						
				</div>
			</div>


			<div class="col-md-6" >
				   <div class="table-responsive">
						
						<table class="table table-bordered" class="table-condensed" id="" style="background-color: white;">
						  <thead>
							<tr>
							  <th>DOKTER</th>
							  <th>NIP</th>
							  <th>Nama</th>
							  <th>Kompetensi</th>
							  <th>Alamat</th>
							</tr>
						  </thead>

						  <?php
							include "koneksi.php";

							$sql = mysqli_query($koneksi,"SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%' OR kompetensi LIKE '%spesialis%' ");
							
							while($data = mysqli_fetch_array($sql)){
						   ?>

						  <tbody>
						  	<td></td>
						  	<td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=detailsdm&nis=<?php echo $data['nis'];?>" class="label label-info"><?php echo $data['nis'];?></a></td>
						  	<td><?php echo $data['nama'];?></td>
						  	<td><?php echo $data['kompetensi'];?></td>
						  	<td><?php echo $data['alamat'];?></td>
						  </tbody>
						  <?php } ?>
						</table>
						
				</div>
			</div>


	</div>
	<br>

