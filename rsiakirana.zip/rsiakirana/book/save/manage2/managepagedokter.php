
<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) {
			

			case 'addtujuan':
				include "header.php";
				include "halaman1/roompolilainnya.php";
				include "footer.php";
				break;
			case 'datapoli':
				include "header.php";
				include "halaman1/dataroompolilainnya.php";
				include "footer.php";
				break;

			case 'addp':
				include "header.php";
				include "halaman2/datapasien.php";
				include "footer.php";
				break;
			case 'src':
				include "header.php";
				include "halaman2/pencarian.php";
				include "footer.php";
				break;
			case 'idpsn':
				include "header.php";
				include "halaman2/detailpasien.php";
				include "footer.php";
				break;
			case 'idpsn1':
				include "header.php";
				include "halaman2/detailpasien1.php";
				include "footer.php";
				break;
			case 'datapasien':
				include "header.php";
				include "halaman2/pasien.php";
				include "footer.php";
				break;
			case 'prosespasien':
				include "header.php";
				include "halaman2/pasienbaru.php";
				include "footer.php";
				break;
			case 'psbaru':
				include "header.php";
				include "halaman2/prosespasienbaru.php";
				include "footer.php";
				break;
			case 'prspasien':
				include "header.php";
				include "halaman2/pasienout.php";
				include "footer.php";
				break;
			case 'rekpsn':
				include "header.php";
				include "halaman2/rekappasien.php";
				include "footer.php";
				break;
			case 'outpsn':
				include "header.php";
				include "halaman2/pasienoutkeu.php";
				include "footer.php";
				break;
			case 'outpsnkeu':
				include "header.php";
				include "halaman2/rekappasienkeu.php";
				include "footer.php";
				break;
			case 'prkeupsn':
				include "header.php";
				include "halaman2/carikeuanganpsn.php";
				include "footer.php";
				break;
			case 'psn1':
				include "header.php";
				include "halaman2/pasienrjalan.php";
				include "footer.php";
				break;
			case 'psn2':
				include "header.php";
				include "halaman2/pasienrinap.php";
				include "footer.php";
				break;
			case 'psn3':
				include "header.php";
				include "halaman2/pasienrgd.php";
				include "footer.php";
				break;

			case 'dkt':
				include "header.php";
				include "halaman3/dokter.php";
				include "footer.php";
				break;

			case 'obt':
				include "header.php";
				include "halaman4/obat.php";
				include "footer.php";
				break;
			case 'addobt':
				include "header.php";
				include "halaman4/addobat.php";
				include "footer.php";
				break;

			
			case 'dticd':
				include "header.php";
				include "halaman5/icd.php";
				include "footer.php";
				break;
				
				
				
				
			default:
				echo "<center>
				<div>
				<img src='images/maintenance.jpg'>
				</div>
				</center>";
				break;
		}
	}else{
		include "managedokter.php";
	}
 
	 ?>