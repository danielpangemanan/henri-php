<?php 
include "./koneksi.php";
?>

<div class="main-grid">
	<h3 style="text-align: center;">DATA OBAT</h3>
	<br>
	<div class="agile-grids">	
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th>APOTIK</th>
				 <th>Kode</th>
				 <th>Nama Obat</th>
				 <th>Jenis Obat/ Kategori</th>
				 <th>Satuan</th>
				 <th>Harga</th>
				</tr>
					
				<?php
				
				$sql = $koneksi->query("SELECT * FROM dataobat ORDER BY id_obat DESC");
				while ($data=$sql->fetch_assoc())
				{
				?>											
					
				<tr>
				 <td></td>
				 <td bgcolor="#ffffff"><?php echo $data['kode_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jenis_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['satuan_obt'];?></td>
				 <td bgcolor="#ffffff"><?php echo "Rp." . number_format($data['harga_obt']).",-"; ?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div>