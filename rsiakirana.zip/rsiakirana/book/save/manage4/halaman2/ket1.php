<?php
	include "koneksi.php";
	if (mysqli_connect_errno()) {
	    trigger_error('Koneksi ke database gagal: '  . mysqli_connect_error(), E_USER_ERROR); 
	}
?>
<br>
<div class="container">
<div class="row">
<div class="col-md- col-sm-8">
			 
<form name="form_stafsdm" action="" method="post" enctype="multipart/form-data">

  <div class="form-group">
    <label for="kompetensi">Kompetensi</label>
    <input type="text" class="form-control" id="kompetensi" placeholder="..." name="kompetensi">
  </div>

	

  <div class="form-group">
    <label for="keterangan">Tanggal Input</label>
    <input type="date" class="form-control" id="" placeholder="..." name="tanggal">
  </div>

  

  <div class="form-group">
  	 <br>
    <button type="submit" class="btn btn-primary" name="tambah">Input</button>

   	<a href="/rsudprovsulut/aksesadmin/manage1/dataentry" class="btn btn-danger">Batal</a>
  </div>
</form>
	
</div>
</div>
</div>
<br>
<br>

<?php
if(isset($_POST['tambah'])) {
$kompetensi = $_POST['kompetensi'];
$tanggal = $_POST['tanggal'];

$cekdulu= "select * from ket1 where kompetensi='$_POST[kompetensi]'"; 
$prosescek= mysqli_query($koneksi, $cekdulu);
if (mysqli_num_rows($prosescek)>0) { //proses mengingatkan data jika sudah ada
	echo "<script>alert('maaf $kompetensi sudah terdaftar......'); </script>";
} else {
// Insert user data into table
$query="INSERT INTO ket1 SET kompetensi='$kompetensi', tanggal='$tanggal'";
mysqli_query($koneksi, $query); 
}
// echo "<script>alert('Data Berhasil ditambahkan');window.location=''</script>";
}
?>

