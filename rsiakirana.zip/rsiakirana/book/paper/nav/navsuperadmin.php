		
		
		<ul>
			<li>
				<a href="page">
					<i class="fa fa-home nav_icon"></i>
					<span class="nav-text">
					Beranda
					</span>
				</a>
			</li>
			
			<li class="has-subnav">
				<a href="javascript:;">
					<i class="fa fa-bar-chart nav_icon"></i>
						<span class="nav-text">Dashbord Super Admin</span>
					<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
						<a class="subnav-text" href="?l=l-admin">
							Modul Admin
						</a>
					</li>
										
					<li>
						<a class="subnav-text" href="?l=l-admisi">
							Modul Admisi
						</a>
					</li>

					<li>
						<a class="subnav-text" href="?l=l-rmedis">
							Modul Rekam Medis
						</a>
					</li>

					<li>
						<a class="subnav-text" href="?l=l-apotik">
							Modul Apotik
						</a>
					</li>

					<li>
						<a class="subnav-text" href="?l=l-keukasir">
							Modul Kasir
						</a>
					</li>

					<li>
						<a class="subnav-text" href="?l=l-medis">
							Modul Perawat/Dokter
						</a>
					</li>

					<li>
						<a class="subnav-text" href="?l=l-spv">
							Modul SPV 
						</a>
					</li>

					<li>
						<a class="subnav-text" href="?l=l-pim">
							Modul Pimpinan
						</a>
					</li>
					
				</ul>
			</li>
			
			
			<li class="has-subnav">
				<a href="javascript:;">
					<i class="fa fa-list-ul" aria-hidden="true"></i>
					<span class="nav-text">Pengaturan</span>
					<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
						<a class="subnav-text" href="?l=2">Akun Login</a>
					</li>
				</ul>
			</li>
			<li class="has-subnav">
				<a href="adminrs?page=arsip">
					<i class="fa fa-file-text-o nav_icon" aria-hidden="true"></i>
					<span class="nav-text">Arsip</span>
					<i class=""></i><i class=""></i>
				</a>
				
				<li class="has-subnav">
				<a href="javascript:;">
					<i class="fa fa-check-square-o nav_icon" aria-hidden="true"></i>
					<span class="nav-text">Input Data</span>
					<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
						<a class="subnav-text" href="?l=1">Modul Input Data</a>
					</li>
					<li>
						<a class="subnav-text" href="?page=up">Modul Import Data</a>
					</li>
				</ul>
			</li>
			</li>
			</li>
			<li>
			<a href="/rsiakirana/index.php">
			<i class="icon-off nav-icon"></i>
			<span class="nav-text">
			Keluar
			</span>
			</a>
			</li>
			
		</ul>