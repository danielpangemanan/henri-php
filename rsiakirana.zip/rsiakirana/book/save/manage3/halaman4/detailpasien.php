
<?php

	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = "select * from tbl_pasien where no_rekamedis='$no'";
	$result = mysqli_query($koneksi,$sql);
	}
	while($data = mysqli_fetch_array($result))
	{
		
?>

<br>
<div class="container-fluid" class="col-md-12">
	
<div class="container-fluid">
   		<div class="table-responsive">
			<form method="POST">
				<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">
					<thead>
					<tr>
						<th><h3 class="th1" style="text-align: center">RSIA-KIRANA</h3></th>
						<th><h3 class="th1" style="text-align: center">REKAM MEDIS PASIEN</h3></th>
						<th></th>
					</tr>
		   			<tr>
						<th><center>DATA PASIEN</center></th>
						<th><center>KETERANGAN</center></th>
						<th><center>PROSES PASIEN</center></th>
					</tr>
				   </thead>

				   <tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">
						<td>Nomor Rekamedis</td>
						<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>

					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">
						<td>Nomor Induk Kependudukan</td>
						<td><?php echo $data['nik']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="ruangan" required>
						        <option value=''>Tindakan Pasien Rawat...</option>
						        <option value="Pasien Rawat Jalan">Pasien Rawat Jalan</option>
								<option value="Pasien Rawat Inap dan Perawatan">Pasien Rawat Inap dan Perawatan</option>
								<option value="Pasien Gawat Darurat">Pasien Gawat Darurat</option>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nama_pasien" value="<?php echo $data['nama_pasien'];?>">
						<td>Nama Pasien</td>
						<td><?php echo $data['nama_pasien']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="dokter_lain">
						        <option value='-'>Dokter lain/Tambahan...</option>
						          <?php
						         						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%'";

						          $hasil=mysqli_query($koneksi,$sql);
						          
						          while ($dokter1 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?>"><?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="jenis_kelamin" value="<?php echo $data['jenis_kelamin'];?>">
						<td>Jenis Kelamin</td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="triage" required>
						        <option value=''>Triage Pasien...</option>
						        <option value="Merah">Merah</option>
								<option value="Kuning">Kuning</option>
								<option value="Hijau">Hijau</option>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="golongan_darah" value="<?php echo $data['golongan_darah'];?>">
						<td>Golongan Darah</td>
						<td><?php echo $data['golongan_darah']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="ruang_inap">
						        <option value='belum di isi'>Ruang Inap Pasien</option>
						          <?php
						         						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="SELECT * FROM ruangan ORDER BY id_ruangan";

						          $hasil=mysqli_query($koneksi,$sql);
						          
						          while ($ruanginap = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $ruanginap['nama'];?>"><?php echo $ruanginap['nama'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="tempat_lahir" value="<?php echo $data['tempat_lahir'];?>">
						<input type="hidden" class="form-control" name="tanggal_lahir" value="<?php echo $data['tanggal_lahir'];?>">
						<td>Tempat, Tanggal Lahir</td>
						<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="alamat" value="<?php echo $data['alamat'];?>">
						<td>Alamat</td>
						<td><?php echo $data['alamat']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nama_ibu" value="<?php echo $data['nama_ibu'];?>">
						<td>Nama Ibu Kandung</td>
						<td><?php echo $data['nama_ibu']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="agama" value="<?php echo $data['agama'];?>">
						<td>Agama</td>
						<td><?php echo $data['agama']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Status</td>
						<td><input style="border: none;" type="text" class="form-control" name="status_menikah" value="<?php echo $data['status_menikah'];?>"></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Telp/Hp</td>
						<td><input style="border: none;" type="text" class="form-control" name="no_hp" value="<?php echo $data['no_hp'];?>"></td>
					</tr>
				   	</tbody>

				   	
				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pekerjaan</td>
						<td><input style="border: none;" type="text" class="form-control" name="id_pekerjaan" value="<?php echo $data['id_pekerjaan'];?>"></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pembiayaan</td>
						<td>
							<select style="border: none;" name="pembiayaan" class="form-control" name="pembiayaan" required>
								<option value="<?php echo $data['pembiayaan'];?>"><?php echo $data['pembiayaan'];?></option>
								<option value="Mandiri">Mandiri</option>
								<option value="BPJS">BPJS</option>
							</select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Ruang Penanganan Pasien</td>
						<td>
						<select style="border: none;" class="form-control" name="tujuan" required>
					        <option value='<?php echo $data['tujuan'];?>'><?php echo $data['tujuan'];?></option>
					          <?php
					       					        
					         //Perintah sql untuk menampilkan semua data pada tabel 
					          $sql="select * from tujuan_pasien";

					          $hasil=mysqli_query($koneksi,$sql);
					          
					          while ($ptujuan = mysqli_fetch_array($hasil)) {
					          
					         ?>
					          <option value="<?php echo $ptujuan['nama_tujuan'];?>"><?php echo $ptujuan['nama_tujuan'];?></option>
					        <?php 
					        }
					        ?>
					    </select>
					</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Registrasi</td>
						<?php
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi, "select id_registrasi from tbl_pasien where no_rekamedis='$no' order by id desc limit 1");		
							
							while($datareg = mysqli_fetch_array($sql)){					
	
						?>
						<td><input style="border: none;" type="text" class="form-control" name="id_registrasi" value="<?php echo $datareg['id_registrasi'];?>" required></td>
						<?php } ?>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Dokter</td>
						<td><select style="border: none;" class="form-control" name="dokter" required>
									        <option value='<?php echo $data['dokter'];?>'><?php echo $data['dokter'];?></option>
									          <?php
									         									        
									         //Perintah sql untuk menampilkan semua data pada tabel 
									          $sql="SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%'";

									          $hasil=mysqli_query($koneksi,$sql);
									          $no=0;
									          while ($data = mysqli_fetch_array($hasil)) {
									          $no++;
									         ?>
									          <option value="<?php echo $data['nama'];?>&nbsp:<?php echo $data['kompetensi'];?>"><?php echo $data['nama'];?>&nbsp:<?php echo $data['kompetensi'];?></option>
									        <?php 
									        }
									        ?>
									    </select></td>
					</tr>
				   	</tbody>
				   	
				 	</table>
				 	<div>
						<button type="submit" name="input" class="btn btn-primary" >Proses</button>
						<!-- <a class="btn btn-primary" href="/aksesadmin/manage1/halaman4/printbarcode.php?page=printbarcode&kode=<?php echo $data['no_rekamedis'];?>" role="button">Print</a> -->
					</div>
				 </form>
				
		</div>
	</div>
</div>
<hr>
<?php } ?>



 <?php

 	

	  if(isset($_POST['input'])) {
	  	$id_registrasi=$_POST['id_registrasi'];
	  	$no_rekamedis=$_POST['no_rekamedis'];
		$nik= $_POST['nik'];
		$nama_pasien=$_POST['nama_pasien'];
		$jenis_kelamin=$_POST['jenis_kelamin'];
		$golongan_darah=$_POST['golongan_darah'];
		$tempat_lahir=$_POST['tempat_lahir'];
		$tanggal_lahir=$_POST['tanggal_lahir'];
		$nama_ibu=$_POST['nama_ibu'];
		$alamat=$_POST['alamat'];
		$agama=$_POST['agama'];
		$status_menikah=$_POST['status_menikah'];
		$no_hp=$_POST['no_hp'];
		$id_pekerjaan=$_POST['id_pekerjaan'];
		$dokter=$_POST['dokter'];
		$tujuan=$_POST['tujuan'];
		$pembiayaan=$_POST['pembiayaan'];
		$ruangan=$_POST['ruangan'];
		$dokter_lain=$_POST['dokter_lain'];
		$triage=$_POST['triage'];
		$ruang_inap=$_POST['ruang_inap'];

		// Insert user data into table
		$input = mysqli_query($koneksi, "INSERT INTO tbl_pasien1 (id_registrasi,no_rekamedis,nik,nama_pasien,jenis_kelamin,golongan_darah,tempat_lahir,tanggal_lahir,nama_ibu,alamat,agama,status_menikah,no_hp,id_pekerjaan,dokter,tujuan,pembiayaan,ruangan,dokter_lain,triage,ruang_inap) VALUES('$id_registrasi','$no_rekamedis','$nik','$nama_pasien','$jenis_kelamin','$golongan_darah','$tempat_lahir','$tanggal_lahir','$nama_ibu','$alamat','$agama','$status_menikah','$no_hp','$id_pekerjaan','$dokter','$tujuan','$pembiayaan','$ruangan','$dokter_lain','$triage','$ruang_inap')"); 
		  		
		echo "<script>alert('data pasien $nama_pasien akan diproses || dengan Triage: $triage');window.location='/rsiakirana/aksesadmin/manage3/adminrmedis.php?page=datapasien'</script>";
		
	  }
	?>
	




				


