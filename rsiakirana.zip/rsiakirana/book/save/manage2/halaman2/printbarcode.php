

<?php
	include "koneksibarcode.php";

	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien where no_rekamedis='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<center>
<div class="container-fluid" class="col-md-12">
	
<div class="container-fluid">
   		<div class="table-responsive">
		
				<table class="table  table-bordered" class="table-condensed" id="">
					<thead>
					<tr>
						<th><center><img src="images/logo.png"></center></th>
						<th><h3 style="text-align: center">REKAM MEDIS PASIEN</h3></th>
						<th></th>
					</tr>
		   			<tr>
						<th><center>DATA PASIEN</center></th>
						<th><center>KETERANGAN</center></th>
						<th></th>
					</tr>
				   </thead>

				   <tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Rekamedis</td>
						<td style="text-align: center"><?php echo $data['no_rekamedis']; ?></td>
						<td><strong>Dokter:&nbsp<?php echo $data['dokter']; ?></strong></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Induk Kependudukan</td>
						<td><?php echo $data['nik']; ?></td>
						<td><?php echo bar128(stripslashes($data['no_rekamedis'])); ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Pasien</td>
						<td><?php echo $data['nama_pasien']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Jenis Kelamin</td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Golongan Darah</td>
						<td><?php echo $data['golongan_darah']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Tempat, Tanggal Lahir</td>
						<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Alamat</td>
						<td><?php echo $data['alamat']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Ibu Kandung</td>
						<td><?php echo $data['nama_ibu']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Agama</td>
						<td><?php echo $data['agama']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Status</td>
						<td><?php echo $data['status_menikah']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Telp/Hp</td>
						<td><?php echo $data['no_hp']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pekerjaan</td>
						<td><?php echo $data['id_pekerjaan']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pembiayaan</td>
						<td><?php echo $data['pembiayaan']; ?></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Ruang Penanganan Pasien</td>
						<td><?php echo $data['tujuan']; ?></td>
					</tr>
				   	</tbody>
				   	
				 	</table>
				<?php } ?>
		</div>
	</div>
</div>
</center>

	<hr><center>
		<button><a class="btn btn-primary" href="/rsudprovsulut/aksesadmin/manage1/.." role="button">KEMBALI</a></button>
	</center><hr><br>




	




<!-- <?php 
$host       = "localhost";
$user       = "medkesne_rsud";
$password   = "rsudprovsulut123";
$database   = "medkesne_rsudsdm1";
$koneksi    = mysqli_connect($host, $user, $password, $database);
?>



<?php
include('bar128.php');
$sql = $koneksi->query("select *from tbl_pasien order by no_rekamedis desc limit 1");
while ($data=$sql->fetch_assoc())
{
?>

	
	<?php
	}
	?>
	

<br>
<form method="get">
	<label>Masukkan Nomor Rekamedis</label>
	<input type="text" name="no_rekamedis">
	<input type="submit" value="cari">
</form>
<hr>

<?php 
																	
																	
	if(isset($_GET['no_rekamedis'])){
		$pasien = $_GET['no_rekamedis'];
		$sql = mysqli_query($koneksi,"select * from tbl_pasien where no_rekamedis='$pasien'");
	}else{
		$sql = mysqli_query($koneksi,"select * from tbl_pasien order by no_rekamedis desc limit 1");
	}
	while($data = mysqli_fetch_array($sql)){
	?>
<?php echo $data['nama_pasien']; ?><br>
<?php echo bar128(stripslashes($data['no_rekamedis'])); ?>
<?php } ?>



<button><a href="/aksesadmin/manage1/adminrmedis.php">Selesai</a></button> -->				


