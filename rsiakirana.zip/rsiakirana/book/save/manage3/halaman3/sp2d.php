<?php
include "conkeu.php";
?>

<br>
<br>
	<section class="">
			<center><img src="/aksesadmin/manage1/halaman3/images/logokemenkes.jpg"></center>
				<center><h4>SURAT PERINTAH PENCAIRAN DANA</h4></center>
			<center><h4>RSUD PROVINSI SULUT</h4></center>
			
			<hr>
																	
						
      <div class="accordion" id="accordionExample">
        <div class="card">
          <div class="card-header" id="headingOne">
            <h2 class="mb-0">
              <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                PERSYARATAN SP2D
              </button>
            </h2>
          </div>

          <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
              Membawa Surat Perintah membayar SPM & 
      		Membawa Surat Perintah Pembayaran SPP
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header" id="headingTwo">
            <h2 class="mb-0">
              <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                SISTEM, MEKANISME, PROSEDUR
              </button>
            </h2>
          </div>
          <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
            <div class="card-body">
              1. PA menandatangani SPM sebagai syarat pengajuan SP2D dan menugaskan Bendahara Pengeluaran SKPDuntuk menyerahakan kepada BUD 2. Kepala BPKA (BUD) menerima SPM yang diajukan oleh PA SKPD untuk didisposisi kepada Kabid Perbendaharaan (Kuasa BUD) 3. Kabid.Perbendaharaan menerima disposisi dari kepala BPKA dan mendisposisi kembali kepada Kasubid. Belanja dan Pembiayaan untuk diverifikasi kelengkapan dokumen (SPM dan SPP) Hal-hal yang harus diperhatikan oleh Kasubid Belanja dan Pembiayaan : • DPA SKPD • Format lembar verifikasi • Format SP2D Setelah diverifikasi menerbitkan dan memaraf SP2D untuk diserahkan kepada Kabid Perbendaharaan (Kuasa BUD) untuk di tandatangani 4. Kabid Perbendaharaan (Kuasa BUD) memeriksa dokumen beserta kelengkapannya dan menadatangani SP2D 5. Kabid Perbendaharaan (Kuasa BUD) setelah menadatangan SP2D menyerahkan kembali ke Kasubid. Belanja dan Pembiayaan untiserahkan kepada SKPD melalui Bendahara Pengeluaran SKPD
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header" id="headingThree">
            <h2 class="mb-0">
              <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                BERKAS-BERKAS
              </button>
            </h2>
          </div>
          <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
            <div class="card-body">
              Surat Perintah Pencairan Dana (SP2D)
            </div>
          </div>
        </div>
      			
		</section>

	
	




