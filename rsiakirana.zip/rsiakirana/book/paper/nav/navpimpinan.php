		
		
		<ul>
			<li>
				<a href="page">
					<i class="fa fa-home nav_icon"></i>
					<span class="nav-text">
					Beranda
					</span>
				</a>
			</li>
			
			<li class="has-subnav">
				<a href="javascript:;">
					<i class="fa fa-bar-chart nav_icon"></i>
						<span class="nav-text">Dashbord Pimpinan</span>
					<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
						<a class="subnav-text" href="?page=sdm">
							SDM/DOKTER
						</a>
					</li>
										
					<li>
						<a class="subnav-text" href="">
							Layanan
						</a>
					</li>
					
				</ul>
			</li>
			
			
			<li class="has-subnav">
				<a href="javascript:;">
					<i class="fa fa-list-ul" aria-hidden="true"></i>
					<span class="nav-text">Pengaturan</span>
					<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
						<a class="subnav-text" href="?page=admin">Akun Login</a>
					</li>
				</ul>
			</li>
			<li class="has-subnav">
				<a href="adminrs?page=arsip">
					<i class="fa fa-file-text-o nav_icon" aria-hidden="true"></i>
					<span class="nav-text">Arsip</span>
					<i class=""></i><i class=""></i>
				</a>
				<li class="has-subnav">
				<a href="javascript:;">
					<i class="icon-table nav-icon" aria-hidden="true"></i>
					<span class="nav-text">Rekam Medis</span>
					<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
						<a class="subnav-text" href="/rsiakirana/aksesadmin/manage1/adminrmedis.php">Modul Rekam Medis</a>
					</li>
				</ul>
				<li class="has-subnav">
				<a href="javascript:;">
					<i class="fa fa-check-square-o nav_icon" aria-hidden="true"></i>
					<span class="nav-text">Input Data</span>
					<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
						<a class="subnav-text" href="?l=1">Modul Input Data</a>
					</li>
					<li>
						<a class="subnav-text" href="?page=up">Modul Import Data</a>
					</li>
				</ul>
			</li>
			</li>
			</li>
			<li>
			<a href="/rsiakirana/index.php">
			<i class="icon-off nav-icon"></i>
			<span class="nav-text">
			Keluar
			</span>
			</a>
			</li>
			
		</ul>