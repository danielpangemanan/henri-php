






	
	       
        <div class="main-grid">
            <div class="agile-grids">   
                <div class="grids">
                    <div class="panel panel-widget forms-panel">
                        <br>
                        <h2 style="color: black; text-align: center;">PENDAFTARAN PASIEN</h2>
                        <br>
                        <div class="forms">
                            <div class="form-grids widget-shadow" data-example-id="basic-forms"> 
                                    	<div class="form-title">
                                            <h4>PASIEN BARU</h4>
                                            <a>pendaftaran pasien baru</a>
                                        </div>
                                <div class="agile-tables">
                                    <div class="w3l-table-info">
										<div class="container">
			  							
										
										<div class="col-md-6">
										<form id="form" role="form" method="post" action="">
                              
                                   		<label for="no_rekamedis">Nomor Rekam Medis</label><br>
                                   		<?php
									          
									          $sql="SELECT MAX(no_rekamedis) AS no_rekamedis FROM tbl_pasien ";

									          $hasil=mysqli_query($koneksi,$sql);
									          while ($psn = mysqli_fetch_array($hasil)) {
									           $nmrek=$psn['no_rekamedis'];
									           $rekmnomor = sprintf("%05d", $nmrek+1);
									           
									        ?>
                                        
                                        <input type="text" class="form-control" name="no_rekamedis" readonly value="<?php echo $rekmnomor;?>" required>
                                  		<br>
                                  		<?php } ?>

                                  		<label for="id_registrasi">Nomor Registrasi</label><br>
                                  		<?php
									         
									          $sql="SELECT MAX(id_registrasi) AS id_registrasi FROM tbl_pasien ";

									          $hasil=mysqli_query($koneksi,$sql);
									          while ($psn = mysqli_fetch_array($hasil)) {
									           $nmreg=$psn['id_registrasi'];
									           $nmreg++;
									        ?>
                                        <input type="text" class="form-control" name="id_registrasi" readonly value="<?php echo $nmreg;?>" required>
                                  		<br>
                                  		<?php } ?>

                                  		<label for="nik">NIK (sesuai dengan KTP)</label><br>
                                        <input type="number" class="form-control" name="nik" placeholder="...." required>
                                  		<br>

                                  		<label for="nama_pasien">Nama Pasien</label><br>
                                        <input type="text" class="form-control" name="nama_pasien" value="<?php echo $data['nama_pasien'];?>" required>
                                  		<br>
										
										
                                  		<label for="jenis_kelamin">Jenis Kelamin</label>
										<select name="jenis_kelamin" class="form-control" name="jenis_kelamin" required>
											<option value="<?php echo $data['jenis_kelamin'];?>"><?php echo $data['jenis_kelamin'];?></option>
											<option value="Laki-laki">Laki-laki</option>
											<option value="Perempuan">Perempuan</option>
											<option value="Tidak Diketahui">Tidak Diketahui</option>
										</select>
									    <br>
                                   
                                        <label for="golongan_darah">Golongan Darah</label><br>
                                        <input type="text" class="form-control" name="golongan_darah" placeholder="...."required>
                                  		<br>

                                  		<label for="tempat_lahir">Tempat Lahir</label><br>
                                        <input type="text" class="form-control" name="tempat_lahir" placeholder="...."required>
                                  		<br>

                                  		<label for="tanggal_lahir">Tanggal Lahir</label><br>
                                        <input type="date" class="form-control" name="tanggal_lahir" placeholder="...."required>
                                  		<br>

                                  		<label for="nama_ibu">Nama Ibu Kandung</label><br>
                                        <input type="text" class="form-control" name="nama_ibu" placeholder="...."required>
                                  		<br>

                                  		<label for="alamat">Alamat</label><br>
                                        <input type="text" class="form-control" name="alamat" value="<?php echo $data['alamat'];?>" required>
                                  		<br>
                                  		<br><br>
                      					</div>
				        
						
										<div class="col-md-6">
                                        <label for="agama">Agama</label>
										<select name="agama" class="form-control" name="agama" required>
											<option value="Kristen Protestan">Kristen Protestan</option>
											<option value="Islam">Islam</option>
											<option value="Katolik">Katolik</option>
											<option value="Hindu">Hindu</option>
											<option value="Buddha">Buddha</option>
											<option value="Kong Hu Cu">Kong Hu Cu</option>
											<option value="Lainnya">Lainnya</option>
										</select>
									    <br>

									    <label for="status_menikah">Status</label><br>
                                        <select name="status_menikah" class="form-control" name="status_menikah" required>
											<option value="Kawin">Kawin</option>
											<option value="Belum Kawin">Belum Kawin</option>
											<option value="Janda">Janda</option>
											<option value="Duda">Duda</option>
											<option value="Lainnya">Lainnya</option>
										</select>
                                  		<br>

                                  		<label for="no_hp">No. Telp/HP</label><br>
                                        <input type="number" class="form-control" name="no_hp" placeholder="...."required>
                                  		<br>

                                  		<label for="id_pekerjaan">Pekejaan</label><br>
                                        <input type="text" class="form-control" name="id_pekerjaan" placeholder="...."required>
                                  		<br>

                                  		<label for="dokter">Dokter</label><br>
                                        <select class="form-control" name="dokter">
									        <option value=''>..:::..</option>
									          <?php
									         
									        
									         //Perintah sql untuk menampilkan semua data pada tabel 
									          $sql="SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%'";

									          $hasil=mysqli_query($koneksi,$sql);
									          
									          while ($dokter1 = mysqli_fetch_array($hasil)) {
									          
									         ?>
									          <option value="<?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?>"><?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?></option>
									        <?php 
									        }
									        ?>
									    </select>
                                  		<br>

                                  		<label for="tujuan">Poli Tujuan/ Umum/ Lainnya</label>
										<select class="form-control" name="tujuan" required>
									        <option value=''>..:::..</option>
									          <?php
									        
									        
									         //Perintah sql untuk menampilkan semua data pada tabel 
									          $sql="select * from tujuan_pasien";

									          $hasil=mysqli_query($koneksi,$sql);
									          
									          while ($ptujuan = mysqli_fetch_array($hasil)) {
									          
									         ?>
									          <option value="<?php echo $ptujuan['nama_tujuan'];?>"><?php echo $ptujuan['nama_tujuan'];?></option>
									        <?php 
									        }
									        ?>
									    </select>
									    <br>

                                  		<label for="pembiayaan">Pembiayaan</label>
										<select name="pembiayaan" class="form-control" name="pembiayaan" required>
											<option value="Mandiri">Mandiri</option>
											<option value="BPJS">BPJS</option>
										</select>
									    <br>

									   <div>
											<button type="submit" name="input" class="btn btn-primary" >Input </button>
			
											<button type="reset" name="reset" class="btn btn-primary">Reset </button>
										</div>
  										</form>
                             			</div>
                             			

										</div>
                            		</div>
                        		</div>

                			</div>
            			</div>
        			</div>
            	</div>
            </div>
        </div>
        <br>
        

        
		
	


        
 
						
	  					
	  <?php

	  if(isset($_POST['input'])) {
	  	$id_registrasi= $_POST['id_registrasi'];
		$no_rekamedis= $_POST['no_rekamedis'];
		$nik= $_POST['nik'];
		$nama_pasien=$_POST['nama_pasien'];
		$jenis_kelamin=$_POST['jenis_kelamin'];
		$golongan_darah=$_POST['golongan_darah'];
		$tempat_lahir=$_POST['tempat_lahir'];
		$tanggal_lahir=$_POST['tanggal_lahir'];
		$nama_ibu=$_POST['nama_ibu'];
		$alamat=$_POST['alamat'];
		$agama=$_POST['agama'];
		$status_menikah=$_POST['status_menikah'];
		$no_hp=$_POST['no_hp'];
		$id_pekerjaan=$_POST['id_pekerjaan'];
		$dokter=$_POST['dokter'];
		$tujuan=$_POST['tujuan'];
		$pembiayaan=$_POST['pembiayaan'];
		//$gambar=$_POST['gambar'];

		// Insert user data into table
		$query="INSERT INTO tbl_pasien SET id_registrasi='$id_registrasi', no_rekamedis='$no_rekamedis', nik='$nik', nama_pasien='$nama_pasien', jenis_kelamin='$jenis_kelamin', golongan_darah='$golongan_darah', tempat_lahir='$tempat_lahir', tanggal_lahir='$tanggal_lahir', nama_ibu='$nama_ibu', alamat='$alamat', agama='$agama', status_menikah='$status_menikah', no_hp='$no_hp', id_pekerjaan='$id_pekerjaan', dokter='$dokter', tujuan='$tujuan', pembiayaan='$pembiayaan'";
		mysqli_query($koneksi, $query);  
		//move_uploaded_file($_FILES['gambar']['tmp_name'],'images/'.$gambar);
		  		
		echo "<script>alert('pendaftaran atas nama pasien : $nama_pasien berhasil'); self.location = '';</script>";
	  }
	?>





	<style type="text/css">
	.container {
  		margin-top: 25px;
  		margin-bottom: 45px;
  	</style>

    
	



