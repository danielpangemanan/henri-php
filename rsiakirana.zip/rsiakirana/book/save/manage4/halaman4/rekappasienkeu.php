

<?php
	include "./koneksi.php";

	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
	   		<div class="table-responsive">
				<form>
					<table class="table  table-bordered" class="table-condensed" id="">
						<thead>
						<tr>
							<th><h3 style="text-align: center;">RSIA-KIRANA</h3></th>
							<th><h3 style="text-align: center;">PROSES PEMBAYARAN PASIEN</h3></th>
						</tr>
			   			<tr>
							<th><center>DATA PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   </thead>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Rekamedis</td>
							<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Induk Kependudukan</td>
							<td><?php echo $data['nik']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Pasien</td>
							<td><?php echo $data['nama_pasien']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Petugas Dokter</td>
							<td><strong><?php echo $data['dokter']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Jenis Kelamin</td>
							<td><?php echo $data['jenis_kelamin']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Golongan Darah</td>
							<td><?php echo $data['golongan_darah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Tempat, Tanggal Lahir</td>
							<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Alamat</td>
							<td><?php echo $data['alamat']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Ibu Kandung</td>
							<td><?php echo $data['nama_ibu']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Agama</td>
							<td><?php echo $data['agama']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Status</td>
							<td><?php echo $data['status_menikah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Telp/Hp</td>
							<td><?php echo $data['no_hp']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pekerjaan</td>
							<td><?php echo $data['id_pekerjaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pembiayaan</td>
							<td><?php echo $data['pembiayaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Poli Penanganan Pasien</td>
							<td><?php echo $data['tujuan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Ruang Inap Pasien</td>
							<td><?php echo $data['ruang_inap']; ?></td>
							
						</tr>
					   	</tbody>
					   	<?php } ?>

					   	<?php
							include "koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from dataobatpasien where id_registrasi='$no'");
							}else{
							echo "berdasarkan nomor registrasi";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<tbody>
						<tr class="odd gradeX">
							<td>Data Penggunaan Obat</td>
							<td><strong><?php echo $data['dataobat']; ?></strong></td>
						</tr>
					   	</tbody>
					 	</table>
					 	<?php } ?>

					





					 	<div class="agile-grids">	
			<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="">
							<?php
							include "./koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrjalan where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>


					   </table>
					   <?php } ?>
					</div>
			</div>


			<div class="agile-grids">	
			<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="">
							<?php
							include "./koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrinap where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>
					   	
					   </table>
					   <?php } ?>
					</div>
			</div>


			<div class="agile-grids">	
			<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="">
							<?php
							include "./koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrgd where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Keluhan Pasien</td>
							<td><strong><?php echo $data['keluhan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Riwayat Penyakit Pasien</td>
							<td><strong><?php echo $data['rpenyakit']; ?>&nbsp(kode penyakit)</strong></td>
						</tr>
					   	</tbody>
					    

					   </table>
					   <?php } ?>
					</div>
			</div>
		</form>

		

			<!-- Button trigger modal -->
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">Biaya Ruang Inap</button> &nbsp

			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop1">Biaya Obat</button>
			</div>
		</div>
	</div>


	<div class="agile-grids">	
			<div class="table-responsive">
					<!-- Modal -->
					<form role="form" method="POST">
						<?php
							include "./koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">
						<input type="hidden" class="form-control" name="id_registrasi" value="<?php echo $data['id_registrasi'];?>">

						<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">

						<input type="hidden" class="form-control" name="pembiayaan" value="<?php echo $data['pembiayaan'];?>">

						<?php } ?>

					<div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="staticBackdropLabel">Input Biaya Ruangan</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <label for="id_data">Ruangan</label>
						      <select class="form-control" name="id_data" required>
						        <option value=''>..:::..</option>
						          <?php
						         //Membuat koneksi ke database
						         $koneksiroom = mysqli_connect("localhost",'root',"","medkesne_rsudroom");
						         if (!$koneksiroom){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from ruangan";

						          $hasil=mysqli_query($koneksiroom,$sql);
						          
						          while ($dataroom = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $dataroom['id_data'];?>"><?php echo $dataroom['nama'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						    <br>

						    <label for="jumlah">Jumlah(Hari)</label><br>
	                        <input type="text" class="form-control" name="jumlah" placeholder="...."required>

					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					        <button type="submit" name="input" class="btn btn-primary">Kirim</button>
					      </div>
					    </div>
					  </div>
					</div>

					<?php
					 	include "./koneksi.php";

						  if(isset($_POST['input'])) {
						  	$no_rekamedis=$_POST['no_rekamedis'];
						  	$id_registrasi=$_POST['id_registrasi'];
						  	$nik=$_POST['nik'];
						  	$pembiayaan=$_POST['pembiayaan'];
							$id_data=$_POST['id_data'];
							$jumlah=$_POST['jumlah'];

						// Insert user data into table
						$input = mysqli_query($koneksi, "INSERT INTO tabel_trnruangpasien 
							(no_rekamedis,id_registrasi,nik,pembiayaan,id_data,jumlah) 
							VALUES('$no_rekamedis','$id_registrasi','$nik','$pembiayaan','$id_data','$jumlah')"); 
						  		
						echo "<script>alert('data keuangan ruangan pasien akan diproses');window.location=''</script>";
						
					  }
					?>

					</form>
		</div>
	</div>


	<div class="agile-grids">	
			<div class="table-responsive">
					<!-- Modal -->
					<form role="form1" method="POST">
						<?php
							include "./koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">

						<input type="hidden" class="form-control" name="id_registrasi" value="<?php echo $data['id_registrasi'];?>">

						<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">

						<input type="hidden" class="form-control" name="pembiayaan" value="<?php echo $data['pembiayaan'];?>">

						<?php } ?>

					<div class="modal fade" id="staticBackdrop1" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel1" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="staticBackdropLabel1">Input Biaya Obat</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <label for="id_obat">Obat</label>
						      <select class="form-control1" name="id_obat" required>
						        <option value=''>..:::..</option>
						          <?php
						         include "./koneksi.php";
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($koneksiobat,$sql);
						          
						          while ($dataobat = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $dataobat['id_obat'];?>"><?php echo $dataobat['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						    <br>

						    <label for="jumlah">Jumlah(Qty)</label><br>
	                        <input type="text" class="form-control1" name="jumlah" placeholder="...."required>

					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					        <button type="submit" name="input1" class="btn btn-primary">Kirim</button>
					      </div>
					    </div>
					  </div>
					</div>

					<?php
					 	include "./koneksi.php";

						  if(isset($_POST['input1'])) {
						  	$no_rekamedis=$_POST['no_rekamedis'];
						  	$id_registrasi=$_POST['id_registrasi'];
						  	$nik=$_POST['nik'];
						  	$pembiayaan=$_POST['pembiayaan'];
							$id_obat=$_POST['id_obat'];
							$jumlah=$_POST['jumlah'];

						// Insert user data into table
						$input = mysqli_query($koneksi, "INSERT INTO tabel_trnobatpasien 
							(no_rekamedis,id_registrasi,nik,pembiayaan,id_obat,jumlah) 
							VALUES('$no_rekamedis','$id_registrasi','$nik','$pembiayaan','$id_obat','$jumlah')"); 
						  		
						echo "<script>alert('data keuangan obat pasien akan diproses');window.location=''</script>";
						
					  }
					?>

					</form>
		</div>
	</div>


<div class="container-fluid" class="col-md-12">
	<div class="agile-grids">	
			<div class="table-responsive"> 
				<table class="table table-bordered">
				<?php
					include "./koneksi.php";
					$no = $_GET['kode'];

					$ambildata=mysqli_query($koneksiroom, "SELECT tabel_trnruangpasien.no_rekamedis, tabel_trnruangpasien.id_data, tabel_trnruangpasien.jumlah, data_ruangan.harga FROM tabel_trnruangpasien JOIN data_ruangan ON data_ruangan.id_data = tabel_trnruangpasien.id_data where id_registrasi='$no'");
					
					while($databiayaruangan = mysqli_fetch_array($ambildata)){

					?>

					<tr>
					 <th>BIAYA RUANGAN</th>
					 <th>Nomor Rekam Medis</th>
					 <th>Jumlah Hari</th>
					 <th>Harga</th>
					 <th>Total Biaya</th>
					</tr>
														
						
					<tr>
					 <td></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaruangan['no_rekamedis'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaruangan['jumlah'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaruangan['harga'];?></td>
					 <td></td>
					</tr>
				<?php } ?>
				</table>

				<table class="table table-bordered">
				<?php

					include "./koneksi.php";
					$no1 = $_GET['kode'];

					$ambildata1=mysqli_query($koneksiobat, "SELECT tabel_trnobatpasien.no_rekamedis, tabel_trnobatpasien.id_obat, tabel_trnobatpasien.jumlah, dataobat.harga_obt FROM tabel_trnobatpasien JOIN dataobat ON dataobat.id_obat = tabel_trnobatpasien.id_obat where id_registrasi='$no1'");
					
					while($databiayaobat = mysqli_fetch_array($ambildata1)){

					?>

					<tr>
					 <th>BIAYA OBAT</th>
					 <th>Nomor Rekam Medis</th>
					 <th>Jumlah(qty)</th>
					 <th>Harga</th>
					 <th>Total Biaya</th>
					</tr>
														
						
					<tr>
					 <td></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaobat['no_rekamedis'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaobat['jumlah'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaobat['harga_obt'];?></td>
					 <td></td>
					</tr>
				<?php } ?>
				</table>
		</div>
	</div>

</div>
<hr>





<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
	.th1{
		position: relative;
		top: -40px;
	}
</style>



				


