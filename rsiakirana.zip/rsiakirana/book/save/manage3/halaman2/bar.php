

<!-- <?php
	include "koneksi.php";
	?>

	<?php
	  // Cek apakah parameter ID ada
	  if (isset($_GET['nis'])) {
		// jika ada ambil nilai id
		$nis = $_GET['nis'];
	  } else {
		// jika tidak ada redirect ke index.php
		//header('Location:akseslogin.php');
	  }
	 ?>

	<?php
	// query SQL menampilkan data dari table tbl_biodata
	$sql = "SELECT * FROM stafsdm WHERE nis='$nis'";
	// tampung data (dalam array) kedalam variable $biodata
	$biodata = mysqli_query($koneksi, $sql);
	// cek apakah $biodata nilai kosong atau tidak
	if (mysqli_num_rows($biodata) > 0) {
	// jika ada tampilkan kedalam tabel
	$m = mysqli_fetch_assoc($biodata);
	}?> -->



<?php
	include "koneksi.php";

	echo '<div style="border:0px double #ababab; padding:5px;margin:5px height:750px;;width:500px;">';
	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = "select * from stafsdm where nis='$no'";
	$result=mysqli_query($koneksi,$sql);
	}else{
	echo "cari berdasarkan nomor NIS";
	}
	while($m = mysqli_fetch_array($result)){

?>

<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
	   		<div class="table-responsive">
				
					<table border="1" cellpadding="1" cellspacing="1" align="center" width="150%">
						<thead>
						<tr>
							<th><center><img src="/rsiakirana/images/logokirana.png" width="135px" height="60px"></center></th>
							<th><h3 style="text-align: center">PRINT DATA<br> NIP:&nbsp<center><?php echo bar128(stripslashes($m['nis'])); ?></center></h3></th>
						</tr>
			   			<tr>
							<th><center>DATA SDM</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   </thead>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Induk</td>
							<td><strong><?php echo $m['nis']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pendidikan</td>
							<td><?php echo $m['pendidikan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Kompetensi</td>
							<td><?php echo $m['kompetensi']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Keterangan Diklat</td>
							<td><strong><?php echo $m['diklat']; ?></strong></td>
						</tr>
					   	</tbody>

					   	
					 	</table>
					
				</div>
			</div>
				

	</div>
</center>
<br>
<br>
	<center>
		<button><a class="btn btn-primary" onclick="window.print()" role="button">PRINT</a></button>

		<button><a class="btn btn-primary" href="/rsiakirana/aksesadmin/manage1/adminrs.php?page=sdm" role="button">SELESAI</a></button>
	</center><br>
 <?php } ?>




















