<?php 
include "./koneksi.php";
?>

<div class="main-grid">
			<div class="agile-grids">	
				
			<h3 style="text-align: center;">DATA ICD/TINDAKAN REKAM MEDIS</h3>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th></th>
				 <th>Kode</th>
				 <th>Keterangan/Tindakan</th>
				</tr>
					
				<?php
				
				$sql = $koneksi->query("SELECT * FROM data_icd ORDER BY id_icd ASC");
				while ($data=$sql->fetch_assoc())
				{
				?>											
					
				<tr>
				 <td></td>
				 <td bgcolor="#ffffff"><?php echo $data['kode_icd'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['keterangan_icd'];?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div>