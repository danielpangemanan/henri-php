<?php
include "conkeu.php";
?>
<br><br>
<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
	  					<form id="form" role="form" method="post" action="#">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>Input DAU</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s">
													   <div class="col-md-6 col-sm-6">
															<label for="kode_dau">Kode DAU</label>
															<input type="text" class="form-control" name="kode_dau" placeholder="...." required>
													   </div>
													  
													  
													  <div class="col-md-6 col-sm-6">
															<label for="jenis_dau">Uraian Anggaran</label>
															<input type="text" class="form-control" name="jenis_dau" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="jumlah_dau">Jumlah(Rp)</label>
															<input type="text" class="form-control" name="jumlah_dau" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="tanggal_dau">Tanggal Input DAU</label>
															<input type="date" class="form-control" name="tanggal_dau" placeholder="...." required>
														</div>
								  
								  						<div class="col-md-6 col-sm-6">
															<label for="tahun_dau">Tahun Anggaran</label>
															<input type="year" class="form-control" name="tahun_dau" placeholder="...." required>
														</div>

													   <div class="col-md-12 col-sm-12">
															<br>&nbsp; <a href="#"> pastikan data yang di input sudah benar!!!</a>
															<button  class="col-md-2" type="submit" class="form-control" name="tambah">Input</button>
														   <br>
													   </div>
								  
  							</form>
						</div>
	
	  
	  					<!-- validasi yang belum ditampilkan-->
													<?php 
													//if(isset($_GET['nomor_jurnal'])){
													//	if($_GET['nomor_jurnal'] == ""){
													//		echo "<h4 style='color:red'>Nomor Jurnal Belum Di Masukkan !</h4>";
													//	}
													//}
													?>
		   
			 
							<!-- php input -->

							<?php

							  // Check If form submitted, insert form data into users table.
							  if(isset($_POST['tambah'])) {
								$kode_dau = $_POST['kode_dau'];
								$jenis_dau = $_POST['jenis_dau'];
								$jumlah_dau = $_POST['jumlah_dau'];
								$tanggal_dau = $_POST['tanggal_dau'];
								$tahun_dau = $_POST['tahun_dau'];
								  
								//koneksi.phpr data into table
								$query="INSERT INTO inputdau SET kode_dau='$kode_dau', jenis_dau='$jenis_dau',jumlah_dau='$jumlah_dau',tanggal_dau='$tanggal_dau',tahun_dau='$tahun_dau'";
								  mysqli_query($koneksi, $query); 

								  
								  echo "<script>alert('Input Berhasil Rp. :$jumlah_dau');window.location='/aksesadmin/halaman9/dataentry.php?'</script>";
								}
							?>


</div>
</div>    
</div>
<br>