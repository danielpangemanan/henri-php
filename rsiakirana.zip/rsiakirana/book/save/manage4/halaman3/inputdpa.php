<?php
include "conkeu.php";
?>
<br><br>
<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
	  					<form id="form" role="form" method="post" action="#">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>Input DPA</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s">
													   <div class="col-md-6 col-sm-6">
															<label for="kode_dpa">Kode DPA</label>
															<input type="text" class="form-control" name="kode_dpa" placeholder="...." required>
													   </div>
													  
													  
													  <div class="col-md-6 col-sm-6">
															<label for="uraian_dpa">Uraian Anggaran</label>
															<input type="text" class="form-control" name="uraian_dpa" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="jumlah_dpa">Jumlah(Rp)</label>
															<input type="text" class="form-control" name="jumlah_dpa" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="tanggal_dpa">Tanggal Input DPA</label>
															<input type="date" class="form-control" name="tanggal_dpa" placeholder="...." required>
														</div>
								  
								  						<div class="col-md-6 col-sm-6">
															<label for="tahun_dpa">Tahun Anggaran</label>
															<input type="year" class="form-control" name="tahun_dpa" placeholder="...." required>
														</div>

													   <div class="col-md-12 col-sm-12">
															<br>&nbsp; <a href="#"> pastikan data yang di input sudah benar!!!</a>
															<button  class="col-md-2" type="submit" class="form-control" name="tambah">Input</button>
														   <br>
													   </div>
								  
  							</form>
						</div>
	
	  
	  					<!-- validasi yang belum ditampilkan-->
													<?php 
													//if(isset($_GET['nomor_jurnal'])){
													//	if($_GET['nomor_jurnal'] == ""){
													//		echo "<h4 style='color:red'>Nomor Jurnal Belum Di Masukkan !</h4>";
													//	}
													//}
													?>
		   
			 
							<!-- php input -->

							<?php

							  // Check If form submitted, insert form data into users table.
							  if(isset($_POST['tambah'])) {
								$kode_dpa = htmlspecialchars($_POST['kode_dpa']);
								$uraian_dpa = $_POST['uraian_dpa'];
								$jumlah_dpa = $_POST['jumlah_dpa'];
								$tanggal_dpa = $_POST['tanggal_dpa'];
								$tahun_dpa = $_POST['tahun_dpa'];
								  
								//koneksi.phpr data into table
								$query="INSERT INTO inputdpa SET kode_dpa='$kode_dpa', uraian_dpa='$uraian_dpa',jumlah_dpa='$jumlah_dpa',tanggal_dpa='$tanggal_dpa',tahun_dpa='$tahun_dpa'";
								  mysqli_query($koneksi, $query); 

								  
								  echo "<script>alert('Input Berhasil Rp. :$jumlah_dpa');window.location=''</script>";
								}
							?>


</div>
</div>    
</div>
<br>