
<?php 
  include "conarsip.php";

  $sql = $koneksi->query("select * from medkesne_rsudarsip");
  $sql = $koneksi->query("SELECT * FROM data_kirana ORDER BY id ASC");


  while ($data=$sql->fetch_assoc()) {
?>

<br>
<html>
  <head><link href="file2.css" rel="stylesheet" type="text/css" /><table width='100%' border='0' align='center' cellpadding='3px' cellspacing='0' class='tbl_form'><tr class='isi2'><td valign='top' align='center'><font size='4' face='Tahoma'><?php echo $data['nama_rs']; ?></font><br><?php echo $data['alamat']; ?><br>Telepon: <?php echo $data['no_telp']; ?>, E-mail : <?php echo $data['email']; ?><br><br><font size='4' face='Tahoma'>REKAP<br><br></font></td></tr></table>
  <?php } ?>
  </head>
  <body>
    <table width="100%" border="1" align="center" cellpadding="3px" cellspacing="0" class="tbl_form">
      <tr class="isi1">
        <td valign="top" bgcolor="#f8fdf3" align="left">
          TANGGAL LAPORAN: <?php echo date('d-m-Y'); ?>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;DOKTER :
        </td>
      </tr>
      <tr class="isi1">
        <td>
          <table width="100%" border="1" align="center" cellpadding="3px" cellspacing="0" class="tbl_form">
            <tr class="isi3">
              <td valign="middle" bgcolor="#f8fdf3" align="center" width="3%" rowspan="3">
                NO.
              </td>
              <td valign="middle" bgcolor="#f8fdf3" align="center" width="5%" rowspan="3">
                NO.REKAM MEDIS
              </td>
              <td valign="middle" bgcolor="#f8fdf3" align="center" width="10%" rowspan="3">
                NAMA PASIEN
              </td>
              <td valign="middle" bgcolor="#f8fdf3" align="center" width="12%" rowspan="3">
                ALAMAT
              </td>
              <td valign="middle" bgcolor="#f8fdf3" align="center" width="4%" rowspan="3">
                TGL.LAHIR
              </td>
              <td valign="middle" bgcolor="#f8fdf3" align="center" width="1%" rowspan="2">
                L/P
              </td>
              <td valign="middle" bgcolor="#f8fdf3" align="center" width="20%" rowspan="2">
                TINDAKAN &amp; HARGA
              </td>
            </tr>
           
          </table>
        </td>
      </tr>
     
    </table>
  </body>
</html>
