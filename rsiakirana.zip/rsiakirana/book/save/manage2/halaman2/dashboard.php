<?php
include "koneksibarcode.php";
?>

<!DOCTYPE html>
<html lang="en">
	<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
    <link href="css/bootstrap-3.4.1.css" rel="stylesheet" type="text/css">
    
</head>
<body style="background-image:url(images/background.jpg);background-size:cover">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
		<div class="container">
			<a class="navbar-brand" target="_blank" href=""><b>RSUD</b>&nbsp;PROVINSI SULUT</a>
			
		</div>
		</div>
	</nav>
	<div class="col-md-1"></div>
	<div class="col-md-10 well">
	  <nav class="navbar navbar-default">
	   
		<h4><b>DATA&nbsp;PASIEN</b></h4>
		<br>
		<input class="btn btn-primary" type="button" value="Pasien Baru" onclick="window.location.href='/aksesadmin/halaman8/datapasien.php'" />
		</nav>    
	   
		<b>Data Rekam Medik</b>
		
		
		
		
		<div class="col-md-10">
			
			
									<div class="table-responsive">
										<table class="table table-hover">
									
										<tr>
										 <th bgcolor="#75BCF0">KETERANGAN</th>
										 <th bgcolor="#75BCF0">Dokter</th>
										 <th bgcolor="#75BCF0">Nama Pasien</th>
										 <th bgcolor="#75BCF0">Tanggal Masuk</th>
										 <th bgcolor="#75BCF0">Nomor Kode</th>
										 <th bgcolor="#75BCF0">Jenis Kelamin</th>
										</tr>
										<?php
										$query = mysqli_query($koneksi,"SELECT * FROM pasien ORDER BY id DESC");
										while($data=mysqli_fetch_array($query))
										{
										?>
										<tr>
										 <td></td>
										 <td bgcolor="#ffffff"><?php echo $data['dokter'];?></td>
										 <td bgcolor="#ffffff"><?php echo $data['nama_pasien'];?></td>
										 <td bgcolor="#ffffff"><?php echo $data['tanggal_masuk'];?></td>
										 <td bgcolor="#ffffff"><?php echo $data['kode'];?></td>
										 <td bgcolor="#ffffff"><?php echo $data['jenis_kelamin'];?></td>
										 
										</tr>
										<?php
										}
										?>
										</table>
									</div>
			
	</div>
		
		
<script src="js/jquery-1.12.4.min.js"></script>
<script src="js/bootstrap-3.4.1.js"></script>
</body>
</html>