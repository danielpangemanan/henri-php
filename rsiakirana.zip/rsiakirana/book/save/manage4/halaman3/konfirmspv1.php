<?php 
include "./koneksi.php"; 

$nomor = $_GET['nomor'];
$keterangan = $_GET['keterangan'];
$jumlah = $_GET['jumlah'];
$waktu = $_GET['waktu'];
$bulan=date('F');

$cekdulu= "SELECT * FROM jurnal_masuk WHERE kode_transaksi='MO$nomor'"; 
$prosescek= mysqli_query($koneksi, $cekdulu);
if (mysqli_num_rows($prosescek)>0) { 
    echo "<script>alert('Transaksi ini sudah di Konfirmasi Sebelumnya'); </script>";
} else {

$update = mysqli_query($koneksi, "UPDATE tabel_pesan SET sudahbaca='YES'
WHERE nomor=$nomor ");


$query="INSERT INTO jurnal_masuk SET nomor_jurnal='22001', jenis='$keterangan', jumlah='$jumlah', kode_transaksi='MO$nomor', tanggal_masuk='$waktu', bulan='$bulan'";
	  mysqli_query($koneksi, $query); 
}
?>





<script>
setTimeout(function() {
  window.location.href = "/rsiakirana/aksesadmin/manage4/spvkasir?page=spv1";
}, 500);
</script>