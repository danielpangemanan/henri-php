


<?php
	include "koneksi.php";

	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");

	}else{
	echo "PASIEN BELUM DI PROSES";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
	   		<div class="table-responsive">
				<form method="POST">
					<table class="table table-bordered" style="background-color: white;">
						<thead>
						<tr>
							<th><h3 style="text-align: center">MENU KEUANGAN</h3></th>
							<th><h3 style="text-align: center">PROSES PEMBAYARAN PASIEN</h3></th>
						</tr>
			   			<tr>
							<th><center>DATA PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   </thead>

					   <tbody>
						<tr class="odd gradeX">
							
							<input type="hidden" class="form-control" name="id_registrasi" value="<?php echo $data['id_registrasi'];?>">
							<td>Nomor Registrasi</td>
							<td><strong><?php echo $data['id_registrasi']; ?></strong></td>
						</tr>
					   	</tbody>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Rekamedis</td>
							<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Induk Kependudukan</td>
							<td><?php echo $data['nik']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Pasien</td>
							<td><?php echo $data['nama_pasien']; ?></td>
							
						</tr>
					   	</tbody>

					   	
					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Alamat</td>
							<td><?php echo $data['alamat']; ?></td>
							
						</tr>
					   	</tbody>

					   	
					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pembiayaan</td>
							<td><?php echo $data['pembiayaan']; ?></td>
							
						</tr>
					   	</tbody>
					 	<?php } ?>

					






						<?php
							include "koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrjalan where id_registrasi='$no'");
							}else{
							echo "";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						
					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>
					   <?php } ?>
					


			
						<?php
							include "koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrinap where id_registrasi='$no'");
							}else{
							echo "";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>
					   <?php } ?>
					


			
						<?php
							include "koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrgd where id_registrasi='$no'");
							}else{
							echo "";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						
					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Keluhan Pasien</td>
							<td><strong><?php echo $data['keluhan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Riwayat Penyakit Pasien</td>
							<td><strong><?php echo $data['rpenyakit']; ?>&nbsp(kode penyakit)</strong></td>
						</tr>
					   	</tbody>
					   <?php } ?>
					
		
					<?php

						$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudroom";
						$koneksiroom    = mysqli_connect($host, $user, $password, $database);
						$no = $_GET['kode'];

						$ambildata=mysqli_query($koneksiroom, "SELECT tabel_trnruangpasien.no_rekamedis, tabel_trnruangpasien.id_data, tabel_trnruangpasien.jumlah, data_ruangan.harga FROM tabel_trnruangpasien JOIN data_ruangan ON data_ruangan.id_data = tabel_trnruangpasien.id_data where id_registrasi='$no'");
						
						while($databiayaruangan = mysqli_fetch_array($ambildata)){

							$jumlah=$databiayaruangan['jumlah'];
							$harga=$databiayaruangan['harga'];
							$totalruangan=$jumlah*$harga;

					?>

					<tbody>
						<tr class="odd gradeX">
							<td>Jumlah Hari Penggunaan Ruangan</td>
							<td><?php echo $databiayaruangan['jumlah'];?></td>
						</tr>
					</tbody>
														
					<tbody>
						<tr class="odd gradeX">
							<td>Biaya Penggunaan Ruangan</td>
							<td><?php echo "Rp." .number_format($databiayaruangan['harga']).",-";?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Total Biaya Ruangan</td>
							<td style="background-color: yellow"><?php echo "Rp." .number_format($totalruangan).",-";?></td>
						</tr>
					</tbody>
					<?php } ?>
				

				
					<?php

						$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudobat";
						$koneksiobat    = mysqli_connect($host, $user, $password, $database);
						$no1 = $_GET['kode'];

						$ambildata1=mysqli_query($koneksiobat, "SELECT tabel_trnobatpasien.no_rekamedis, tabel_trnobatpasien.id_obat, tabel_trnobatpasien.jumlah, dataobat.harga_obt FROM tabel_trnobatpasien JOIN dataobat ON dataobat.id_obat = tabel_trnobatpasien.id_obat where id_registrasi='$no1'");
						
						while($databiayaobat = mysqli_fetch_array($ambildata1)){

							$jumlah=$databiayaobat['jumlah'];
							$harga_obt=$databiayaobat['harga_obt'];
							$totalobat=$jumlah*$harga_obt;
					?>

					<tbody>
						<tr class="odd gradeX">
							<td>Jumlah Obat</td>
							<td><?php echo $databiayaobat['jumlah'];?></td>
						</tr>
					</tbody>
														
					<tbody>
						<tr class="odd gradeX">
							<td>Biaya Obat</td>
							<td><?php echo "Rp." .number_format($databiayaobat['harga_obt']).",-";?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Total Biaya Obat</td>
							<td style="background-color: yellow"><?php echo "Rp." .number_format($totalobat).",-";?></td>
						</tr>
					</tbody>
					<?php } ?>
				
					




			<?php
				include "koneksi.php";
				$no = $_GET['kode'];
				$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");
				
				while($datapsnpsn = mysqli_fetch_array($sql)){

			?>


			<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $datapsnpsn['no_rekamedis'];?>">

			<input type="hidden" class="form-control" name="nomor_jurnal" value="<?php echo $datapsnpsn['id_registrasi'];?>">
			
			<input type="hidden" class="form-control" name="nama_pasien" value="<?php echo $datapsnpsn['nama_pasien'];?>">

			<input type="hidden" class="form-control" name="nik" value="<?php echo $datapsnpsn['nik'];?>">
			
			
			
			<tbody>
				<tr class="odd gradeX">
					<td><input class="form-control" name="tgl_proseskeu" value="Tanggal Proses: <?php echo $date = date("Y-m-d H:i:s");?>" style="border:none"></td>
				</tr>
			</tbody>
			<?php } ?>



			<!-- in registrasi mengikuti isian form diatas -->

			<input type="hidden" class="form-control" name="jenis" value="Pembayaran Pasien">

			<!-- Total Biaya Pasien mengikuti isian form diatas -->
															
			<!-- Total NorekMedis Pasien mengikuti isian form diatas -->
													   
			<input type="hidden" class="form-control" name="tanggal_masuk" value="<?php echo $date = date("Y-m-d H:i:s");?>">

			<input type="hidden" class="form-control" name="bulan" value="<?php echo date("m");?>">

			<tbody>
				<tr class="odd gradeX">
					<td><input class="form-control" name="jumlah" placeholder="input total biaya pembayaran" required></td>
				</tr>
			</tbody>

		</table>
		
			<h6>Catatan: Jumlah Biaya adalah Total dari semua Tabel Berwarna Kuning</h6>
			<button type="submit" name="kirimkeu" class="btn btn-primary">PROSES PEMBAYARAN PASIEN</button>

		</div>
		
		</form>
		

	</div>
</div>
<br>
<br>

<?php
$host     = "localhost";
$user     = "root";
$password = "";
$database = "medkesne_rsudkeu";
$koneksikeupsn  = mysqli_connect($host, $user, $password, $database);

if(isset($_POST['kirimkeu'])) {
$no_rekamedis= $_POST['no_rekamedis'];
$id_registrasi= $_POST['id_registrasi'];
$nama_pasien= $_POST['nama_pasien'];
$nik=$_POST['nik'];
$jumlah=$_POST['jumlah'];
$tgl_proseskeu=$_POST['tgl_proseskeu'];

// Insert user data into table
$query="INSERT INTO tabel_prspbrpasien SET no_rekamedis='$no_rekamedis', id_registrasi='$id_registrasi', nama_pasien='$nama_pasien', nik='$nik', jumlah='$jumlah', tgl_proseskeu='$tgl_proseskeu' ";
mysqli_query($koneksikeupsn, $query);  
  		

}
?>




<?php
	$host     = "localhost";
	$user     = "root";
	$password = "";
	$database = "medkesne_rsudkeu";
	$koneksi_jrmasuk  = mysqli_connect($host, $user, $password, $database);
 
  	if(isset($_POST['kirimkeu'])) {
	$nomor_jurnal = $_POST['id_registrasi'];
	$jenis = $_POST['jenis'];
	$jumlah = $_POST['jumlah'];
	$kode_transaksi = $_POST['no_rekamedis'];
	$tanggal_masuk = $_POST['tanggal_masuk'];
	$bulan = $_POST['bulan'];

	
	$query="INSERT INTO jurnal_masuk SET nomor_jurnal='$id_registrasi', jenis='$jenis',jumlah='$jumlah',kode_transaksi='$no_rekamedis',tanggal_masuk='$tanggal_masuk',bulan='$bulan'";
	  mysqli_query($koneksi_jrmasuk, $query); 

	  echo "<script>alert('data obat pembayaran pasien dengan nomor r.medis $no_rekamedis sudah masuk dengan total $jumlah');window.location='adminrs.php?page=bkeupsn'</script>";

}

?> 






<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
	
</style>



				


