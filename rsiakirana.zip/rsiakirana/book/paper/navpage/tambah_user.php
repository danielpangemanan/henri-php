






	
	       
        <div class="main-grid">
            <div class="agile-grids">   
                <div class="grids">
                    <div class="progressbar-heading grids-heading">
                    </div>
                    <div class="panel panel-widget forms-panel">
                        <br>
                        <h2 style="color: black; text-align: center;">TAMBAH AKUN PENGGUNA</h2>
                        <br>
                        <div class="forms">
                            <div class="form-grids widget-shadow" data-example-id="basic-forms"> 
                                    	<div class="form-title">
                                            <p>Tambah Akun Pengguna sesuai dengan user modul</p>
                                        </div>

                                        <div class="agile-tables">
                                            <div class="w3l-table-info">

                                               <br>
                                               <div class="container">
                                               <form method="POST">
                                               	<label for="nama">Nama User</label><br>
						                        <input type="text" class="form-control" name="nama" placeholder="...." required>
						                  		<br>
												                               
						                        <label for="username">Username</label><br>
						                        <input type="text" class="form-control" name="username" placeholder="...."required>
						                  		<br>

						                   
						                        <label for="password">Password Pengguna</label><br>
						                        <input type="text" class="form-control" name="password" placeholder="...."required>
						                   		<br>

						                   		<label for="level">Jenis Akun</label>
												<select name="level" class="form-control" required>
													<option value="">..:::..</option>
													<option value="pimpinan">Pimpinan</option>
													<option value="admin">Admin</option>
													<option value="medis">Dokter</option>
													<option value="medis">Perawat</option>
													<option value="admrmedis">Rekam Medis</option>
													<option value="spvkasir">SPV Kasir</option>
													<option value="apotik">Apotik</option>
													<option value="admisi">Admisi</option>
													<option value="keukasir">Keuangan/Kasir</option>
												</select>
						                        <br>
						                            
											   <div>
													<button type="submit" name="tambah"
															class="btn btn-primary" >Input </button>
												</div>
											  </form>
											  </div>
											  <br>

                                        </div>
                            </div>
                        </div>                            
                </div>
            </div>
        </div>
        
        

        


	  					<?php
						  
						  if(isset($_POST['tambah'])) {
							$nama = htmlspecialchars($_POST['nama']);
							$username= htmlspecialchars($_POST['username']);
							$password= htmlspecialchars($_POST['password']);
							$level = htmlspecialchars($_POST['level']);
							// $is_aktif= htmlspecialchars($_POST['is_aktif']);

							$cekdulu= "select * from login where username='$_POST[username]'"; 
							$prosescek= mysqli_query($koneksi, $cekdulu);
							if (mysqli_num_rows($prosescek)>0) { //proses mengingatkan data sudah ada
								echo "<script>alert('maaf $username sudah terdaftar'); </script>";
							} else {
							// Insert user data into table
							$result = mysqli_query($koneksi, "INSERT INTO login (nama,username,password,level) VALUES('$nama','$username','$password','$level')"); 
							}
							
							echo "<script>alert('User Baru Sudah Aktif');window.location='' </script>"; 
						  }
						?>
