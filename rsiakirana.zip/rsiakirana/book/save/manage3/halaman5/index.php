
<br>

<center><h3 class="text-primary">Upload File Excel <small></small></h3></center>
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-2">
			
			
			<form method="post" enctype="multipart/form-data" action="/aksesadmin/manage1/adminrs?page=upproses">
				<div class="form-group">
					<label for="exampleInputFile"><b>Masukkan File disini</b> </label>
					
					 Pastikan file yang di upload adalah .xls
					
					<input type="file" name="berkas_excel" class="form-control" id="exampleInputFile">
				</div>
				
				<button type="submit" class="btn btn-danger">Import</button>
				<br><br>
			</form>
			
			<a href="" class="btn btn-primary">Selesai</a>
			
		</div>
		
		<div class="col-md-10">
			<form method="POST" action="">
				<button class="btn btn-success pull-right"><span class="glyphicon glyphicon-export"></span>edit</button>
			</form>
			<br/><br/>
			
			<div class="container-fluid">
				<div class="table-responsive">
																
				<table class="table table-bordered" class="table-condensed" id="">
				<thead style="text-align: center">
					
					<tr>
						<td rowspan="2">No</td>
						<td rowspan="2">Desa</td>
						<td rowspan="2">Jumlah Jiwa<br>(data umum)</td>
						<td colspan="2">Jamban</td>
						<td colspan="2">Jumlah Tempat Sampah</td>
						<td colspan="2">Jumlah Spal</td>
					</tr>
					<tr>
						<td>Jumlah KK</td>
						<td>Jumlah Jiwa</td>
						<td>TPS</td>
						<td>TPA</td>
						<td>Saluran</td>
						<td>Kolam</td>
					</tr>
					
				</thead>
				<tbody>
					<?php
						require 'koneksi.php';
						$no=1;
						$query = mysqli_query($koneksiup, "SELECT * FROM `data_icd`");
						while($fetch = mysqli_fetch_array($query)){
					?>
					<tr>
						<td><?php echo $no++; ?></td>
						<td><?php echo $fetch['kode_icd']?></td>
						<td><?php echo $fetch['keterangan_icd']?></td>
						<td><?php echo $fetch['user']?></td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
			</div>
			</div>




