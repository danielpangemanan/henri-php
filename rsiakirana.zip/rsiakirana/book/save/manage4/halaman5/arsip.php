<!DOCTYPE html>
<html lang="en">
	<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
    <link href="css/bootstrap-3.4.1.css" rel="stylesheet" type="text/css">
    
</head>
<body style="background-image:url(background.jpg);background-size:cover">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
		<div class="container">
			<a class="navbar-brand" target="_blank" href=""><b>RSUD</b>&nbsp;PROVINSI SULUT</a>
			
		</div>
		</div>
	</nav>
	<div class="col-md-1"></div>
	<div class="col-md-10 well">
	  <nav class="navbar navbar-default">
	   
		    
		</nav>    
	   
			<?php 

			include_once("./koneksi.php");

			$jenis = $_GET['jenis'];

			$result = mysqli_query($koneksi, "SELECT FROM arsip WHERE jenis=$jenis");

			?>
      
		
		<h3 class="text-primary"> <?php echo $jenis;?><small>&nbsp;&nbsp;RSUD</small></h3>
			 
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-3">
			File Arsip
			<a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=inputarsip&jenis=<?php echo $jenis;?>">Input Data File</a>
			<br>
			<div class="btn btn-default">
			<a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=arsip">Kembali</a>
			</div>
		</div>
		
		<div class="col-md-9">
			
			
		<div class="table-responsive">
			<table class="table table-striped table-hover">
		
			<tr style="background-color: orange">
			 <th><?php echo $jenis;?></th>
			 <th>Judul File Arsip</th>
			 <th>Nama File Arsip</th>
			 <th >Tanggal di Arsipkan</th>
			 <th >Detail Arsip File</th>
			</tr>
			<?php
			$query = mysqli_query($koneksi,"SELECT * FROM data_file WHERE judul LIKE '$jenis' ");
			while($data=mysqli_fetch_array($query))
			{
			?>
			<tr>
			 <td></td>
			 <td bgcolor="#ffffff"><?php echo $data['judul'];?></td>
			 <td bgcolor="#ffffff"><?php echo $data['nama_file'];?></td>
			 <td bgcolor="#ffffff"><?php echo $data['tanggal'];?></td>
			 <th bgcolor="#ffffff"><a href="/rsudprovsulut/aksesadmin/manage1/halaman6/uploadfilepdf/view.php?name=<?php echo $data['nama_file'];?>"><img src="/rsudprovsulut/aksesadmin/manage1/halaman6/uploadfilepdf/file/pdflogo.png" alt="lihat arsip" height="25"></a>open&nbsp
			 <a href="/rsudprovsulut/aksesadmin/manage1/halaman6/uploadfilepdf/hapus.php?id=<?php echo $data['id'];?>" class="label label-info" onclick="return confirm('ANDA YAKIN DATA AKAN DIHAPUS?')">Hapus</a></th>
			</tr>
			<?php
			}
			?>
			</table>
		</div>
			
	</div>
		
		
<script src="js/jquery-1.12.4.min.js"></script>
<script src="js/bootstrap-3.4.1.js"></script>
</body>
</html>