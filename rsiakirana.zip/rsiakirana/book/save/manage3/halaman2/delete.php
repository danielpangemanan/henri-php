<?php
	include "koneksi.php";
	$mysqli=new mysqli($host,$user,$pass,$database);
	if (mysqli_connect_errno()) {
	    trigger_error('Koneksi ke database gagal: '  . mysqli_connect_error(), E_USER_ERROR); 
	}
?>



<?php 

    $hapus=$mysqli->query("select*from stafsdm where nis='$_GET[nis]'");
    // memilih gambar untuk dihapus
    $nama_gambar=mysqli_fetch_array($hapus);
    // nama field gambar
    $lokasi=$nama_gambar['gambar'];
    // alamat tempat gambar
    $hapus_gambar="images/$lokasi";
    // script delete gambar dari folder
    unlink($hapus_gambar);
    $mysqli->query("DELETE FROM stafsdm WHERE nis='$_GET[nis]'");

	echo "<script>alert('data ini akan di HAPUS!');window.location='/rsiakirana/aksesadmin/manage1/adminrs.php?page=sdm'</script>";
?>