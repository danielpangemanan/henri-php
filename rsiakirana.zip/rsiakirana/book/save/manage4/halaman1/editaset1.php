<?php
include "conaset.php";

$kode     = $_GET['kode'];
$aset2     = mysqli_query($koneksi, "select * from aset1 where id='$kode'");
$data     = mysqli_fetch_array($aset2);

?>


<br>
    <div class="container">
    <div class="row">
     <div class="col-md-8 col-sm-12">
              <!-- SECTION INPUT -->
            
              <form id="form" role="form" method="post" action="#">
                
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>PERUBAHAN DATA ASET</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s" >
                                   
                                      <input type="hidden" class="form-control" name="id" value="<?php echo $data['id'];?>">  
                                      
                                        <label for="kode_aset">Kode Aset</label><br>
                                        <input type="text" class="form-control" name="kode_aset" value="<?php echo $data['kode_aset'];?>">
                                      <br>
                                                   
                                        <label for="keterangan">Keterangan</label><br>
                                        <input type="text" class="form-control" name="keterangan" value="<?php echo $data['keterangan'];?>">
                                      <br>

                                   
                                      <label for="nama">Nama Aset</label><br>
                                      <input type="text" class="form-control" name="nama" value="<?php echo $data['nama'];?>">
                                      <br>

                                      <label for="anggaran">Mata Anggaran</label>
                                        <select name="anggaran" class="form-control">
                                          <option value="<?php echo $data['anggaran'];?>"><?php echo $data['anggaran'];?></option>
                                          <option value="Daerah">Daerah</option>
                                          <option value="Pusat">Pusat</option>
                                          <option value="RSUD">RSUD</option>
                                        </select>
                                        <br>


                                        <label for="penerima">Penerima</label>
                                        <select name="penerima" class="form-control">
                                          <option value="<?php echo $data['penerima'];?>"><?php echo $data['penerima'];?></option>
                                          <option value="Pimpinan">Pimpinan</option>
                                          <option value="Biro Umum">Biro Umum</option>
                                        </select>
                                        <br>

                                        <label for="tanggal_masuk">Tanggal Masuk</label><br>
                                        <input type="date" class="form-control" name="tanggal_masuk" value="<?php echo $data['tanggal_masuk'];?>">
                                        <br>

                                        <label for="harga">Harga</label><br>
                                        <input type="text" class="form-control" name="harga" value="<?php echo $data['harga'];?>">
                                        <br>
                                            
                     <div>
                      <button type="submit" name="tambah"
                          class="btn btn-primary">Perubahan Data</button>

                      <a type="button" href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=aset1"
                          class="btn btn-primary">Batal</a>
                    </div>
                      
                  </form>
                
            </div>
              
              <?php
               
              if(isset($_POST['tambah'])) {
              $id = htmlspecialchars($_POST['id']);
              $kode_aset = htmlspecialchars($_POST['kode_aset']);
              $keterangan = htmlspecialchars($_POST['keterangan']);
              $nama= htmlspecialchars($_POST['nama']);
              $anggaran= htmlspecialchars($_POST['anggaran']);
              $penerima = htmlspecialchars($_POST['penerima']); 
              $tanggal_masuk = htmlspecialchars($_POST['tanggal_masuk']); 
              $harga = htmlspecialchars($_POST['harga']); 
              
              // Insert user data into table
              mysqli_query($koneksi, "UPDATE aset1 SET kode_aset='$kode_aset', keterangan='$keterangan', nama='$nama', anggaran='$anggaran', penerima='$penerima', tanggal_masuk='$tanggal_masuk' , harga='$harga' where id='$id' "); 
              
              echo "<script>alert('Perubahan Data Berhasil');window.location='/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=aset2'</script>";
              }
            ?>
              

    </div>
  </div>
  </div>  
<br>
    