
<?php include "koneksi.php"; ?>

<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
		 	<br>
	  					<!-- SECTION INPUT -->
						
	  					<form id="form" role="form" method="post" action="">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>TAMBAH DATA ICD/TINDAKAN REKAM MEDIS</h2>
                              </div>

                              	<div class="wow fadeInUp" data-wow-delay="0.8s" >
                                   
                                        <label for="kode_icd">Kode ICD</label><br>
                                        <input type="text" class="form-control" name="kode_icd" placeholder="...." required>
                                  		<br>

                                  		<label for="keterangan_icd">Nama Tindakan Sesuai Kode ICD</label><br>
                                        <input type="text" class="form-control" name="keterangan_icd" placeholder="...." required>
                                  		<br>

										<label for="user">Nama User</label><br>
                                        <input type="text" class="form-control" name="user" placeholder="...." required>
                                  		<br>                        		

									   <div>
											<button type="submit" name="input" class="btn btn-primary" >Input </button>
			
											<button type="reset" name="reset" class="btn btn-primary">Reset </button>
										</div>
								</div>
  							</form>
								
					<?php
						  if(isset($_POST['input'])) {
							$kode_icd = htmlspecialchars($_POST['kode_icd']);
							$keterangan_icd= htmlspecialchars($_POST['keterangan_icd']);
							$user= htmlspecialchars($_POST['user']);

							$cekdulu= "select * from data_icd where kode_icd='$_POST[kode_icd]'"; 
							$prosescek= mysqli_query($koneksi, $cekdulu);
							if (mysqli_num_rows($prosescek)>0) { //proses mengingatkan data sudah ada
								echo "<script>alert('maaf $kode_icd sudah terdaftar'); </script>";
							} else {
							// Insert user data into table
							mysqli_query($koneksi, "INSERT INTO data_icd SET kode_icd='$kode_icd',keterangan_icd='$keterangan_icd',user='$user' "); 
							}
							
							echo "<script>alert('data ICD $keterangan_icd sudah masuk');window.location='adminrs.php?page=dticd'</script>";
						  }
						?>	
	  					
	 
		</div>
	</div>
  </div>  
<br>