


			
			<table class="table  table-bordered" class="table-condensed" id="">
			  <thead style="background-color: lightgreen">
					<tr>
					<th><center>FORMULIR <br> PASIEN RAWAT INAP</center></th>
					<th><center>KETERANGAN</center></th>
				</tr>
			   </thead>

			   	<tbody>
			   	<tr class="odd gradeX">
			   		<td>Tanggal Pemeriksaan</td>
					<td><input style="border: none;" type="date" class="form-control" name="tglperiksa" required="">
					</td>
				</tr>
				</tbody>

			   	<tbody>
				<tr class="odd gradeX">
					<td><strong>Hasil Anamesis</strong></td>
				</tr>
			   	</tbody>

			   	<tbody>
				<tr class="odd gradeX">
					<td>Keluhan Pasien</td>
					<td><input style="border: none;" type="text" class="form-control" name="keluhan" placeholder="keluhan pasien...">
					</td>
				</tr>
			   	</tbody>


			   	<link href='https://clinicaltables.nlm.nih.gov/autocomplete-lhc-versions/17.0.2/autocomplete-lhc.min.css' rel="stylesheet">
				<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
				<script src='https://clinicaltables.nlm.nih.gov/autocomplete-lhc-versions/17.0.2/autocomplete-lhc.min.js'></script>

			   	<tbody>
				<tr class="odd gradeX">
					<td>Riwayat Penyakit Pasien</td>
					<td>
						<input style="border: none;" type="text" id="icd10" name="rpenyakit" placeholder="riwayat penyakit..(ICD.10)">
					</td>
					<script>
						new Def.Autocompleter.Search('icd10', 'https://clinicaltables.nlm.nih.gov/api/icd10cm/v3/search?sf=name,code',{tableFormat: true, valueCols: [0], colHeaders: ['Name','Code']});
					</script>             
				</tr>
			   	</tbody>

			   	<tbody>
				<tr class="odd gradeX">
					<td>Hasil Pemeriksaan Fisik dan Penunjang Medik Pasien</td>
					<td><input style="border: none;" type="text" class="form-control" name="hasilpempasien" placeholder="hasil pemeriksaan pasien...">
					</td>
				</tr>
			   	</tbody>

			   	<tbody>
				<tr class="odd gradeX">
					<td>Diagnosa</td>
					<td><input style="border: none;" type="text" class="form-control" name="diagnosa" placeholder="diagnosa pasien...">
					</td>
				</tr>
			   	</tbody>

			   	<tbody>
				<tr class="odd gradeX">
					<td>Pengobatan</td>
					<td>
						<form action="" method="POST">
				        <div class="input-group control-group after-add-more">
				          <select style="border: none;" class="form-control" name="dataobat[]">
						        <option value=''>Obat yang diberikan</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="SELECT * FROM dataobat";

						          $hasil=mysqli_query($konobat,$sql);
						          
						          while ($obatdata = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obatdata['nama_obt'];?>"><?php echo $obatdata['nama_obt'];?></option>
						        <?php } ?>
						    </select>
				          <div class="input-group-btn"> 
				            <button class="btn btn-primary add-more" type="button">Tambah</button>
				          </div>
				        </div>
				        </form>
				        <!-- Copy Fields -->
				        <div class="copy hide">
				          <div class="control-group input-group" style="margin-top:10px">
				          	<select style="border: none;" class="form-control" name="dataobat[]">
						        <option value=''>Obat yang diberikan</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="SELECT * FROM dataobat";

						          $hasil=mysqli_query($konobat,$sql);
						          
						          while ($obatdata = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obatdata['nama_obt'];?>"><?php echo $obatdata['nama_obt'];?></option>
						        <?php } ?>
						    </select>
				            <div class="input-group-btn"> 
				              <button class="btn btn-primary remove" type="button">Hapus</button>
				            </div>
				          </div>
				       
						<script type="text/javascript">
						    $(document).ready(function() {
						      $(".add-more").click(function(){ 
						          var html = $(".copy").html();
						          $(".after-add-more").after(html);
						      });
						      $("body").on("click",".remove",function(){ 
						          $(this).parents(".control-group").remove();
						      });
						    });
						</script>						   
					</td>
				</tr>
			   	</tbody>
	 			   
			   	<tbody>
				<tr class="odd gradeX">
					<td><strong>Persetujuan Tindakan Apabila Diperlukan</strong></td>
				</tr>
			   	</tbody>

			   	<tbody>
				<tr class="odd gradeX">
					<td>Persetujuan Tindakan</td>
					<td><input style="border: none;" type="text" class="form-control" name="pertindakan" placeholder="persetujuan tindakan pasien...">
					</td>
				</tr>
			   	</tbody>

			   	<tbody>
				<tr class="odd gradeX">
					<td>Pelayanan Lain</td>
					<td><input style="border: none;" type="text" class="form-control" name="pelain" placeholder="pelayanan lain kepada pasien...">
					</td>
				</tr>
			   	</tbody>
			   	
			   	</table>

			 

			 <table class="table  table-bordered" class="table-condensed" id="">
			  <thead style="background-color: yellow">
				<tr>
					<th><center>FORMULIR ODONTOGRAM <br> KHUSUS PASIEN GIGI</center></th>
				</tr>
			   </thead>

			   <tbody>
			   	<tr class="odd gradeX">
					<td><?php include "odontogram.php"; ?></td>
				</tr>
				</tbody>
			   </table>



							   	
			 </table>
			 </form>

			 <div>
				<button type="submit" name="input1" class="btn btn-primary" >Proses</button>
			</div>




		















		