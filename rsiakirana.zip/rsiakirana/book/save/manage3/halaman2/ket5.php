<?php
	include "koneksi.php";
	if (mysqli_connect_errno()) {
	    trigger_error('Koneksi ke database gagal: '  . mysqli_connect_error(), E_USER_ERROR); 
	}
?>
<br>
<div class="container">
<div class="row">
<div class="col-md- col-sm-8">
			 
<form name="form_stafsdm" action="" method="post" enctype="multipart/form-data">

  <div class="form-group">
    <label for="diklat">Diklat</label>
    <input type="text" class="form-control" id="" placeholder="..." name="diklat">
  </div>

	

  <div class="form-group">
    <label for="keterangan">Tanggal Input</label>
    <input type="date" class="form-control" id="" placeholder="..." name="tanggal">
  </div>

  

  <div class="form-group">
    <button type="submit" class="btn btn-primary" name="tambah">Input</button>
   	<button type="reset" class="btn btn-danger">Batal</button>
  </div>
</form>
	
</div>
</div>
</div>
<br>
<br>

<?php
if(isset($_POST['tambah'])) {
$diklat = $_POST['diklat'];
$tanggal = $_POST['tanggal'];
	
							// Insert user data into table
							$query="INSERT INTO ket5 SET diklat='$diklat', tanggal='$tanggal'";
							mysqli_query($koneksi, $query); 
	
echo "<script>alert('Data Berhasil ditambahkan');window.location=''</script>";
}
?>

