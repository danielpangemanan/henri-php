<?php 
include "./koneksi.php";
?>

<div class="main-grid">
			<div class="agile-grids">	
				
			<h3 style="text-align: center;">DATA DOKTER</h3>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th>DOKTER</th>
				 <th>Nama Dokter</th>
				 <th>Spesialis</th>
				 <th>Alamat</th>
				 <th>Nomor Induk</th>
				</tr>
					
				<?php
				
				$sql = $koneksi->query("SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%' ");
				while ($data=$sql->fetch_assoc())
				{
				?>											
					
				<tr>
				 <td></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['kompetensi'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['alamat'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nis'];?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div>