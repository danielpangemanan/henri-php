<?php
include "conaset.php";
?>


<br>

<div>
<h2 align="center">ASET TIDAK BERGERAK</h2>
<br>

<div class="container-fluid">
<div class="table-responsive">
<table class="table table-bordered table-hover">
 <thead style="background-color: orange">
		<tr>
			<th>Bangunan</th>
			<th>No</th>
			<th>Aset</th>
			<th>Jenis</th>
			<th>Mata Anggaran</th>
			<th>Tanggal Masuk</th>
			<th>Detail</th>
		</tr>
	</thead>
	<tbody>

		<?php 

			$id=0;
			$sql = $koneksi->query("select *from medkesne_rsudaset1");
			$sql = $koneksi->query("SELECT * FROM aset2 WHERE keterangan LIKE '%bangunan%' ORDER BY id ASC");
			while ($data=$sql->fetch_assoc()) {



		?>

		<tr class="odd gradeX">
			<td></td>
			<td><?php echo $id+1; ?></td>
			<td><?php echo $data['kode_aset']; ?></td>
			<td><?php echo $data['nama']; ?></td>
			<td><?php echo $data['anggaran']; ?></td>
			<td><?php echo $data['tanggal_masuk']; ?></td>
			<td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=detail2&kode_aset=<?php echo $data['kode_aset'];?>">Lihat Detail</a></td>

		</tr>

		<?php

			$id++; 
			$data['kode_aset'];
			$data['nama'];
			$data['anggaran'];
			$data['tanggal_masuk'];
		}

		?>
	   </tbody>
	 </table>
	</div>
<br>

</div>	

</div>


<div class="container-fluid">
<div class="table-responsive">
<table class="table table-bordered table-hover">
 <thead style="background-color: orange">
		<tr>
			<th>Alat Kesehatan</th>
			<th>No</th>
			<th>Aset</th>
			<th>Jenis</th>
			<th>Mata Anggaran</th>
			<th>Tanggal Masuk</th>
			<th>Detail</th>
		</tr>
	</thead>
	<tbody>


		<?php 

			$id=0;
			$sql = $koneksi->query("select *from medkesne_rsudaset1");
			$sql = $koneksi->query("SELECT * FROM aset2 WHERE keterangan LIKE '%alat kesehatan%' ORDER BY id ASC");
			while ($data=$sql->fetch_assoc()) {



		?>

		<tr class="odd gradeX">
			<td></td>
			<td><?php echo $id+1; ?></td>
			<td><?php echo $data['kode_aset']; ?></td>
			<td><?php echo $data['nama']; ?></td>
			<td><?php echo $data['anggaran']; ?></td>
			<td><?php echo $data['tanggal_masuk']; ?></td>
			<td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=detail2&kode_aset=<?php echo $data['kode_aset'];?>">Lihat Detail</a></td>

		</tr>

		<?php

			$id++; 
			$data['kode_aset'];
			$data['nama'];
			$data['anggaran'];
			$data['tanggal_masuk'];
		}

		?>
	   </tbody>
	 </table>
	</div>
</div>
<br>

<div class="container-fluid">
<div class="table-responsive">
<table class="table table-bordered table-hover">
 <thead style="background-color: orange">
		<tr>
			<th>Alat Lain</th>
			<th>No</th>
			<th>Aset</th>
			<th>Jenis</th>
			<th>Mata Anggaran</th>
			<th>Tanggal Masuk</th>
			<th>Detail</th>
		</tr>
	</thead>
	<tbody>


		<?php 

			$id=0;
			$sql = $koneksi->query("select *from medkesne_rsudaset1");
			$sql = $koneksi->query("SELECT * FROM aset2 WHERE keterangan LIKE '%alat lain-lain%' ORDER BY id ASC");
			while ($data=$sql->fetch_assoc()) {



		?>

		<tr class="odd gradeX">
			<td></td>
			<td><?php echo $id+1; ?></td>
			<td><?php echo $data['kode_aset']; ?></td>
			<td><?php echo $data['nama']; ?></td>
			<td><?php echo $data['anggaran']; ?></td>
			<td><?php echo $data['tanggal_masuk']; ?></td>
			<td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=detail2&kode_aset=<?php echo $data['kode_aset'];?>">Lihat Detail</a></td>

		</tr>

		<?php

			$id++; 
			$data['kode_aset'];
			$data['nama'];
			$data['anggaran'];
			$data['tanggal_masuk'];
		}

		?>
	   </tbody>
	 </table>
	</div>
</div>
<br>

<div class="container-fluid">
<div class="table-responsive">
<table class="table table-bordered table-hover">
 <thead style="background-color: orange">
		<tr>
			<th>Barang Lain-lain</th>
			<th>No</th>
			<th>Aset</th>
			<th>Jenis</th>
			<th>Mata Anggaran</th>
			<th>Tanggal Masuk</th>
			<th>Detail</th>
		</tr>
	</thead>
	<tbody>


		<?php 

			$id=0;
			$sql = $koneksi->query("select *from medkesne_rsudaset1");
			$sql = $koneksi->query("SELECT * FROM aset2 WHERE keterangan LIKE '%barang lain-lain%' ORDER BY id ASC");
			while ($data=$sql->fetch_assoc()) {



		?>

		<tr class="odd gradeX">
			<td></td>
			<td><?php echo $id+1; ?></td>
			<td><?php echo $data['kode_aset']; ?></td>
			<td><?php echo $data['nama']; ?></td>
			<td><?php echo $data['anggaran']; ?></td>
			<td><?php echo $data['tanggal_masuk']; ?></td>
			<td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=detail2&kode_aset=<?php echo $data['kode_aset'];?>">Lihat Detail</a></td>
			
		</tr>

		<?php

			$id++; 
			$data['kode_aset'];
			$data['nama'];
			$data['anggaran'];
			$data['tanggal_masuk'];
		}

		?>
	   </tbody>
	 </table>
	</div>


</div>
<br>







