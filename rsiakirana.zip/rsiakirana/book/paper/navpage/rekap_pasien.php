

	
	       
        <div class="main-grid">
            <div class="agile-grids">   
                <div class="grids">
                    <div class="progressbar-heading grids-heading">
                    </div>
                    <div class="panel panel-widget forms-panel">
                        <br>
                        <h2 style="color: black; text-align: center;">DATA PASIEN</h2>
                        <br>
                        <div class="forms">
                            <div class="form-grids widget-shadow" data-example-id="basic-forms"> 
                                    	<div class="form-title">
                                            <form action="#" method="post">
												<input type="text" name="kode" value="Cari Data Pasien" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}" >
												<button class="button" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
											</form>	
                                        </div>

                                        <div class="agile-tables">
                                            <div class="w3l-table-info">
                                               <table id="table" class="table table-bordered">
                                                <thead>
                                                  <tr style="background-color: orange">
                                                     <th>Nama Pasien</th>
													 <th>ID Registrasi</th>
													 <th>Nomor Rekam Medis</th>
													 <th>Tanggal Masuk Pasien</th>
													 <th>NIK</th>
													 <th>Status Pasien</th>	
													 <th>Dokter</th>
													 <th>Poli Tujuan</th>
													 <th>Pembiayaan</th>
													 <th>Jaminan</th>
													 <th>Proses</th>

													</tr>
														<?php 
														
														$sql = $koneksi->query("SELECT * FROM tbl_pasien ORDER BY no_rekamedis DESC");
										
														while ($data=$sql->fetch_assoc()) {
														?>									
													<tr>
													 
													 <td bgcolor="#ffffff"><?php echo $data['nama_pasien'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['id_registrasi'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['no_rekamedis'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['tanggal_masuk'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['nik'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['status_pasien'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['dokter'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['tujuan'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['pembiayaan'];?></td>
													 <td bgcolor="#ffffff"><?php echo $data['jaminan_pasien'];?></td>
													 <td bgcolor="#ffffff">
													 	<a href="/rsiakirana/aksesadmin/manage3/halaman4/printoutpasien.php&kode=<?php echo $data['no_rekamedis'];?>" class="label label-info">Print</a>
													 	
													 </td>
													</tr>
													<?php
													
													}
													?>
				
                                                </tbody>
                                              </table>
                                        </div>
                            </div>
                        </div>                            
                </div>
            </div>
        </div>
        <br>
        

        
		
	

	