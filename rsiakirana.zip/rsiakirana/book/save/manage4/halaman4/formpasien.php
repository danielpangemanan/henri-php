
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>RSIA KIRANA</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
 

  <div id="card">
    
    <div id="card-content">
      <div id="card-title">
        <h3>PENDAFTARAN PASIEN</h3>
        <br>
      </div>
      <form method="post" class="form" action="">
        <label for="nama_pasien" style="padding-top:13px">
            &nbsp;Nama Pasien
          </label>
        <input id="underline-title" class="form-content" type="nama_pasien" name="nama_pasien" autocomplete="on" required />
        <div class="underline-title1"></div>

        <label for="alamat" style="padding-top:22px">&nbsp;Alamat
          </label>
        <input id="underline-title" class="form-content" type="alamat" name="alamat" required />
        <div class="underline-title1"></div>

        <label for="ttl" style="padding-top:22px">&nbsp;Tempat, Tgl Lahir
          </label>
        <input id="underline-title" class="form-content" type="ttl" name="ttl" required />
        <div class="underline-title1"></div>

        <label for="jenis_kelamin" style="padding-top:22px">&nbsp;Jenis Kelamin</label>
        <select name="jenis_kelamin" class="form-control" name="jenis_kelamin" style="border:none" required>
          <option value="tidak di isi">...::...</option>
          <option value="Laki-laki">Laki-laki</option>
          <option value="Perempuan">Perempuan</option>
          <option value="Tidak Diketahui">Tidak Diketahui</option>
        </select>
        <div class="underline-title1"></div>
        
        <input id="submit-btn" type="submit" name="submit" value="DAFTAR"/>
      </form>
    </div>
  </div>

</body>

</html>

<style>
  a {
  text-decoration: none;
}
h3 {
  text-decoration: none;
}
body {
  background: -webkit-linear-gradient(bottom, #62adb5, #7beff7);
  background-repeat: no-repeat;
}
label {
  font-family: "Raleway", sans-serif;
  font-size: 11pt;
}
#forgot-pass {
  color: red;
  font-family: "Raleway", sans-serif;
  font-size: 10pt;
  margin-top: 3px;
  text-align: right;
}
#card {
  background: #fbfbfb;
  border-radius: 8px;
  box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
  height: 600px;
  margin: 6rem auto 8.1rem auto;
  width: 400px;
}
#card-content {
  padding: 8px 33px;
}
#card-title {
  font-family: "Raleway Thin", sans-serif;
  letter-spacing: 2px;
  padding-bottom: 2px;
  text-align: center;
}
#signup {
  color: #62adb5;
  font-family: "Raleway", sans-serif;
  font-size: 10pt;
  margin-top: 16px;
  text-align: center;
}
#submit-btn {
  background: -webkit-linear-gradient(right, #62adb5, #7beff7);
  border: none;
  border-radius: 21px;
  box-shadow: 0px 1px 8px #24c64f;
  cursor: pointer;
  color: white;
  font-family: "Raleway SemiBold", sans-serif;
  height: 42.3px;
  margin: 0 auto;
  margin-top: 50px;
  transition: 0.25s;
  width: 153px;
}
#submit-btn:hover {
  box-shadow: 0px 1px 18px #62adb5;
}
.form {
  align-items: left;
  display: flex;
  flex-direction: column;
}
.form-border {
  background: -webkit-linear-gradient(right, #a6f77b, #2ec06f);
  height: 1px;
  width: 100%;
}
.form-content {
  background: #fbfbfb;
  border: none;
  outline: none;
  padding-top: 14px;
}
.underline-title {
  background: -webkit-linear-gradient(right, #62adb5, #7beff7);
  height: 2px;
  margin: -1.1rem auto 0 auto;
  width: 90px;
}
.underline-title1 {
  background: -webkit-linear-gradient(right, #62adb5, #7beff7);
  height: 2px;
  width: 100%;
  margin-top: 8px;
}
</style>


<?php
include "../koneksi.php";

if(isset($_POST['submit'])) {
$nama_pasien= $_POST['nama_pasien'];
$alamat= $_POST['alamat'];
$ttl=$_POST['ttl'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$jam_datang = date('l, d-m-Y  h:i:s a');
//$gambar=$_POST['gambar'];

// Insert user data into table
$query="INSERT INTO pasien SET nama_pasien='$nama_pasien', alamat='$alamat', ttl='$ttl', jenis_kelamin='$jenis_kelamin', jam_datang='$jam_datang'";
mysqli_query($koneksi, $query);  
  		
echo "<script>alert('Data Anda Atas Nama :$nama_pasien Sudah Terdaftar')'</script>";
}
?>