<!DOCTYPE html>
<html>
<head>
	<title>VERIFIKASI DPA</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
 
	<h1>MASUKKAN KODE VERIFIKASI</h1>

	<?php 
	if(isset($_GET['pesan'])){
		if($_GET['pesan']=="gagal"){
			echo "<div class='alert'>Username dan Password tidak sesuai !</div>";
		}
	}
	?>
 
	<div class="kotak_login">
		<p class="kode">KODE</p>
 
		<form action="cek_login.php" method="post">
			<label>user</label>
			<input type="text" name="username" class="form_login" placeholder="..." required="required">
 
			<label>nomor kode</label>
			<input type="password" name="password" class="form_login" placeholder="..." required="required">
 
			<input type="submit" class="tombol_login" value="open">
 
			<br/>
			<br/>
			<center>
				<a class="link" href="#">SIM@RS-ADMIN</a>
			</center>
		</form>
		
	</div>
 
 
</body>
</html>