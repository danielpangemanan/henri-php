
<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) {
			
			
			case 'spv1':
				include "halaman3/spvkeu1.php";
				break;
			case 'spv2':
				include "halaman3/spvkeu2.php";
				break;


			case 'konf1':
				include "halaman3/konfirmspv1.php";
				break;
			case 'konf2':
				include "halaman3/konfirmspv2.php";
				break;
			
				
				
			default:
				echo "<center>
				<div>
				<img src='images/maintenance.jpg'>
				</div>
				</center>";
				break;
		}
	}else{
		include "managespv.php";
	}
 
	 ?>