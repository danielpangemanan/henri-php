<?php
	include "koneksi.php";
	if (mysqli_connect_errno()) {
	    trigger_error('Koneksi ke database gagal: '  . mysqli_connect_error(), E_USER_ERROR); 
	}
?>
<br>
<div class="container">
<div class="row">
<div class="col-md- col-sm-8">
			 
<form name="form_stafsdm" action="" method="post" enctype="multipart/form-data">

  <div class="form-group">
    <label for="pendidikan">Pendidikan</label>
    <input type="text" class="form-control" id="kompetensi" placeholder="..." name="pendidikan">
  </div>

	

  <div class="form-group">
    <label for="keterangan">Tanggal Input</label>
    <input type="date" class="form-control" id="" placeholder="..." name="tanggal">
  </div>

  

  <div class="form-group">
    <button type="submit" class="btn btn-primary" name="tambah">Input</button>
   	<button type="reset" class="btn btn-danger">Batal</button>
  </div>
</form>
	
</div>
</div>
</div>
<br>
<br>

<?php
if(isset($_POST['tambah'])) {
$pendidikan = $_POST['pendidikan'];
$tanggal = $_POST['tanggal'];
	
							// Insert user data into table
							$query="INSERT INTO ket2 SET pendidikan='$pendidikan', tanggal='$tanggal'";
							mysqli_query($koneksi, $query); 
	
echo "<script>alert('Data Berhasil ditambahkan');window.location=''</script>";
}
?>

