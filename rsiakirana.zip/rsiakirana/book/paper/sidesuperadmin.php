
		
		

		<?php 
		$kode=$_SESSION['level'];
		$user = mysqli_query($koneksi, "SELECT * from modul where m_modul='$kode' and modul='Y'");
		while ($ev=mysqli_fetch_array($user)) {
		?>


		<?php include "$ev[keterangan].php"; ?>
		
		<?php } ?>