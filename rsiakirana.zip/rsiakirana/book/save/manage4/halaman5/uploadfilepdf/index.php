<?php

include_once("../koneksi.php");

$jenis = $_GET['jenis'];

$result = mysqli_query($koneksi, "SELECT FROM arsip WHERE jenis=$jenis");

?>

<br>
<br>

<div class="container-fluid">
    <div class="col-md-10">
        <form action="/rsiakirana/aksesadmin/manage1/halaman6/uploadfilepdf/upload.php" method="post" enctype="multipart/form-data">
        <table class="table table-bordered">
        <td>
        <h4>File PDF</h4>
        <input type="file" name="file" size="100" required>
        </td>
        
        <input type="hidden" name="judul" value="<?php echo $jenis;?>">
        
        <br />
        
        <td>
        <h4>Nama File</h4>
        <input type="text" name="nama_file" placeholder="nama file pdf" size="60" required>
        <h6>nama file harus sesuai dengan nama file pdf yang akan di upload</h6>
        </td>
        
        <br />
        
        <td>
        <h4>Tanggal Upload</h4>
        <input type="date" name="tanggal" required>
        <br />
        <br>
        </td>
        
        </table>
        
        <input type="submit" name="input" value="UPLOAD" >
        </form>
        
    </div>
</div>








