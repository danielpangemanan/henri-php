<?php
include "conroom.php";
 ?>


<div class="main-grid">
	<div class="agile-grids">	

	<div class="chart-heading">
	<h2>DATA RUANGAN</h2>
	</div>

	<div class="col-md-12" style="text-align: center">
	<div class="area-grids">
	<div class="container-fluid">
						   <div class="table-responsive">
							 <table class="table table-bordered table-hover">

							 			<?php 
											include "conroom.php";

											// AmbilData 2 tabel
											$ambildata=mysqli_query($koneksi, "SELECT * FROM data_ruangan order by id_data asc");
											while($data=mysqli_fetch_array($ambildata)) {
										?>

								 	<thead></thead>
										
									<tbody>

										<tr>

											<td><strong><?php echo $data['keterangan']; ?></strong></td>

											<td>Total Bed:&nbsp<strong><?php echo $data['jumlah_ruangan']; ?></strong></td>

											<td>Harga:&nbsp<strong><?php echo "Rp." . number_format($data['harga']).",-"; ?></strong></td>

										</tr>

										<?php } ?>

									</tbody>
							</table>
						</div>
					</div>
				</div>



			

																		
					
					
					
					
					
	
		 