

<?php
	
	
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");
	}else{
		echo "PASIEN BELUM DIPROSES || MOHON HUBUNGI BAGIAN REKAM MEDIS";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
   		<div class="table-responsive">
			
				<table class="table  table-bordered" class="table-condensed" id="">
					<thead style="background-color: lightgrey">
					<tr>
						<th><h3 style="text-align: center">REKAM MEDIS PASIEN</h3></th>
						<th style="text-align: center"></th>
						<th style="text-align: center">N.R.Medis:<?php echo $data['no_rekamedis']; ?></th>
					</tr>
		   			<tr>
						<th><center>DATA PASIEN</center></th>
						<th><center>Keterangan</center></th>
						<th><center>#</center></th>
					</tr>
				   </thead>

				   <tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Rekamedis</td>
						<td><?php echo $data['no_rekamedis']; ?></td>
						<td><strong>Dokter:&nbsp<?php echo $data['dokter']; ?></strong></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Induk Kependudukan</td>
						<td><?php echo $data['nik']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Pasien</td>
						<td><?php echo $data['nama_pasien']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Jenis Kelamin</td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Golongan Darah</td>
						<td><?php echo $data['golongan_darah']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Tempat, Tanggal Lahir</td>
						<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Alamat</td>
						<td><?php echo $data['alamat']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Ibu Kandung</td>
						<td><?php echo $data['nama_ibu']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Agama</td>
						<td><?php echo $data['agama']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Status</td>
						<td><?php echo $data['status_menikah']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Telp/Hp</td>
						<td><?php echo $data['no_hp']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pekerjaan</td>
						<td><?php echo $data['id_pekerjaan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pembiayaan</td>
						<td><?php echo $data['pembiayaan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Ruang Penanganan Pasien</td>
						<td><?php echo $data['tujuan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Dokter Lain/Tambahan</td>
						<td><?php echo $data['dokter_lain']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Triage Pasien</td>
						<td><?php echo $data['triage']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Tindakan Rawat Pasien</td>
						<td style="background-color: yellow;"><?php echo $data['ruangan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   </table>
				
			</div>
				<center>
				<a class="btn btn-primary" href="/rsiakirana/aksesadmin/manage2/admindokter.php?page=psn1&kode=<?php echo $data['id_registrasi'];?>" class="label label-info">Proses Rawat Jalan</a>

				<a class="btn btn-primary" href="/rsiakirana/aksesadmin/manage2/admindokter.php?page=psn2&kode=<?php echo $data['id_registrasi'];?>" class="label label-info">Proses Rawat Inap dan Perawatan</a>

				<a class="btn btn-primary" href="/rsiakirana/aksesadmin/manage2/admindokter.php?page=psn3&kode=<?php echo $data['id_registrasi'];?>" class="label label-info">Proses Gawat Darurat</a>
				</center>
		 		<?php } ?>
	</div>
</div>
<hr>



<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
</style>



				


