

<?php
	include "koneksibarcode.php";

	
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where id_registrasi='$no'");
	}
	while($data = mysqli_fetch_array($sql)){

?>

<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
   		<div class="table-responsive">
			<form method="POST">
				<table class="table  table-bordered" class="table-condensed" id="">
					<thead style="background-color: lightgrey">
					<tr>
						<th><h3 style="text-align: center">REKAM MEDIS PASIEN</h3></th>
						<th style="text-align: center"></th>
						<th style="text-align: center">Nomor Registrasi:<?php echo $data['id_registrasi']; ?></th>
					</tr>
		   			<tr>
						<th><center>DATA PASIEN</center></th>
						<th><center>Keterangan</center></th>
						<th><center>#</center></th>
					</tr>
				   </thead>

				   <tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Rekamedis</td>
						<td><?php echo $data['no_rekamedis']; ?></td>
						<td><strong>Dokter:&nbsp<?php echo $data['dokter']; ?></strong></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Induk Kependudukan</td>
						<td><?php echo $data['nik']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Pasien</td>
						<td><?php echo $data['nama_pasien']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Jenis Kelamin</td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Golongan Darah</td>
						<td><?php echo $data['golongan_darah']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Tempat, Tanggal Lahir</td>
						<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Alamat</td>
						<td><?php echo $data['alamat']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nama Ibu Kandung</td>
						<td><?php echo $data['nama_ibu']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Agama</td>
						<td><?php echo $data['agama']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Status</td>
						<td><?php echo $data['status_menikah']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Nomor Telp/Hp</td>
						<td><?php echo $data['no_hp']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pekerjaan</td>
						<td><?php echo $data['id_pekerjaan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Pembiayaan</td>
						<td><?php echo $data['pembiayaan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Ruang Penanganan Pasien</td>
						<td><?php echo $data['tujuan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Dokter Lain/Tambahan</td>
						<td><?php echo $data['dokter_lain']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Triage Pasien</td>
						<td><?php echo $data['triage']; ?></td>
						<td></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<td>Tindakan Rawat Pasien</td>
						<td><?php echo $data['ruangan']; ?></td>
						<td></td>
					</tr>
				   	</tbody>
				 	<!--FORM TUTUP DI AKHIR-->
		


					<!--INPUT HIDDEN DATA PASIEN-->
				 	<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">
				 	<input type="hidden" class="form-control" name="id_registrasi" value="<?php echo $data['id_registrasi'];?>">
				 	<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">
				 	<input type="hidden" class="form-control" name="nama_pasien" value="<?php echo $data['nama_pasien'];?>">
				 	<input type="hidden" class="form-control" name="jenis_kelamin" value="<?php echo $data['jenis_kelamin'];?>">
				 	<input type="hidden" class="form-control" name="golongan_darah" value="<?php echo $data['golongan_darah'];?>">
				 	<input type="hidden" class="form-control" name="tempat_lahir" value="<?php echo $data['tempat_lahir'];?>">
					<input type="hidden" class="form-control" name="tanggal_lahir" value="<?php echo $data['tanggal_lahir'];?>">
					<input type="hidden" class="form-control" name="alamat" value="<?php echo $data['alamat'];?>">
					<input type="hidden" class="form-control" name="nama_ibu" value="<?php echo $data['nama_ibu'];?>">
					<input type="hidden" class="form-control" name="agama" value="<?php echo $data['agama'];?>">
					<input type="hidden" class="form-control" name="status_menikah" value="<?php echo $data['status_menikah'];?>">
					<input type="hidden" class="form-control" name="no_hp" value="<?php echo $data['no_hp'];?>">
					<input type="hidden" class="form-control" name="id_pekerjaan" value="<?php echo $data['id_pekerjaan'];?>">

					<input type="hidden" class="form-control" name="dokter" value="<?php echo $data['dokter'];?>">
					<input type="hidden" class="form-control" name="pembiayaan" value="<?php echo $data['pembiayaan'];?>">
					<input type="hidden" class="form-control" name="tujuan" value="<?php echo $data['tujuan'];?>">
					<input type="hidden" class="form-control" name="dokter_lain" value="<?php echo $data['dokter_lain'];?>">
					<input type="hidden" class="form-control" name="triage" value="<?php echo $data['triage'];?>">
					<input type="hidden" class="form-control" name="ruangan" value="<?php echo $data['ruangan'];?>">
					
				<?php } ?>
				<br>
				<!--FORM DOKTER PASIEN RAWAT JALAN-->
				<?php include "form_detailpasien1.php"; ?>
		</div>
	</div>
</div>
<hr>



<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
</style>



 <?php

 	include "koneksibarcode.php";

	   if(isset($_POST['input1'])) {
	  	$no_rekamedis=$_POST['no_rekamedis'];
		$id_registrasi= $_POST['id_registrasi'];
		$nik= $_POST['nik'];
		$nama_pasien=$_POST['nama_pasien'];
		$jenis_kelamin=$_POST['jenis_kelamin'];
		$golongan_darah=$_POST['golongan_darah'];
		$tempat_lahir=$_POST['tempat_lahir'];
		$tanggal_lahir=$_POST['tanggal_lahir'];
		$nama_ibu=$_POST['nama_ibu'];
		$alamat=$_POST['alamat'];
		$agama=$_POST['agama'];
		$status_menikah=$_POST['status_menikah'];
		$no_hp=$_POST['no_hp'];
		$id_pekerjaan=$_POST['id_pekerjaan'];
		$dokter=$_POST['dokter'];
		$tujuan=$_POST['tujuan'];
		$pembiayaan=$_POST['pembiayaan'];
		$dokter_lain=$_POST['dokter_lain'];
		$triage=$_POST['triage'];
		$ruangan=$_POST['ruangan'];
		$tglperiksa=$_POST['tglperiksa'];
		$keluhan=$_POST['keluhan'];
		$rpenyakit=$_POST['rpenyakit'];
		$hasilpempasien=$_POST['hasilpempasien'];
		$diagnosa=$_POST['diagnosa'];
		$pertindakan=$_POST['pertindakan'];
		$pelain=$_POST['pelain'];

		// Insert user data into table
		$input = mysqli_query($koneksi, "INSERT INTO tbl_pasienrinap (no_rekamedis,id_registrasi,nik,nama_pasien,jenis_kelamin,golongan_darah,tempat_lahir,tanggal_lahir,nama_ibu,alamat,agama,status_menikah,no_hp,id_pekerjaan,dokter,tujuan,pembiayaan,dokter_lain,triage,tglperiksa,ruangan,keluhan,rpenyakit,hasilpempasien,diagnosa,pertindakan,pelain) 

			VALUES('$no_rekamedis','$id_registrasi','$nik','$nama_pasien','$jenis_kelamin','$golongan_darah','$tempat_lahir','$tanggal_lahir','$nama_ibu','$alamat','$agama','$status_menikah','$no_hp','$id_pekerjaan','$dokter','$tujuan','$pembiayaan','$dokter_lain','$triage','$tglperiksa','$ruangan','$keluhan','$rpenyakit','$hasilpempasien','$diagnosa','$pertindakan','$pelain')"); 
		  		
		echo "<script>alert('data pasien $nama_pasien akan diproses');window.location='../manage2/admindokter.php?page=datapasien'</script>";
		
	  }
	?>
	

	<?php
		$connect = mysqli_connect("localhost", "root", "", "medkesne_rsudsdm1");  
		$input = $_POST['dataobat'];
		if (is_array($input) || is_object($input))
		{
			foreach ($input as $output) {
			    mysqli_query($connect,"INSERT into dataobatpasien (no_rekamedis,id_registrasi,dataobat) Values('$no_rekamedis','$id_registrasi','$output')");
			}
		}
	?>

				


