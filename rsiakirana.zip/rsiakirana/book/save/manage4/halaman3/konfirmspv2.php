<?php 
include "./koneksi.php"; 
$nomor = $_GET['nomor'];
$update = mysqli_query($koneksi, "UPDATE tabel_pesan1 SET sudahbaca='YES'
WHERE nomor=$nomor ");
?>

<script>
setTimeout(function() {
  window.location.href = "/rsiakirana/aksesadmin/manage4/spvkasir?page=spv2";
}, 500);
</script>