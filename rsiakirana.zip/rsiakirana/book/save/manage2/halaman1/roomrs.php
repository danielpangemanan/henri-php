<?php
include "conroom.php";
 ?>


<div class="main-grid">
	<div class="agile-grids">	

	<div class="chart-heading">
	<h2>DATA RUANGAN</h2>
	</div>

	<div class="col-md-12" style="text-align: center">
	<div class="area-grids">
	<div class="container-fluid">
						   <div class="table-responsive">
							 <table class="table table-bordered table-hover">

							 			<?php 
											include "conroom.php";

											// AmbilData 2 tabel
											$ambildata=mysqli_query($koneksi, "SELECT * FROM data_ruangan, ruangan where data_ruangan.id_data=ruangan.id_data order by id_ruangan asc");
											while($data=mysqli_fetch_array($ambildata)) {
										?>

								 	<thead></thead>
										
									<tbody>

										<tr>

											<td><strong><?php echo $data['nama']; ?></strong></td>

											<td>Total Bed:&nbsp<strong><?php echo $data['jumlah']; ?></strong></td>

											<td>Harga:&nbsp<strong><?php echo "Rp." . number_format($data['harga']).",-"; ?></strong></td>

										</tr>

										<?php } ?>

									</tbody>
							</table>
						</div>
					</div>
				</div>



			<div class="area-grids">
				<div class="container-fluid">
						   <div>


						Bed Tersisa di Ruang Bedah : &nbsp
						<?php
							include "conroom.php";
						?>					
							<?php 
							
							$sql = $koneksi->query("SELECT nama_pasien, SUM(id) AS total FROM `reservasi_ruangan` GROUP BY pesan_ruangan LIKE 'ruang bedah'");
							while ($data=$sql->fetch_assoc()) {
							
						?>
							
						
							<?php
							$totaldata=10-$data['total'];
							}
						?>
							
							<?php echo "$totaldata"; ?>

						<br>

							Bed Tersisa di Ruang ICU : &nbsp
						<?php
							include "conroom.php";
						?>					
							<?php 
							
							$sql = $koneksi->query("SELECT nama_pasien, SUM(id) AS total FROM `reservasi_ruangan` GROUP BY pesan_ruangan LIKE 'ruang icu'");
							while ($data=$sql->fetch_assoc()) {
							
						?>
							
						
							<?php
							$totaldata=15-$data['total'];
							}
						?>
							
							<?php echo "$totaldata"; ?>
												
						   				

							 				
						</div>
					</div>
				</div>


																		
					
					
					
					
					
	
		 