<?php 
include "koneksi.php";
?>

	<div class="main-grid">
		<div class="agile-grids">	
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th>REKAPAN PASIEN</th>
				 <th>Nomor R.Medis</th>
				 <th>NIK</th>
				 <th>Nama Pasien</th>
				 <th>Jenis Kelamin</th>
				 <th>Alamat</th>
				 <th>Dokter</th>
				 <th>Tujuan Awal</th>
				</tr>
					
				<?php
				
				$sql = $koneksi->query("select *from tbl_pasien1 order by id_registrasi asc");
				while ($data=$sql->fetch_assoc())
				{
				?>											
					
				<tr>
				 <td><a href="/rsudprovsulut/aksesadmin/manage1/adminrmedis.php?page=rekpsn&kode=<?php echo $data['id_registrasi'];?>" class="label label-info">Cetak Rekapan</a></td>
				 <td bgcolor="#ffffff"><?php echo $data['no_rekamedis'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nik'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama_pasien'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jenis_kelamin'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['alamat'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['dokter'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['tujuan'];?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div>
		</div>
	</div>

	<br>

	