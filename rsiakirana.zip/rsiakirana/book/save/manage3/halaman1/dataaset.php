



<div class="container">
	<h3>ASET RSUD</h3>
	<div class="row panel2">
		<div class="col-md-12 info-panel">
			<div class="row">
				<div class="col-lg-6" >
					<img style="display: block; margin: 0 auto; text-align: center; width: 70px; height: 70px;" src="/rsiakirana/images/logoadmin.png">

					<h3><a href="adminrs.php?page=aset1" class="label label-info">ASET BERGERAK</a></h3>
					
					<div class="list-group">
					    <a class="list-group-item list-group-item-primary"><strong>Ambulance:&nbsp 
					    	<?php include "readambulance.php"; ?> 
					    	Total:<?php echo "". $contambul; ?></strong>
					    </a>
					    <a class="list-group-item list-group-item-primary"><strong>Kendaraan Operasional:&nbsp
					    	<?php include "readopr.php"; ?> 
					    	Total:<?php echo "". $contopr; ?></strong>
					    </a>
					    <a class="list-group-item list-group-item-primary"><strong>Mobil Jenazah:&nbsp
					    	<?php include "readjnz.php"; ?> 
					    	Total:<?php echo "". $contjnz; ?></strong>
						</a>
					</div>					
				</div>

				<div class="col-lg-6" >
					<img style="display: block; margin: 0 auto; text-align: center; width: 70px; height: 70px;" src="/rsiakirana/images/logoadmin.png">
					<h3><a href="adminrs.php?page=aset2" class="label label-info">ASET TIDAK BERGERAK</a></h3>

					<div class="list-group">
					    <a class="list-group-item list-group-item-primary"><strong>Bangunan</strong></a>
					    <a class="list-group-item list-group-item-primary"><strong>Alat Kesehatan</strong></a>
					    <a class="list-group-item list-group-item-primary"><strong>Barang/Alat Lainnya</strong></a>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>



<style>

	.info-panel{
	background-color: lightyellow;
	box-shadow: 0 3px 8px rgba(0,0,0,0.5);
	border-radius: 12px;
	background-color: white;
	padding: 30px;
	}

	.paragraf1{
		margin-bottom: 100px;
		text-align: center;
	}

	.paragraf2{
	text-align: center;
	margin-top: 12px;
	}

	.info-panel img{
		width: 80px;
		height: 80px;
		margin-right: 20px;
		margin-bottom: 20px;
	}

	.info-panel h3{
		text-align: center;
		font-size: 22px;
		text-transform: uppercase;
		font-weight: bold;
	}

	h3{
		margin-top: 25px;
		text-align: center;
		font-size: 28px;
		text-transform: uppercase;
		font-weight: bold;
	}

	h4{
		margin-top: 25px;
		text-align: center;
		font-size: 16px;
		text-transform: uppercase;
		font-weight: bold;
	}
	a{
		margin-top: 15px;
		text-align: center;
	}

	.info{
		margin-top: 100px;
	}

	.dashboard{
		margin-top: 50px;
	}

	.panelhome{
		margin-top: 50px;
	}

	.panel2{
		margin-top: 25px;
		margin-bottom: 50px;
	}
</style>