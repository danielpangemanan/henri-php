<?php

$db = new Mysqli("localhost", "root", "", "medkesne_rsudaset1");
?>

<br>

	<?php

            if(isset($_GET["kode_aset"])){
                $search = mysqli_real_escape_string($db, $_GET['kode_aset']);
				$text=$_GET['kode_aset'];
				
                $query = $db->query("SELECT * FROM aset2 WHERE kode_aset LIKE '%$search%' ORDER BY id ASC");
            }
		
		
		 else {
                $query = $db->query("SELECT * FROM aset2 ORDER BY id ASC");
            }
		


            while($data = mysqli_fetch_assoc($query)) {
						

	?>

	<input type="hidden" class="form-control" name="id" value="<?php echo $data['id'];?>">  

<center>
	<strong align="center">Nama Aset:&nbsp<?php echo $data['nama']; ?></strong>
		<hr>
	<br>
</center>
<table class="table table-hover" style="background-color: white;">
  
  <thead>
	    <tr>
	      <th scope="col">Nomor Kode Aset</th>
	      <th scope="col">Keterangan Aset</th>
	      <th scope="col">Tanggal Masuk</th>
	      <th scope="col">Detail Aset</th>
	    </tr>
  </thead>
  <tbody>
	    <tr align="center">
	      <td><?php echo $data['kode_aset']; ?></td>
	      <td><?php echo $data['keterangan']; ?></td>
	      <td><?php echo $data['tanggal_masuk']; ?></td>
	      <td><a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=easet2&kode=<?php echo $data['id'];?>" class="label label-info">edit data</a>
	      	<br>
	      	<a href="/rsudprovsulut/aksesadmin/manage1/halaman2/delete.php?page=delete&nis=<?php echo $m['nis'];?>" class="label label-info" onclick="return confirm('DATA AKAN DIHAPUS?')">hapus data</a>
	      	<br>
			<a href="/rsudprovsulut/aksesadmin/manage1/halaman2/bar.php?page=bar&kode=<?php echo $m['nis'];?>" class="label label-info">cetak barcode</a>
			<br>
			<a href="/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=aset2" class="label label-info">kembali</a></td>
	    </tr>
  </tbody>
</table>

  

<?php } ?>
<br>