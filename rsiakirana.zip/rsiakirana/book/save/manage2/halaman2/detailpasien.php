

	

<br>
<?php
	

	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where no_rekamedis='$no'");
	echo "<h4>Catatan: Proses Pasien Sesuai dengan Nomor Registrasi</h4>";
	}else{
	echo "PASIEN BELUM DI PROSES";
	}
	while($data = mysqli_fetch_array($sql)){

?>



<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
	   		<div class="table-responsive">
				<form method="POST">
					<table class="table table-bordered">
						<thead>
						<tr style="background-color: salmon;">
							<th><h3 style="text-align: center">MENU KEUANGAN</h3></th>
							<th><h3 style="text-align: center">PROSES PEMBAYARAN PASIEN</h3></th>
						</tr>
			   			<tr>
							<th><center>DATA PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   </thead>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Registrasi</td>
							<td><strong><a href="/rsiakirana/aksesadmin/manage2/admindokter.php?page=idpsn1&kode=<?php echo $data['id_registrasi'];?>" class="label label-info"><?php echo $data['id_registrasi']; ?></a></strong></td>
						</tr>
					   	</tbody>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Rekamedis</td>
							<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Induk Kependudukan</td>
							<td><?php echo $data['nik']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Pasien</td>
							<td><?php echo $data['nama_pasien']; ?></td>
							
						</tr>
					   	</tbody>

					   	
					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Alamat</td>
							<td><?php echo $data['alamat']; ?></td>
							
						</tr>
					   	</tbody>

					   	
					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pembiayaan</td>
							<td><?php echo $data['pembiayaan']; ?></td>
							
						</tr>
					   	</tbody>
					 	<?php } ?>

					</table>
			
					</div>
				</form>


	</div>
</div>
<br>
<br>



<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
	
</style>



				


