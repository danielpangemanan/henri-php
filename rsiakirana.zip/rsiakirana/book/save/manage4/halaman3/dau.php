<?php
include "conkeu.php";
?>

<br>
<br>


								<section class="">
									

									<center><img src="/rsudprovsulut/images/logo.png"></center>
					  				<center><h4>DANA ALOKASI UMUM</h4></center>
									<center><h4>RSUD PROVINSI SULUT</h4></center>
									
									<hr>
											<div id="main">
											
												
														<div class="container-fluid">
														   <div class="table-responsive">
															   
																		<table class="table  table-bordered" class="table-condensed" id="">
															   			<tr>
																			
																			<th><center>KODE</center></th>
																			<th><center>JENIS ANGGARAN</center></th>
																			<th><center>JUMLAH (Rp.)</center></th>

																		</tr>
																		<tr>
																			<th><i><center>1</center></i></th>
																			<th><i><center>2</center></i></th>
																			<th><i><center>3</center></i></th>

																		</tr>
																			
																	   </thead>
																	   <tbody>
																		   
																	<?php 

																		$sql = $koneksi->query("select *from inputdau");
																		while ($data=$sql->fetch_assoc()) {

																	?>
																	

																	<tr class="odd gradeX">
																		
																		<td><center><?php echo $data['kode_dau']; ?></center></td>
																		<td><center><?php echo $data['jenis_dau']; ?></center></td>
																		<td align="left"><center><?php echo "Rp." . number_format($data['jumlah_dau']).",-"; ?></center></td>
																		

																	</tr>
																	
																		   
																 	<?php

																		
																	}

																	?>

																   </tbody>
															   		
																 </table>
																		<?php 


																				$sql = $koneksi->query("select *from inputdau ");
																				while ($data=$sql->fetch_assoc()) {

																			?>
																			<?php
																				$total_dau=@$total_dau+$data['jumlah_dau'];
																			   // $saldo_akhir=$total_masuk-$total_keluar;
																				}
																			?>
																		
																		<td><center><b>Jumlah Belanja&nbsp;&nbsp;<?php echo "Rp." .number_format($total_dau).",-";?>
																		</b></center></td>
																</div>
															</div>
															
															
															
													</div>
												</div>
										</div>
								</section>
						
</div>
<br>
<br>


