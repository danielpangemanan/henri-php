<?php 
include "koneksi.php";
?>

<?php
include "koneksibarcode.php"; 
$cekdulu= "select * from tbl_pasien where no_rekamedis='$_POST[no_rekamedis]'"; 
$prosescek= mysqli_query($koneksi, $cekdulu);
if (mysqli_num_rows($prosescek)>0) { //proses mengingatkan data sudah ada
    echo "<script>alert('Kode Pasien sdh digunakan'); </script>";
}
else { 

include('bar128.php');
echo '<div style="border:3px double #ababab; padding:10px;margin:10px auto;width:400px;">';

		$no_rekamedis= $_POST['no_rekamedis'];
		$nama_pasien=$_POST['nama_pasien'];
		$jenis_kelamin=$_POST['jenis_kelamin'];
		$golongan_darah=$_POST['golongan_darah'];
		$tempat_lahir=$_POST['tempat_lahir'];
		$tanggal_lahir=$_POST['tanggal_lahir'];
		$nama_ibu=$_POST['nama_ibu'];
		$alamat=$_POST['alamat'];
		$agama=$_POST['agama'];
		$status_menikah=$_POST['status_menikah'];
		$no_hp=$_POST['no_hp'];
		$id_pekerjaan=$_POST['id_pekerjaan'];
		$dokter=$_POST['dokter'];
		$tujuan=$_POST['tujuan'];
		$pembiayaan=$_POST['pembiayaan'];

$query="INSERT INTO tbl_pasien SET no_rekamedis='$no_rekamedis', nama_pasien='$nama_pasien', jenis_kelamin='$jenis_kelamin', golongan_darah='$golongan_darah', tempat_lahir='$tempat_lahir', tanggal_lahir='$tanggal_lahir', nama_ibu='$nama_ibu', alamat='$alamat', agama='$agama', status_menikah='$status_menikah', no_hp='$no_hp', id_pekerjaan='$id_pekerjaan', dokter='$dokter', tujuan='$tujuan', pembiayaan='$pembiayaan'";
							mysqli_query($koneksi, $query);  

}
?>

<table border="0" cellpadding="4" cellspacing="3" align="center" width="100%">
<tr>
<td colspan="3" align="center">
<b><?php echo $no_rekamedis; ?></b>
<hr>
</td>
</tr>
<tr>
<td>Nama Pasien</td>
<td>:<?php echo $nama_pasien; ?></td>
</tr>
<tr>
<td>Golongan Darah</td>
<td>:<?php echo $golongan_darah; ?></td>
</tr>
<tr>
<tr>
<td>Jenis Kelamin</td>
<td>:<?php echo $jenis_kelamin; ?></td>
</tr>
<tr>
<td>GR Barcode </td><td><?php echo bar128(stripslashes($_POST['no_rekamedis'])); ?></td>
</tr>
</table>
<?php

echo '</div>';
?>

<center><button><a href="/rsudprovsulut/aksesadmin/manage1/adminrmedis.php">Selesai</a></button></center>
<center><button><a href="/rsudprovsulut/aksesadmin/manage1/halaman4/printbarcode.php">Print</a></button></center>					


