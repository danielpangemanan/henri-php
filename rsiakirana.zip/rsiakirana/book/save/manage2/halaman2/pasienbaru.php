<?php 
include "koneksibarcode.php";
?>

<div class="main-grid">
			<div class="agile-grids">	
				
			<h3 style="text-align: center;">PENDAFTARAN PASIEN BARU</h3>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
				 <th>Proses</th>
				 <th>Nomor Pendaftaran</th>
				 <th>Nama Pasien</th>
				 <th>Alamat</th>
				 <th>Tempat/Tgl Lahir</th>
				 <th>Jenis Kelamin</th>
				 <th>Jam Daftar</th>
				</tr>
					
				<?php
				
				$sql = $koneksi->query("select *from pasien order by id desc");
				while ($data=$sql->fetch_assoc())
				{
				?>											
					
				<tr>
				 <td><a href="/rsudprovsulut/aksesadmin/manage1/adminrmedis.php?page=psbaru&id=<?php echo $data['id'];?>" class="label label-info">Proses</a></td>
				 <td bgcolor="#ffffff">PSID0000<?php echo $data['id'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['nama_pasien'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['alamat'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['ttl'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jenis_kelamin'];?></td>
				 <td bgcolor="#ffffff"><?php echo $data['jam_datang'];?></td>
				</tr>
				<?php
				
				}
				?>
				</table>
			</div>