

	

<!-- Button trigger obat-modal -->
	<div class="modal fade" id="staticBackdrop1" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel1" aria-hidden="true">
		<form method="POST">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="staticBackdropLabel1">Input Penjualan Obat</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body">
		        <label for="nama_obt">Nama Obat</label>
			      <select class="form-control1" name="nama_obt" required>
			        <option value=''>..:::..</option>
			         <?php
			          
			          $sql="SELECT * FROM dataobat";
			          $hasil=mysqli_query($koneksi,$sql);
			          while ($dataobat = mysqli_fetch_array($hasil)) {
			          
			         ?>
			          <option value="<?php echo $dataobat['nama_obt'];?>"><?php echo $dataobat['nama_obt'];?> &nbsp| &nbsp&nbspRp.<?php echo $dataobat['harga_obt'];?></option>
			        <?php 
			        }
			        ?>
			    </select>
			    <br>

			    <label for="jumlah">Jumlah(Qty)</label><br>
                <input type="text" class="form-control1" name="jumlah" placeholder="...."required>

                <label for="harga_obt">Harga Per/Item</label>
			      <select class="form-control1" name="harga_obt" required>
			        <option value=''>..:::..</option>
			         <?php
			         
			          $sql="SELECT * FROM dataobat";
			          $hasil=mysqli_query($koneksi,$sql);
			          while ($dataobat = mysqli_fetch_array($hasil)) {
			          
			         ?>
			          <option value="<?php echo $dataobat['harga_obt'];?>">Rp.<?php echo $dataobat['harga_obt'];?> &nbsp|&nbsp <?php echo $dataobat['nama_obt'];?></option>
			        <?php 
			        }
			        ?>
			    </select>
			    <br>

				<input type="hidden" class="form-control1" name="tgl_keluar" value="<?php echo date('d-F-Y')?>">                

		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
		        <button type="submit" name="input1" class="btn btn-primary">Kirim</button>
		      </div>
		    </div>
		  </div>
		</form>
	</div>
	<!-- proses input pengeluaran obat -->
	<?php
	

		if(isset($_POST['input1'])) {
			$nama_obt=$_POST['nama_obt'];
			$jumlah=$_POST['jumlah'];
			$harga_obt=$_POST['harga_obt'];
			$tgl_keluar=$_POST['tgl_keluar'];

			$selStok =mysqli_query($koneksi, "SELECT * FROM dataobat WHERE nama_obt='$nama_obt'");
		    $stokAwal    =mysqli_fetch_array($selStok);
		    $stok    =$stokAwal['stok'];
		    //hitung sisa stok
		    $sisa    =$stok-$jumlah;
		    $harga   =$jumlah*$harga_obt;
		    $username = $_SESSION['username'];

				//cek sisa stok
				if ($stok < $jumlah) {
				?>
				<script language="JavaScript">
				alert('Jumlah pengeluaran lebih besar dari sisa Stok Barang');
				document.location='admapt?page=obtout';
				</script>
				<?php
				}
				//proses    
				else{

				    $updateStok= mysqli_query($koneksi, "UPDATE dataobat SET stok='$sisa' WHERE nama_obt='$nama_obt'");

					$query="INSERT INTO obat_apotik SET nama_obt='$nama_obt', jumlah='$jumlah', harga='$harga', tgl_keluar='$tgl_keluar' "; 

					$laporan= mysqli_query($koneksi, "INSERT INTO tabel_pesan SET waktu='$tgl_keluar', dari='$username', kepada='spv', pesan='Konfirmasi Keuangan', sudahbaca='NO', jumlah='$harga', keterangan='Penjualan Obat $nama_obt' "); 

					mysqli_query($koneksi, $query); 
					
					echo "<script>alert('Data Penjualan Obat Berhasil ');</script>";
		}
	}
	?>
	<!-- proses input pengeluaran obat -->






<div class="main-grid">
	<div class="agile-grids">	
		<h3 style="text-align: center;">DATA PENJUALAN OBAT</h3>
		<hr>
		<!-- Button trigger modal -->
		<div>
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop1">Proses Obat Keluar</button>

		</div>
		<hr>
		<!-- Button trigger modal -->
		<div class="table-responsive">
			<table class="table table-bordered">
		
			<tr style="background-color: white;">
			 
			 <th width="350px">Nama Obat</th>
			 <th width="150px">Jumlah Terjual</th>
			 <th width="250px" style="background-color: lightblue;">Total Harga</th>
			 <th width="250px">Tanggal Terjual</th>
			</tr>
				
			<?php
				
				$sql = $koneksi->query("SELECT * FROM obat_apotik ");
				while ($data=$sql->fetch_array())
			{
			?>											
				
			<tr>
			 <td bgcolor="#ffffff"><?php echo $data['nama_obt'];?></td>
			 <td bgcolor="#ffffff"><?php echo $data['jumlah'];?></td>
			 <td bgcolor="#ffffff"><?php echo $data['harga'];?></td>
			 <td bgcolor="#ffffff"><?php echo $data['tgl_keluar'];?></td>
			</tr>
			<?php
			
			}
			?>
			</table>
		</div>
	</div>
</div>
			



<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
	.th1{
		position: relative;
		top: -40px;
	}
</style>



				

