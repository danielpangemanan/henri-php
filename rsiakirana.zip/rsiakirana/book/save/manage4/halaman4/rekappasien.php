
<?php
	include "koneksi.php";

	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien where id_registrasi='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>
<br>
<div class="container-fluid" class="col-md-12">
	
	<div class="container-fluid">
	   		<div class="table-responsive">
				
					<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">
						<thead>
						<tr>
							<th><h3 style="text-align: center">RSIA-KIRANA</h3></th>
							<th><h3 style="text-align: center">REKAP PASIEN</h3></th>
						</tr>
			   			<tr>
							<th><center>DATA PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   </thead>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Rekamedis</td>
							<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Induk Kependudukan</td>
							<td><?php echo $data['nik']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Pasien</td>
							<td><?php echo $data['nama_pasien']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Petugas Dokter</td>
							<td><strong><?php echo $data['dokter']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Jenis Kelamin</td>
							<td><?php echo $data['jenis_kelamin']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Golongan Darah</td>
							<td><?php echo $data['golongan_darah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Tempat, Tanggal Lahir</td>
							<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Alamat</td>
							<td><?php echo $data['alamat']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Ibu Kandung</td>
							<td><?php echo $data['nama_ibu']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Agama</td>
							<td><?php echo $data['agama']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Status</td>
							<td><?php echo $data['status_menikah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Telp/Hp</td>
							<td><?php echo $data['no_hp']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pekerjaan</td>
							<td><?php echo $data['id_pekerjaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pembiayaan</td>
							<td><?php echo $data['pembiayaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Ruang Penanganan Pasien</td>
							<td><?php echo $data['tujuan']; ?></td>
							
						</tr>
					   	</tbody>
					   	
					 	</table>
					 <?php } ?>
				</div>
			</div>
				

					
		

		<div class="container-fluid">	
			<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">
							<?php
							include "koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrjalan where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   </table>
					   <?php } ?>
				</div>
			</div>


			<div class="container-fluid">	
				<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">
							<?php
							include "koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrinap where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   </table>
					   <?php } ?>
				</div>
			</div>


			<div class="container-fluid">	
				<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">
							<?php
							include "koneksi.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasienrgd where id_registrasi='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<thead>
						<tr>
							<th><center>DATA TINDAKAN PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   	</thead>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Pasien</td>
							<td><strong><?php echo $data['ruangan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Dokter Lain</td>
							<td><strong><?php echo $data['dokter_lain']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Triage</td>
							<td><strong><?php echo $data['triage']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Tanggal Pemeriksaan</td>
							<td><strong><?php echo $data['tglperiksa']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Keluhan Pasien</td>
							<td><strong><?php echo $data['keluhan']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							<td>Riwayat Penyakit Pasien</td>
							<td><strong><?php echo $data['rpenyakit']; ?>&nbsp(kode penyakit)</strong></td>
						</tr>
					   	</tbody>

					   </table>
					   <?php } ?>
					</div>
				</div>



			<div class="container-fluid">	
				<h4>DATA PENGGUNAAN RUANGAN PASIEN</h4>
				<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">

						<?php

						$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudroom";
						$koneksiroom    = mysqli_connect($host, $user, $password, $database);
						$no = $_GET['kode'];

						$ambildata=mysqli_query($koneksiroom, "SELECT tabel_trnruangpasien.no_rekamedis, tabel_trnruangpasien.id_data, tabel_trnruangpasien.jumlah, data_ruangan.harga, data_ruangan.keterangan FROM tabel_trnruangpasien JOIN data_ruangan ON data_ruangan.id_data = tabel_trnruangpasien.id_data where id_registrasi='$no'");
						
						while($databiayaruangan = mysqli_fetch_array($ambildata)){

							$jumlah=$databiayaruangan['jumlah'];
							$harga=$databiayaruangan['harga'];
							$totalruangan=$jumlah*$harga;

					?>


					<tbody>
						<tr class="odd gradeX">
							<td>Nama Ruangan</td>
							<td><?php echo $databiayaruangan['keterangan'];?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Jumlah Hari Penggunaan Ruangan</td>
							<td><?php echo $databiayaruangan['jumlah'];?></td>
						</tr>
					</tbody>
														
					<tbody>
						<tr class="odd gradeX">
							<td>Biaya Penggunaan Ruangan</td>
							<td><?php echo "Rp." .number_format($databiayaruangan['harga']).",-";?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Total Biaya Ruangan</td>
							<td style="background-color: yellow"><?php echo "Rp." .number_format($totalruangan).",-";?></td>
						</tr>
					</tbody>
					<?php } ?>
					</table>
				</div>
			</div>

			<div class="container-fluid">	
				<h4>DATA BIAYA OBAT PASIEN</h4>
				<div class="table-responsive">
					<table class="table  table-bordered" class="table-condensed" id="" style="background-color: white;">

						<?php

						$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudobat";
						$koneksiobat    = mysqli_connect($host, $user, $password, $database);
						$no1 = $_GET['kode'];

						$ambildata1=mysqli_query($koneksiobat, "SELECT tabel_trnobatpasien.no_rekamedis, tabel_trnobatpasien.id_obat, tabel_trnobatpasien.jumlah, dataobat.harga_obt, dataobat.nama_obt FROM tabel_trnobatpasien JOIN dataobat ON dataobat.id_obat = tabel_trnobatpasien.id_obat where id_registrasi='$no1'");
						
						while($databiayaobat = mysqli_fetch_array($ambildata1)){

							$jumlah=$databiayaobat['jumlah'];
							$harga_obt=$databiayaobat['harga_obt'];
							$totalobat=$jumlah*$harga_obt;

						?>

					
					<tbody>
						<tr class="odd gradeX">
							<td>Nama Obat</td>
							<td><?php echo $databiayaobat['nama_obt'];?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Jumlah Obat</td>
							<td><?php echo $databiayaobat['jumlah'];?></td>
						</tr>
					</tbody>
														
					<tbody>
						<tr class="odd gradeX">
							<td>Biaya Obat</td>
							<td><?php echo "Rp." .number_format($databiayaobat['harga_obt']).",-";?></td>
						</tr>
					</tbody>

					<tbody>
						<tr class="odd gradeX">
							<td>Total Biaya Obat</td>
							<td style="background-color: yellow"><?php echo "Rp." .number_format($totalobat).",-";?></td>
						</tr>
					</tbody>
					<?php } ?>
					</table>
				</div>
			</div>


	</div>
	<br>		


