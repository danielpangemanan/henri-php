<?php

$host       =   "localhost";
$user       =   "root";
$password   =   "";
$database   =   "medkesne_rsudkeu";
// perintah php untuk akses ke database
$koneksi = mysqli_connect($host, $user, $password, $database);		   			
$jumlahDataPerHalaman = 3;
$jumlahData = count(query("SELECT * FROM jurnal_masuk"));
$jumlahHalaman = ceil($jumlahData / $jumlahDataPerHalaman);
$halamanAktif = (isset ($_GET["halaman"])) ? $_GET["halaman"] : 1;
$awalData = ($jumlahDataPerHalaman * $halamanAktif) - $jumlahDataPerHalaman;

$jurnal_masuk = query("SELECT * FROM jurnal_masuk LIMIT $awalData, $jumlahDataPerHalaman");
																	
?>

<br>
<br>
								
					  				<center><h2>KAS MASUK</h2></center>
									<div id="main">
													
										
										<?php for ($i=1; $i <= $jumlahHalaman; $i++) : ?>
											<?php if( $i == $halamanAktif) : ?>
											<a href="?halaman=<?= $i; ?>" style="font-weight: bold"><?= $i; ?></a>
											<?php else : ?>
												<a href="?halaman=<?= $i; ?>"><?= $i; ?></a>
											<?php endif; ?>
										<?php endfor; ?>


										
	
									</div>
											
							

