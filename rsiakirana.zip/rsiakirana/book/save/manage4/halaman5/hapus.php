<?php

include_once("./koneksi.php");

$id = $_GET['id'];

$result = mysqli_query($koneksi, "DELETE FROM member WHERE mem_id=$id");

header("Location:index.php");


?>