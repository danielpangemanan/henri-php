
<?php
	include "koneksibarcode.php";

	
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien where no_rekamedis='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<div class="container-fluid" class="col-md-12">
	
<div class="container-fluid">
   		<div class="table-responsive">
			<form method="POST">
				<table class="table  table-bordered" class="table-condensed" id="">
					<thead>
					<tr>
						<th><center><img src="images/logo.png"></center></th>
						<th><h3 class="th1" style="text-align: center">REKAM MEDIS PASIEN</h3></th>
						<th><h3 class="th1" style="text-align: center">RSUD PROV-SULUT</h3></th>
					</tr>
		   			<tr>
						<th><center>DATA PASIEN</center></th>
						<th><center>KETERANGAN</center></th>
						<th><center>TINDAKAN</center></th>
					</tr>
				   </thead>

				   <tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">
						<td>Nomor Rekamedis</td>
						<td style="text-align: center"><strong><?php echo $data['no_rekamedis']; ?></strong></td>
						<td><strong>Dokter:&nbsp<?php echo $data['dokter']; ?></strong></td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">
						<td>Nomor Induk Kependudukan</td>
						<td><?php echo $data['nik']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="ruangan">
						        <option value=''>Ruangan Rawat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $ruangan1 = mysqli_connect("localhost",'root',"","medkesne_rsudroom");
						         if (!$ruangan1){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from ruangan";

						          $hasil=mysqli_query($ruangan1,$sql);
						          
						          while ($ruang1 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $ruang1['nama'];?>"><?php echo $ruang1['nama'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nama_pasien" value="<?php echo $data['nama_pasien'];?>">
						<td>Nama Pasien</td>
						<td><?php echo $data['nama_pasien']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="dokter_lain">
						        <option value=''>Dokter lain</option>
						          <?php
						         //Membuat koneksi ke database
						         $kondokter = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
						         if (!$kondokter){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%'";

						          $hasil=mysqli_query($kondokter,$sql);
						          
						          while ($dokter1 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?>"><?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="jenis_kelamin" value="<?php echo $data['jenis_kelamin'];?>">
						<td>Jenis Kelamin</td>
						<td><?php echo $data['jenis_kelamin']; ?></td>
						<td>
						      <select style="border: none;" class="form-control" name="obat1">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat1 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat1){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat1,$sql);
						          
						          while ($obat1 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat1['nama_obt'];?>"><?php echo $obat1['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="golongan_darah" value="<?php echo $data['golongan_darah'];?>">
						<td>Golongan Darah</td>
						<td><?php echo $data['golongan_darah']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat2">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat2 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat2){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat2,$sql);
						          
						          while ($obat2 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat2['nama_obt'];?>"><?php echo $obat2['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="tempat_lahir" value="<?php echo $data['tempat_lahir'];?>">
						<input type="hidden" class="form-control" name="tanggal_lahir" value="<?php echo $data['tanggal_lahir'];?>">
						<td>Tempat, Tanggal Lahir</td>
						<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat3">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat3 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat3){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat3,$sql);
						          
						          while ($obat3 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat3['nama_obt'];?>"><?php echo $obat3['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="alamat" value="<?php echo $data['alamat'];?>">
						<td>Alamat</td>
						<td><?php echo $data['alamat']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat4">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat4 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat4){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat4,$sql);
						          
						          while ($obat4 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat4['nama_obt'];?>"><?php echo $obat4['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="nama_ibu" value="<?php echo $data['nama_ibu'];?>">
						<td>Nama Ibu Kandung</td>
						<td><?php echo $data['nama_ibu']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat5">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat5 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat5){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat5,$sql);
						          
						          while ($obat5 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat5['nama_obt'];?>"><?php echo $obat5['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="agama" value="<?php echo $data['agama'];?>">
						<td>Agama</td>
						<td><?php echo $data['agama']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat6">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat6 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat6){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat6,$sql);
						          
						          while ($obat6 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat6['nama_obt'];?>"><?php echo $obat6['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="status_menikah" value="<?php echo $data['status_menikah'];?>">
						<td>Status</td>
						<td><?php echo $data['status_menikah']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat7">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat7 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat7){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat7,$sql);
						          
						          while ($obat7 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat7['nama_obt'];?>"><?php echo $obat7['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="no_hp" value="<?php echo $data['no_hp'];?>">
						<td>Nomor Telp/Hp</td>
						<td><?php echo $data['no_hp']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat8">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat8 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat8){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat8,$sql);
						          
						          while ($obat8 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat8['nama_obt'];?>"><?php echo $obat8['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="id_pekerjaan" value="<?php echo $data['id_pekerjaan'];?>">

						<input type="hidden" class="form-control" name="dokter" value="<?php echo $data['dokter'];?>">
						<td>Pekerjaan</td>
						<td><?php echo $data['id_pekerjaan']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat9">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat9 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat9){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat9,$sql);
						          
						          while ($obat9 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat9['nama_obt'];?>"><?php echo $obat9['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="pembiayaan" value="<?php echo $data['pembiayaan'];?>">
						<td>Pembiayaan</td>
						<td><?php echo $data['pembiayaan']; ?></td>
						<td>
							<select style="border: none;" class="form-control" name="obat10">
						        <option value=''>Obat...</option>
						          <?php
						         //Membuat koneksi ke database
						         $konobat10 = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$konobat10){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($konobat10,$sql);
						          
						          while ($obat10 = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $obat10['nama_obt'];?>"><?php echo $obat10['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						</td>
					</tr>
				   	</tbody>

				   	<tbody>
					<tr class="odd gradeX">
						
						<input type="hidden" class="form-control" name="tujuan" value="<?php echo $data['tujuan'];?>">
						<td>Ruang Penanganan Pasien</td>
						<td><?php echo $data['tujuan']; ?></td>
						<td><input style="border: none" type="text" name="tindakan_lain" placeholder="Tindakan Lain..."></td>
					</tr>
				   	</tbody>
				   	
				 	</table>
				 	<div>
						<button type="submit" name="input" class="btn btn-primary" >Proses</button>
						<a class="btn btn-primary" href="/rsudprovsulut/aksesadmin/manage1/halaman2/printbarcode.php?page=printbarcode&kode=<?php echo $data['no_rekamedis'];?>" role="button">Print</a>
					</div>
				 </form>
				
		</div>
	</div>
</div>
<hr>
<?php } ?>



 <?php

 	include "koneksibarcode.php";

	  if(isset($_POST['input'])) {
	  	$no_rekamedis=$_POST['no_rekamedis'];
		$nik= $_POST['nik'];
		$nama_pasien=$_POST['nama_pasien'];
		$jenis_kelamin=$_POST['jenis_kelamin'];
		$golongan_darah=$_POST['golongan_darah'];
		$tempat_lahir=$_POST['tempat_lahir'];
		$tanggal_lahir=$_POST['tanggal_lahir'];
		$nama_ibu=$_POST['nama_ibu'];
		$alamat=$_POST['alamat'];
		$agama=$_POST['agama'];
		$status_menikah=$_POST['status_menikah'];
		$no_hp=$_POST['no_hp'];
		$id_pekerjaan=$_POST['id_pekerjaan'];
		$dokter=$_POST['dokter'];
		$tujuan=$_POST['tujuan'];
		$pembiayaan=$_POST['pembiayaan'];
		$ruangan=$_POST['ruangan'];
		$dokter_lain=$_POST['dokter_lain'];
		$obat1=$_POST['obat1'];
		$obat2=$_POST['obat2'];
		$obat3=$_POST['obat3'];
		$obat4=$_POST['obat4'];
		$obat5=$_POST['obat5'];
		$obat6=$_POST['obat6'];
		$obat7=$_POST['obat7'];
		$obat8=$_POST['obat8'];
		$obat9=$_POST['obat9'];
		$obat10=$_POST['obat10'];
		$tindakan_lain=$_POST['tindakan_lain'];

		// Insert user data into table
		$input = mysqli_query($koneksi, "INSERT INTO tbl_pasien1 (no_rekamedis,nik,nama_pasien,jenis_kelamin,golongan_darah,tempat_lahir,tanggal_lahir,nama_ibu,alamat,agama,status_menikah,no_hp,id_pekerjaan,dokter,tujuan,pembiayaan,ruangan,dokter_lain,obat1,obat2,obat3,obat4,obat5,obat6,obat7,obat8,obat9,obat10,tindakan_lain) VALUES('$no_rekamedis','$nik','$nama_pasien','$jenis_kelamin','$golongan_darah','$tempat_lahir','$tanggal_lahir','$nama_ibu','$alamat','$agama','$status_menikah','$no_hp','$id_pekerjaan','$dokter','$tujuan','$pembiayaan','$ruangan','$dokter_lain','$obat1','$obat2','$obat3','$obat4','$obat5','$obat6','$obat7','$obat8','$obat9','$obat10','$tindakan_lain')"); 
		  		
		echo "<script>alert('data pasien $nama_pasien akan diproses');window.location=''</script>";
		
	  }
	?>
	


<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
	.th1{
		position: relative;
		top: -40px;
	}



				


