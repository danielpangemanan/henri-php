

<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
		 	<br>
	  					<!-- SECTION INPUT -->
						
	  					<form id="form" role="form" method="post" action="">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>OBAT</h2>
                              </div>

                              	<div class="wow fadeInUp" data-wow-delay="0.8s" >
                                   
                                        <label for="kode_obt">Kode Obat</label><br>
                                        <input type="text" class="form-control" name="kode_obt" placeholder="...." required>
                                  		<br>

                                  		<label for="nama_obt">Nama Obat</label><br>
                                        <input type="text" class="form-control" name="nama_obt" placeholder="...." required>
                                  		<br>

										<label for="jenis_obt">Jenis Obat</label><br>
                                        <input type="text" class="form-control" name="jenis_obt" placeholder="...." required>
                                  		<br> 

                                  		<label for="satuan_obt">Satuan</label><br>
                                        <input type="text" class="form-control" name="satuan_obt" placeholder="...." required>
                                  		<br>   

                                  		<label for="harga_obt">Harga</label><br>
                                        <input type="text" class="form-control" name="harga_obt" placeholder="...." required>
                                  		<br>                              		

									   <div>
											<button type="submit" name="input" class="btn btn-primary" >Input </button>
			
											<button type="reset" name="reset" class="btn btn-primary">Reset </button>
										</div>
								</div>
  							</form>
								
						
	  					
	  <?php

	 	$host       = "localhost";
		$user       = "root";
		$password   = "";
		$database   = "medkesne_rsudobat";
		$koneksi    = mysqli_connect($host, $user, $password, $database);

	  if(isset($_POST['input'])) {
		$kode_obt= $_POST['kode_obt'];
		$nama_obt=$_POST['nama_obt'];
		$jenis_obt=$_POST['jenis_obt'];
		$satuan_obt=$_POST['satuan_obt'];
		$harga_obt=$_POST['harga_obt'];

		// Insert user data into table
		$inputObat = mysqli_query($koneksi, "INSERT INTO dataobat (kode_obt,nama_obt,jenis_obt,satuan_obt,harga_obt) VALUES('$kode_obt','$nama_obt','$jenis_obt','$satuan_obt', '$harga_obt')");  
		  		
		echo "<script>alert('data obat $nama_obt sudah masuk');window.location='adminrmedis.php'</script>";
	  }
	?>
	  					

		</div>
	</div>
  </div>  
<br>