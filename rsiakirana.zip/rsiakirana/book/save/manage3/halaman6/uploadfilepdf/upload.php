
<?php
include "koneksi.php";

 $targetfolder = "file/";
 $targetfolder = $targetfolder . basename( $_FILES['file']['name']) ;
$file_type=$_FILES['file']['type'];
if ($file_type=="application/pdf" || $file_type=="image/gif" || $file_type=="image/jpeg") {
 if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))
 {
 echo "BERHASIL di Upload  file ". basename( $_FILES['file']['name']). " is uploaded";
 //Jalankan perintah insert ke database
 }
 else {
 echo "File Gagal di Upload";
 }
}
else {
 echo "Hanya Boleh upload PDF, JPEG GIF .<br>";
}
?>


<?php
include "koneksi.php";

if(isset($_POST['input'])) {
$judul= $_POST['judul'];
$nama_file= $_POST['nama_file'];
$tanggal=$_POST['tanggal'];

// Insert user data into table
$query="INSERT INTO data_file SET judul='$judul', nama_file='$nama_file', tanggal='$tanggal'";
mysqli_query($koneksi, $query);
}
?>

<script>
setTimeout(function() {
  window.location.href = "/rsiakirana/aksesadmin/manage1/adminrs.php?page=arsip";
}, 1000);
</script>


