<?php
include "conuser.php";
?>

<br>
	  <div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
						
	  					<form id="form" role="form" method="post" action="#">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>KELOLA AKUN REKAM MEDIS(ADMIN)</h2>
                              </div>

															
						
											
                              <div class="wow fadeInUp" data-wow-delay="0.8s" >
                                   
                                        <label for="nama">Nama User</label><br>
                                        <input type="text" class="form-control" name="nama" placeholder="...." required>
                                  		<br>
										                               
                                        <label for="username">Username</label><br>
                                        <input type="text" class="form-control" name="username" placeholder="...."required>
                                  		<br>

                                   
                                        <label for="password">Password Pengguna</label><br>
                                        <input type="text" class="form-control" name="password" placeholder="...."required>
                                   		<br>

                                   		<label for="level">Jenis Akun</label>
										<select name="level" class="form-control" required>
											<option value="">.....</option>
											<option value="dokter">Dokter</option>
											<option value="perawat">Perawat</option>
										</select>
                                        <br>

                                        <!-- <label for="is_aktif">Status Akun</label>
										<select name="is_aktif" class="form-control" required>
											<option value="">.....</option>
											<option value="y">Aktif</option>
											<option value="n">Non Aktif</option>
										</select>
                                        <br> -->
                                            
									   <div>
											<button type="submit" name="tambah"
													class="btn btn-primary" >Input </button>
										</div>
								  		
								  </form>
						</div>
	  					
	  					<?php
			 				
			 				
						  
						  if(isset($_POST['tambah'])) {
							$nama = htmlspecialchars($_POST['nama']);
							$username= htmlspecialchars($_POST['username']);
							$password= htmlspecialchars($_POST['password']);
							$level = htmlspecialchars($_POST['level']);
							// $is_aktif= htmlspecialchars($_POST['is_aktif']);

							$cekdulu= "select * from login where nama='$_POST[nama]'"; 
							$prosescek= mysqli_query($koneksi, $cekdulu);
							if (mysqli_num_rows($prosescek)>0) { //proses mengingatkan data sudah ada
								echo "<script>alert('maaf $nama sudah terdaftar'); </script>";
							} else {
							// Insert user data into table
							$result = mysqli_query($koneksi, "INSERT INTO login (nama,username,password,level) VALUES('$nama','$username','$password','$level')"); 
							}
							
							echo "<script>alert('User Baru Sudah Aktif');window.location='/rsudprovsulut/aksesadmin/manage1/adminrs.php?page=admin' </script>"; 
						  }
						?>

		</div>
	</div>
  </div>  
<br>
    