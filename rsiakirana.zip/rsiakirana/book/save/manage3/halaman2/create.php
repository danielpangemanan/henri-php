<!--
Author : Aguzrybudy
Created : Selasa, 08-Novermber-2016
Title : Crud Php Mysqli Dilengkapi dengan upload gambar dan ckeditor
-->
<!-- <?php
$nis = $_POST['nis'];
$kompetensi = $_POST['kompetensi'];
$nama = $_POST['nama'];
$pendidikan = $_POST['pendidikan'];
$alamat = $_POST['alamat'];
$gambar = $_FILES['gambar']['name'];
$mysqli->query("INSERT INTO stafsdm(nis,kompetensi,nama,pendidikan,alamat,gambar) VALUES('$nis','$kompetensi','$nama','$pendidikan','$alamat','$gambar')");
move_uploaded_file($_FILES['gambar']['tmp_name'],'images/'.$gambar);
echo "<script>alert('input data berhasil.. ...')";
?> -->

<?php
include "koneksi.php";
if(isset($_POST['tambah'])) {
$nis = $_POST['nis'];
$kompetensi = $_POST['kompetensi'];
$nama = $_POST['nama'];
$pendidikan = $_POST['pendidikan'];
$masa_kerja = $_POST['masa_kerja'];
$diklat = $_POST['diklat'];
$status = $_POST['status'];
$wnegara = $_POST['wnegara'];
$alamat = $_POST['alamat'];
$gambar = $_FILES['gambar']['name'];
$mysqli->query("INSERT INTO stafsdm(nis,kompetensi,nama,pendidikan,masa_kerja,diklat,status,wnegara,alamat,gambar) VALUES('$nis','$kompetensi','$nama','$pendidikan','$masa_kerja','$diklat','$status','$wnegara','$alamat','$gambar')");
move_uploaded_file($_FILES['gambar']['tmp_name'],'halaman4/images/'.$gambar);
	
echo "<script>alert('Terima kasih Admin! : $nis');window.location='/aksesadmin/halaman9/adminrs?page=sdm'</script>";
}
?>