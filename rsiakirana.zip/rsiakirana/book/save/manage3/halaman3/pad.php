<?php
include "conkeu.php";
?>

<br>
<br>

					

	
								<section class="">
									

									<center><img src="/aksesadmin/manage1/halaman3/images/logokemenkes.jpg"></center>
					  				<center><h4>P A D</h4></center>
									<center><h4>RSUD PROVINSI SULUT</h4></center>
									
									<hr>
									<div id="main">  			
														<div class="container-fluid">
														   <div class="table-responsive">
															   
																		<table class="table  table-bordered" class="table-condensed" id="">
															   			<tr>
																			
																			<th><center>URAIAN</center></th>
																			<th><center>TARGET</center></th>
																			<th><center>REALISASI</center></th>
																			<th><center>(%)</center></th>
																		</tr>
																		<tr>
																			<th><i><center>1</center></i></th>
																			<th><i><center>2</center></i></th>
																			<th><i><center>3</center></i></th>
																			<th><i><center>4</center></i></th>
																		</tr>
																			
																	   </thead>
																	   <tbody>
																		   
																	<?php 

																		$sql = $koneksi->query("select *from inputpad");
																		while ($data=$sql->fetch_assoc()) {
																			
																		$total1=@$total1+$data['target'];
																		$total2=@$total2+$data['realisasi'];
																			
																		$persentasi=round($total1/$total2 * 100,2);
																	?>
																	

																	<tr class="odd gradeX">
																		
																		<td><center><?php echo $data['uraian']; ?></center></td>
																		<td align="left"><center><?php echo "Rp." . number_format($data['target']).",-"; ?></center></td>
																		<td align="left"><center><?php echo "Rp." . number_format($data['realisasi']).",-"; ?></center></td>
																		<td><?php echo "  $persentasi %"; ?></td>

																	</tr>
																	
																		   
																 	<?php
																		
																	}

																	?>

																   </tbody>
															   		
																 </table>
																		<?php 


																				$sql = $koneksi->query("select *from inputpad ");
																				while ($data=$sql->fetch_assoc()) {

																			?>
																			<?php
																				
																			   $total3=$total2-$total1;
																				}
																			?>
																		
																		<td><center><b>Total Dana PAD yang Belum Terealisasi &nbsp;&nbsp;<?php echo "Rp." .number_format($total3).",-";?>
																		</b></center></td>
																		<hr>
																</div>
															</div>
															
															
															
													</div>
												</div>
										</div>
								</section>
						
</div>



