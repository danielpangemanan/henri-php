<?php
include "conaset.php";
?>

<br>
<div>
	<h2 align="center">ASET BERGERAK</h2>
		<br>
		<div class="container-fluid">
		   <div class="table-responsive">
			 <table class="table table-bordered table-hover">
				 <thead style="background-color: orange">
						<tr>
							<th>Kendraan Ambulance</th>
							<th>No</th>
							<th>Aset</th>
							<th>Jenis</th>
							<th>Mata Anggaran</th>
							<th>Tanggal Masuk</th>
							<th>Datail</th>
						</tr>
					</thead>
					<tbody>


						<?php 
							$id=0;
							$sql = $koneksi->query("select *from medkesne_rsudaset1");
							$sql = $koneksi->query("SELECT * FROM aset1 WHERE keterangan LIKE '%ambulance%' ORDER BY id ASC");
						
						
							while ($data=$sql->fetch_assoc()) {

						?>


							

						<tr>
							<td></td>
							<td><?php echo $id+1; ?></td>
							<td><?php echo $data['kode_aset']; ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td><?php echo $data['anggaran']; ?></td>
							<td><?php echo $data['tanggal_masuk']; ?></td>
							<td><a href="/rsiakirana/aksesadmin/manage1/adminrs.php?page=detail1&kode_aset=<?php echo $data['kode_aset'];?>">Lihat Detail</a></td>
						</tr>

						<?php

							$id++; 
							$data['kode_aset'];
							$data['nama'];
							$data['anggaran'];
							$data['tanggal_masuk'];
						}

						?>
					   </tbody>
					 </table>
				</div>
			</div>

		<br>
		<div class="container-fluid">
		   <div class="table-responsive">
			 <table class="table table-bordered table-hover">
				 <thead style="background-color: orange">
						<tr>
							<th>Kendaraan Operasional</th>
							<th>No</th>
							<th>Aset</th>
							<th>Jenis</th>
							<th>Mata Anggaran</th>
							<th>Tanggal Masuk</th>
							<th>Detail</th>

						</tr>
					</thead>
					<tbody>


						<?php 

							$id=0;
							$sql = $koneksi->query("select *from medkesne_rsudaset1");
							$sql = $koneksi->query("SELECT * FROM aset1 WHERE keterangan LIKE '%operasional%' ORDER BY id ASC");
							while ($data=$sql->fetch_assoc()) {



						?>

						<tr class="odd gradeX">
							<td></td>
							<td><?php echo $id+1; ?></td>
							<td><?php echo $data['kode_aset']; ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td><?php echo $data['anggaran']; ?></td>
							<td><?php echo $data['tanggal_masuk']; ?></td>
							<td><a href="/rsiakirana/aksesadmin/manage1/adminrs.php?page=detail1&kode_aset=<?php echo $data['kode_aset'];?>">Lihat Detail</a></td>

						</tr>

						<?php

							$id++; 
							$data['kode_aset'];
							$data['nama'];
							$data['anggaran'];
							$data['tanggal_masuk'];
						}

						?>
					   </tbody>
					 </table>
			</div>
		</div>


		<br>
		<div class="container-fluid">
		   <div class="table-responsive">
			 <table class="table table-bordered table-hover">
				 <thead style="background-color: orange">
						<tr>
							<th>Mobil Jenazah</th>
							<th>No</th>
							<th>Aset</th>
							<th>Jenis</th>
							<th>Mata Anggaran</th>
							<th>Tanggal Masuk</th>
							<th>Detail</th>
						</tr>
					</thead>
					<tbody>


						<?php 

							$id=0;
							$sql = $koneksi->query("select *from medkesne_rsudaset1");
							$sql = $koneksi->query("SELECT * FROM aset1 WHERE keterangan LIKE '%mobil jenazah%' ORDER BY id ASC");
							while ($data=$sql->fetch_assoc()) {



						?>

						<tr class="odd gradeX">
							<td></td>
							<td><?php echo $id+1; ?></td>
							<td><?php echo $data['kode_aset']; ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td><?php echo $data['anggaran']; ?></td>
							<td><?php echo $data['tanggal_masuk']; ?></td>
							<td><a href="/rsiakirana/aksesadmin/manage1/adminrs.php?page=detail1&kode_aset=<?php echo $data['kode_aset'];?>">Lihat Detail</a></td>

						</tr>

						<?php

							$id++; 
							$data['kode_aset'];
							$data['nama'];
							$data['anggaran'];
							$data['tanggal_masuk'];
						}

						?>
					   </tbody>
					 </table>
			</div>
		</div>
	</div>
<br>








