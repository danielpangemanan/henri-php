
<?php
include "koneksi.php";
?>

	 <div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
						
	  					<form id="form" role="form" method="post" action="">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h2>REKAM MEDIS PASIEN</h2>
                              </div>

                              	<div class="wow fadeInUp" data-wow-delay="0.8s" >
                                   
                                   		
                                   		<label for="no_rekamedis">Nomor Rekam Medis</label><br>
                                   		<?php
									         
									         $kon = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
									         if (!$kon){
									            die("Koneksi database gagal:" .mysqli_connect_error());
									         }
									        
									          $sql="SELECT * FROM tbl_pasien Order by no_rekamedis Desc limit 1  ";

									          $hasil=mysqli_query($kon,$sql);
									          
									          while ($psn = mysqli_fetch_array($hasil)) {  
									        ?>
                                        
                                        <input type="text" class="form-control" name="no_rekamedis" value="<?php echo $psn['no_rekamedis'];?>" required>
                                    	<?php } ?>
                                  		<br>

                                  		<label for="id_registrasi">Nomor Registrasi</label><br>
                                        <input type="text" class="form-control" name="id_registrasi" value="001001">
                                  		<br>

                                  		<label for="nik">NIK (sesuai dengan KTP)</label><br>
                                        <input type="text" class="form-control" name="nik" placeholder="...." required>
                                  		<br>

                                  		<label for="nama_pasien">Nama Pasien</label><br>
                                        <input type="text" class="form-control" name="nama_pasien" value="<?php echo $data['nama_pasien'];?>" required>
                                  		<br>
										
										<label for="jenis_kelamin">Jenis Kelamin</label><br>
                                        <input type="text" class="form-control" name="jenis_kelamin" value="<?php echo $data['jenis_kelamin'];?>" required>
                                  		<br>
                                   
                                        <label for="golongan_darah">Golongan Darah</label><br>
                                        <input type="text" class="form-control" name="golongan_darah" placeholder="...."required>
                                  		<br>

                                  		<label for="tempat_lahir">Tempat Lahir</label><br>
                                        <input type="text" class="form-control" name="tempat_lahir" placeholder="...."required>
                                  		<br>

                                  		<label for="tanggal_lahir">Tanggal Lahir</label><br>
                                        <input type="date" class="form-control" name="tanggal_lahir" placeholder="...."required>
                                  		<br>

                                  		<label for="nama_ibu">Nama Ibu Kandung</label><br>
                                        <input type="text" class="form-control" name="nama_ibu" placeholder="...."required>
                                  		<br>

                                  		<label for="alamat">Alamat</label><br>
                                        <input type="text" class="form-control" name="alamat" value="<?php echo $data['alamat'];?>" required>
                                  		<br>
                                   
                                        <label for="agama">Agama</label>
										<select name="agama" class="form-control" name="agama" required>
											<option value="Kristen Protestan">Kristen Protestan</option>
											<option value="Islam">Islam</option>
											<option value="Katolik">Katolik</option>
											<option value="Hindu">Hindu</option>
											<option value="Buddha">Buddha</option>
											<option value="Kong Hu Cu">Kong Hu Cu</option>
											<option value="Lainnya">Lainnya</option>
										</select>
									    <br>

									    <label for="status_menikah">Status</label><br>
                                        <select name="status_menikah" class="form-control" name="status_menikah" required>
											<option value="Kawin">Kawin</option>
											<option value="Belum Kawin">Belum Kawin</option>
											<option value="Janda">Janda</option>
											<option value="Duda">Duda</option>
											<option value="Lainnya">Lainnya</option>
										</select>
                                  		<br>

                                  		<label for="no_hp">No. Telp/HP</label><br>
                                        <input type="text" class="form-control" name="no_hp" placeholder="...."required>
                                  		<br>

                                  		<label for="id_pekerjaan">Pekejaan</label><br>
                                        <input type="text" class="form-control" name="id_pekerjaan" placeholder="...."required>
                                  		<br>

                                  		<label for="dokter">Dokter</label><br>
                                        <select style="border: none;" class="form-control" name="dokter">
									        <option value=''>..:::..</option>
									          <?php
									         //Membuat koneksi ke database
									         $kondokter = mysqli_connect("localhost",'root',"","medkesne_rsudsdm1");
									         if (!$kondokter){
									            die("Koneksi database gagal:" .mysqli_connect_error());
									         }
									        
									         //Perintah sql untuk menampilkan semua data pada tabel 
									          $sql="SELECT * FROM stafsdm WHERE kompetensi LIKE '%dokter%'";

									          $hasil=mysqli_query($kondokter,$sql);
									          
									          while ($dokter1 = mysqli_fetch_array($hasil)) {
									          
									         ?>
									          <option value="<?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?>"><?php echo $dokter1['nama'];?>&nbsp:<?php echo $dokter1['kompetensi'];?></option>
									        <?php 
									        }
									        ?>
									    </select>
                                  		<br>

                                  		<label for="tujuan">Poli Tujuan/ Umum/ Lainnya</label>
										<select class="form-control" name="tujuan" required>
									        <option value=''>..:::..</option>
									          <?php
									         //Membuat koneksi ke database
									         $kontujuan = mysqli_connect("localhost",'root',"","medkesne_rsudroom");
									         if (!$kontujuan){
									            die("Koneksi database gagal:" .mysqli_connect_error());
									         }
									        
									         //Perintah sql untuk menampilkan semua data pada tabel 
									          $sql="select * from tujuan_pasien";

									          $hasil=mysqli_query($kontujuan,$sql);
									          
									          while ($ptujuan = mysqli_fetch_array($hasil)) {
									          
									         ?>
									          <option value="<?php echo $ptujuan['nama_tujuan'];?>"><?php echo $ptujuan['nama_tujuan'];?></option>
									        <?php 
									        }
									        ?>
									    </select>
									    <br>

                                  		<label for="pembiayaan">Pembiayaan</label>
										<select name="pembiayaan" class="form-control" name="pembiayaan" required>
											<option value="Mandiri">Mandiri</option>
											<option value="BPJS">BPJS</option>
										</select>
									    <br>

									   <div>
											<button type="submit" name="input" class="btn btn-primary" >Input </button>
			
											<button type="reset" name="reset" class="btn btn-primary">Reset </button>
										</div>
								</div>
  							</form>
								
						
	  					
	  <?php

	  if(isset($_POST['input'])) {
	  	$id= $_POST['id'];
		$no_rekamedis= $_POST['no_rekamedis'];
		$id_registrasi= $_POST['id_registrasi'];
		$nik= $_POST['nik'];
		$nama_pasien=$_POST['nama_pasien'];
		$jenis_kelamin=$_POST['jenis_kelamin'];
		$golongan_darah=$_POST['golongan_darah'];
		$tempat_lahir=$_POST['tempat_lahir'];
		$tanggal_lahir=$_POST['tanggal_lahir'];
		$nama_ibu=$_POST['nama_ibu'];
		$alamat=$_POST['alamat'];
		$agama=$_POST['agama'];
		$status_menikah=$_POST['status_menikah'];
		$no_hp=$_POST['no_hp'];
		$id_pekerjaan=$_POST['id_pekerjaan'];
		$dokter=$_POST['dokter'];
		$tujuan=$_POST['tujuan'];
		$pembiayaan=$_POST['pembiayaan'];
		//$gambar=$_POST['gambar'];

		// Insert user data into table
		$query="INSERT INTO tbl_pasien SET id='$id', no_rekamedis='$no_rekamedis', id_registrasi='$id_registrasi', nik='$nik', nama_pasien='$nama_pasien', jenis_kelamin='$jenis_kelamin', golongan_darah='$golongan_darah', tempat_lahir='$tempat_lahir', tanggal_lahir='$tanggal_lahir', nama_ibu='$nama_ibu', alamat='$alamat', agama='$agama', status_menikah='$status_menikah', no_hp='$no_hp', id_pekerjaan='$id_pekerjaan', dokter='$dokter', tujuan='$tujuan', pembiayaan='$pembiayaan'";
		mysqli_query($koneksi, $query);  
		//move_uploaded_file($_FILES['gambar']['tmp_name'],'images/'.$gambar);
		  		
		echo "<script>alert('data sudah masuk atas nama pasien : $nama_pasien'); self.location = 'adminrmedis.php?page=prosespasien';</script>";
	  }
	?>





	<style type="text/css">
	.container {
  		margin-top: 25px;
  		margin-bottom: 45px;
  	</style>

    
	



