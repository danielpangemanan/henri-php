<?php
include "koneksi.php";
?>

<br>
<br>
<div class="col-md-12">
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidebar {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidebar a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 22px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidebar a:hover {
  color: #f1f1f1;
}

.sidebar .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

.openbtn {
  font-size: 10px;
  cursor: pointer;
  background-color: #F52327;
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color: #444;
}
.closebtn {
  font-size: 10px;
  cursor: pointer;
  background-color: #F52327;
  color: white;
  padding: 10px 15px;
  border: none;
}

.closebtn:hover {
  background-color: #444;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

/* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */
@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}
</style>
</head>
<body>
											
<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
  
<div id="mySidebar" class="sidebar">
	<a href="/aksesadmin/sdmrs.php">Beranda</a>
	<a href="sdmrs.php?page=input">Input SDM</a>
</div>
	
</body>
</html> 												

	
						<section class="">
					  				<center><h2>Sumberdaya Manusia</h2></center>
									<div id="main">
											<div class="nav-tabs-group">
												
												
												<ul class="nav-tabs-list">
													<li class="active"><a onclick="#">SDM BERDASARKAN KUALIFIKASI</a></li>
												</ul>
												<div class="nav-tabs-right">
													<button class="openbtn" onclick="openNav()">☰</button>
												<button href="javascript:void(0)" class="closebtn" onclick="closeNav()">x</button>
												</div>
											</div>
					  
													
														<div class="container-fluid">
														   <div class="table-responsive">
																
																		<table class="table table-striped table-bordered" class="table-condensed" id="">
																		  <thead>
																			<tr>
																			  <th>Pendidikan S1</th>	
																			  <th>NIS</th>
																			  <th>Nama</th>
																			  <th>Pendidikan</th>
																			  <th>Kompetensi</th>
																			  <th>Gambar</th>
																			  <th><a href="">edit</a></th>
																			</tr>
																		  </thead>
																		  <tbody>

																		  
																		  <?php 
																				 
																			$no = 0;
																			$stafsdm=$mysqli->query("SELECT * FROM stafsdm WHERE pendidikan LIKE '%s1%' ORDER BY id ASC");
																			while($m=mysqli_fetch_array($stafsdm)){
																			$no++;    
																		  ?>  

																		<tr>
																		  <td></td>
																		  <td><?php echo $m['nis']; ?></td>
																		  <td><?php echo $m['nama']; ?></td>
																		  <td><?php echo $m['pendidikan']; ?></td>
																		  <td><?php echo $m['kompetensi']; ?></td>
																		  <td><img src="/aksesadmin/halaman4/images/<?php echo $m['gambar'];?>" height="50"></td>
																		  <td>
																		  <!-- <a href="index.php?page=edit&id=<?php echo $m['id'];?>"><i class="fa fa-pencil"></i></a> --> <!-- dimatikan sementara--> 
																			<a href="halaman4/deletesdm.php?page=delete&id=<?php echo $m['id'];?>"><i class=""></i>hapus</a>|
																			<a href="halaman4/detailsdm.php?page=<?php echo $m['nis'];?>"><i class=""></i>lihat</a>
																		  </td>
																		</tr>

																		<?php } ?>

																		  </tbody>
																		</table>
																		
																	</div>	
														</div>
									
													
														<div class="container-fluid">
														   <div class="table-responsive">
																
																		<table class="table table-striped table-bordered" id="">
																		  <thead>
																			<tr>
																			  <th>Masa Kerja</th>	
																			  <th>NIS</th>
																			  <th>Nama</th>
																			  <th>Masa Kerja</th>
																			  <th>Kompetensi</th>
																			  <th>Gambar</th>
																			  <th><a href="">edit</a></th>
																			</tr>
																		  </thead>
																		  <tbody>

																		  <?php 
																			$no = 0;
																			$stafsdm=$mysqli->query("SELECT * FROM stafsdm ORDER BY id ASC");
																			while($m=mysqli_fetch_array($stafsdm)){
																			$no++;    
																		  ?>  

																		<tr>
																		  <td></td>
																		  <td><?php echo $m['nis']; ?></td>
																		  <td><?php echo $m['nama']; ?></td>
																		  <td><?php echo $m['masa_kerja']; ?></td>
																		  <td><?php echo $m['kompetensi']; ?></td>
																		  <td><img src="/aksesadmin/halaman4/images/<?php echo $m['gambar'];?>" height="50"></td>
																		  <td>
																		  <!-- <a href="index.php?page=edit&id=<?php echo $m['id'];?>"><i class="fa fa-pencil"></i></a> --> <!-- dimatikan sementara--> 
																			<a href="halaman4/deletesdm.php?page=delete&id=<?php echo $m['id'];?>"><i class=""></i>hapus</a>|
																			<a href="halaman4/detailsdm.php?page=<?php echo $m['nis'];?>"><i class=""></i>lihat</a>
																		  </td>
																		</tr>

																		<?php } ?>

																		  </tbody>
																		</table>
																		
																	</div>	
														</div>
													
														<div class="container-fluid">
														   <div class="table-responsive">
																
																		<table class="table table-striped table-bordered" id="">
																		  <thead>
																			<tr>
																			  <th>Diklat</th>	
																			  <th>NIS</th>
																			  <th>Nama</th>
																			  <th>Pendidikan</th>
																			  <th>Diklat</th>
																			  <th>Gambar</th>
																			  <th><a href="">edit</a></th>
																			</tr>
																		  </thead>
																		  <tbody>

																		  <?php 
																			$no = 0;
																			$stafsdm=$mysqli->query("SELECT * FROM stafsdm ORDER BY id ASC");
																			while($m=mysqli_fetch_array($stafsdm)){
																			$no++;    
																		  ?>  

																		<tr>
																		  <td></td>
																		  <td><?php echo $m['nis']; ?></td>
																		  <td><?php echo $m['nama']; ?></td>
																		  <td><?php echo $m['pendidikan']; ?></td>
																		  <td><?php echo $m['diklat']; ?></td>
																		  <td><img src="/aksesadmin/halaman4/images/<?php echo $m['gambar'];?>" height="50"></td>
																		  <td>
																		  <!-- <a href="index.php?page=edit&id=<?php echo $m['id'];?>"><i class="fa fa-pencil"></i></a> --> <!-- dimatikan sementara--> 
																			<a href="halaman4/deletesdm.php?page=delete&id=<?php echo $m['id'];?>"><i class=""></i>hapus</a>|
																			<a href="halaman4/detailsdm.php?page=<?php echo $m['nis'];?>"><i class=""></i>lihat</a>
																		  </td>
																		</tr>

																		<?php } ?>

																		   </tbody>
																		</table>
																		
																	</div>
														</div>
							</div>	
			</section>
</div>




