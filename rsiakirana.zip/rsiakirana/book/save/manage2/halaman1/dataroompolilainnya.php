
<?php 
$db = new Mysqli("localhost", "root", "", "medkesne_rsudroom");
?>

<br>
<div class="container">
	<form method="post" enctype="multipart/form-data">
      <div class="form-group row mt-2" class="form-group row mb-2">
        <div class="col-md-2">
          <label for="cari">Data Ruangan</label>
          <input type="text" name="keyword" class="form-control" id="">
          <button type="submit" class="btn btn-sm btn-danger" name="cari">cari</button>
          <button type="submit" class="btn btn-sm btn-danger" name="cari">reset</button>
      </div>
    </form>
</div>
<br>


<div class="container">
	<div class="main-grid">
		<h3 style="text-align: center;">DATA POLIKLINIK</h3>
		<br>
		<div class="agile-grids">	
			<div class="table-responsive">
				<table class="table table-bordered">
			
				<tr style="background-color: orange">
					 <th>Poli Tujuan/ Umum/ Lainnya</th>
					 <th>Lokasi Gedung</th>
				</tr>
			
				<?php 
					
                    if(isset($_POST["cari"])){
                        $search = $_POST['keyword'];

                        $query = $db->query("SELECT * FROM tujuan_pasien WHERE nama_tujuan LIKE '%$search%' ");
                    }else {
                        $query = $db->query("SELECT * FROM tujuan_pasien ");
                    }
				
                   while($data = mysqli_fetch_assoc($query))
					{
					?>	
								
					
				<tr>
					 <td bgcolor="#ffffff"><?php echo $data['nama_tujuan'];?></td>
					 <td bgcolor="#ffffff">-</td>
				</tr>
				<?php } ?>
			
				</table>
			</div>
		</div>
	</div>
</div>