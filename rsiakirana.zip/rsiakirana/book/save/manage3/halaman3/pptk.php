<?php
include "conkeu.php";
?>

<br>
<br>


	
								<section class="">
									

									<center><img src="/aksesadmin/manage1/halaman3/images/logokemenkes.jpg"></center>
					  				<center><h4>PEJABAT PELAKSANA TEKNIS KEGIATAN</h4></center>
									<center><h4></h4></center>
									
									<hr>
									<div id="main">
										
														<div class="container-fluid">
														   <div class="table-responsive">
															   
																		<table class="table  table-bordered" class="table-condensed" id="">
															   			<tr>
																			
																			<th><center>PPTK</center></th>
																			<th><center>URAIAN</center></th>
																			<th><center>NAMA</center></th>
																			<th><center>KETERANGAN</center></th>
																		</tr>
																		
																	   </thead>
																	   <tbody>
																		   
																		   
																		<?php

																		$connect = mysqli_connect("localhost", "root", "", "medkesne_rsudkeu"); 
																		// mencari kode barang dengan nilai paling besar
																		$query = "SELECT max(id) as maxKode FROM pptk";
																		$hasil = mysqli_query($connect,$query);
																		$data = mysqli_fetch_array($hasil);
																		$id = $data['maxKode'];

																		// mengambil angka atau bilangan dalam kode anggota terbesar,
																		// dengan cara mengambil substring mulai dari karakter ke-1 diambil 6 karakter
																		// misal 'BRG001', akan diambil '001'
																		// setelah substring bilangan diambil lantas dicasting menjadi integer
																		$noUrut = (int) substr($id, 3, 3);

																		// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
																		$noUrut++;

																		// membentuk kode anggota baru
																		// perintah sprintf("%03s", $noUrut); digunakan untuk memformat string sebanyak 3 karakter
																		// misal sprintf("%03s", 12); maka akan dihasilkan '012'
																		// atau misal sprintf("%03s", 1); maka akan dihasilkan string '001'
																		$char = "PPTK001";
																		$id = $char . sprintf("%03s", $noUrut);
																		
																		?>
																		   
																		   
																		   
																		   
																		   
																	<?php 

																		$sql = $koneksi->query("select *from pptk");
																		while ($data=$sql->fetch_assoc()) {

																	?>
																	

																	<tr class="odd gradeX">
																		
																		<td></td>
																		<td><center><?php echo $id++ ?></center></td>
																		<td><center><?php echo $data['nama']; ?></center></td>
																		<td><center><?php echo $data['keterangan']; ?></center></td>

																	</tr>
																	
																		   
																 	<?php

																	}

																	?>

																   </tbody>
															   		
																 </table>
																		
																</div>
															</div>
															
															
															
													</div>
												</div>
										</div>
								</section>
						
</div>
<br>
<br>


