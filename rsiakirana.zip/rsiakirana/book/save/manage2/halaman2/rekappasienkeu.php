

<?php
	include "koneksibarcode.php";

	include('bar128.php');
	if(isset($_GET['kode'])){
	$no = $_GET['kode'];
	$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where no_rekamedis='$no'");
	}else{
	echo "cari berdasarkan nomor rekam medis";
	}
	while($data = mysqli_fetch_array($sql)){

?>

<div class="container-fluid" class="col-md-12">
	<div class="container-fluid">
	   		<div class="table-responsive">
				<form>
					<table class="table  table-bordered" class="table-condensed" id="">
						<thead>
						<tr>
							<th><center><img src="images/logo.png"></center></th>
							<th><h3 class="th1" style="text-align: center">REKAP PASIEN</h3></th>
						</tr>
			   			<tr>
							<th><center>DATA PASIEN</center></th>
							<th><center>KETERANGAN</center></th>
						</tr>
					   </thead>

					   <tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Rekamedis</td>
							<td><strong><?php echo $data['no_rekamedis']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Induk Kependudukan</td>
							<td><?php echo $data['nik']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Pasien</td>
							<td><?php echo $data['nama_pasien']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Petugas Dokter</td>
							<td><strong><?php echo $data['dokter']; ?></strong></td>
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Jenis Kelamin</td>
							<td><?php echo $data['jenis_kelamin']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Golongan Darah</td>
							<td><?php echo $data['golongan_darah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Tempat, Tanggal Lahir</td>
							<td><?php echo $data['tempat_lahir']; ?>,&nbsp<?php echo $data['tanggal_lahir']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Alamat</td>
							<td><?php echo $data['alamat']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nama Ibu Kandung</td>
							<td><?php echo $data['nama_ibu']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Agama</td>
							<td><?php echo $data['agama']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Status</td>
							<td><?php echo $data['status_menikah']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Nomor Telp/Hp</td>
							<td><?php echo $data['no_hp']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pekerjaan</td>
							<td><?php echo $data['id_pekerjaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Pembiayaan</td>
							<td><?php echo $data['pembiayaan']; ?></td>
							
						</tr>
					   	</tbody>

					   	<tbody>
						<tr class="odd gradeX">
							
							
							<td>Ruang Penanganan Pasien</td>
							<td><?php echo $data['tujuan']; ?></td>
							
						</tr>
					   	</tbody>
					   	
					 	</table>
					 	

					<table class="table table-bordered">
				
					<tr>
					 <th>DATA TINDAKAN:&nbsp#<?php echo $data['no_rekamedis'];?></th>
					 <th>Tujuan Awal</th>
					 <th>Fasilitas Ruangan Yang Digunakan</th>
					 <th>Tambahan Petugas Dokter</th>
					 <th>Obat</th>
					 <th>Tindakan Yang Diberikan</th>
					</tr>
						
															
						
					<tr>
					 <td></td>
					 <td bgcolor="#ffffff"><?php echo $data['tujuan'];?></td>
					 <td bgcolor="#ffffff"><?php echo $data['ruangan'];?></td>
					 <td bgcolor="#ffffff"><?php echo $data['dokter_lain'];?></td>
					 <td bgcolor="#ffffff"><?php echo $data['obat1'];?><br>
					 						<?php echo $data['obat2'];?><br>
					 						<?php echo $data['obat3'];?><br>
					 						<?php echo $data['obat4'];?><br>
					 						<?php echo $data['obat5'];?><br>
					 						<?php echo $data['obat6'];?><br>
					 						<?php echo $data['obat7'];?><br>
					 						<?php echo $data['obat8'];?><br>
					 						<?php echo $data['obat9'];?><br>
					 						<?php echo $data['obat10'];?><br>
					 </td>
					 <td bgcolor="#ffffff"><?php echo $data['tindakan_lain'];?></td>
					</tr>
					
					</table>
				</div>
			</div>
		<?php } ?>
		</form>

			<!-- Button trigger modal -->
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">Biaya Ruangan</button>

			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop1">Biaya Obat</button>
			</div>
		</div>
	</div>


	<div class="agile-grids">	
			<div class="table-responsive">
					<!-- Modal -->
					<form role="form" method="POST">
						<?php
							include "koneksibarcode.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where no_rekamedis='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">

						<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">

						<input type="hidden" class="form-control" name="pembiayaan" value="<?php echo $data['pembiayaan'];?>">

						<?php } ?>

					<div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="staticBackdropLabel">Input Biaya Ruangan</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <label for="id_data">Ruangan</label>
						      <select class="form-control" name="id_data" required>
						        <option value=''>..:::..</option>
						          <?php
						         //Membuat koneksi ke database
						         $koneksiroom = mysqli_connect("localhost",'root',"","medkesne_rsudroom");
						         if (!$koneksiroom){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from ruangan";

						          $hasil=mysqli_query($koneksiroom,$sql);
						          
						          while ($dataroom = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $dataroom['id_data'];?>"><?php echo $dataroom['nama'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						    <br>

						    <label for="jumlah">Jumlah(Hari)</label><br>
	                        <input type="text" class="form-control" name="jumlah" placeholder="...."required>

					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					        <button type="submit" name="input" class="btn btn-primary">Kirim</button>
					      </div>
					    </div>
					  </div>
					</div>

					<?php
					 	$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudroom";
						$koneksi    = mysqli_connect($host, $user, $password, $database);

						  if(isset($_POST['input'])) {
						  	$no_rekamedis=$_POST['no_rekamedis'];
						  	$nik=$_POST['nik'];
						  	$pembiayaan=$_POST['pembiayaan'];
							$id_data=$_POST['id_data'];
							$jumlah=$_POST['jumlah'];

						// Insert user data into table
						$input = mysqli_query($koneksi, "INSERT INTO tabel_trnruangpasien 
							(no_rekamedis,nik,pembiayaan,id_data,jumlah) 
							VALUES('$no_rekamedis','$nik','$pembiayaan','$id_data','$jumlah')"); 
						  		
						echo "<script>alert('data keuangan ruangan pasien akan diproses');window.location=''</script>";
						
					  }
					?>

					</form>
		</div>
	</div>


	<div class="agile-grids">	
			<div class="table-responsive">
					<!-- Modal -->
					<form role="form1" method="POST">
						<?php
							include "koneksibarcode.php";

							if(isset($_GET['kode'])){
							$no = $_GET['kode'];
							$sql = mysqli_query($koneksi,"select * from tbl_pasien1 where no_rekamedis='$no'");
							}else{
							echo "cari berdasarkan nomor rekam medis";
							}
							while($data = mysqli_fetch_array($sql)){
						?>

						<input type="hidden" class="form-control" name="no_rekamedis" value="<?php echo $data['no_rekamedis'];?>">

						<input type="hidden" class="form-control" name="nik" value="<?php echo $data['nik'];?>">

						<input type="hidden" class="form-control" name="pembiayaan" value="<?php echo $data['pembiayaan'];?>">

						<?php } ?>

					<div class="modal fade" id="staticBackdrop1" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel1" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="staticBackdropLabel1">Input Biaya Obat</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <label for="id_obat">Obat</label>
						      <select class="form-control1" name="id_obat" required>
						        <option value=''>..:::..</option>
						          <?php
						         //Membuat koneksi ke database
						         $koneksiobat = mysqli_connect("localhost",'root',"","medkesne_rsudobat");
						         if (!$koneksiobat){
						            die("Koneksi database gagal:" .mysqli_connect_error());
						         }
						        
						         //Perintah sql untuk menampilkan semua data pada tabel 
						          $sql="select * from dataobat";

						          $hasil=mysqli_query($koneksiobat,$sql);
						          
						          while ($dataobat = mysqli_fetch_array($hasil)) {
						          
						         ?>
						          <option value="<?php echo $dataobat['id_obat'];?>"><?php echo $dataobat['nama_obt'];?></option>
						        <?php 
						        }
						        ?>
						    </select>
						    <br>

						    <label for="jumlah">Jumlah(Qty)</label><br>
	                        <input type="text" class="form-control1" name="jumlah" placeholder="...."required>

					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					        <button type="submit" name="input1" class="btn btn-primary">Kirim</button>
					      </div>
					    </div>
					  </div>
					</div>

					<?php
					 	$host       = "localhost";
						$user       = "root";
						$password   = "";
						$database   = "medkesne_rsudobat";
						$koneksi    = mysqli_connect($host, $user, $password, $database);

						  if(isset($_POST['input1'])) {
						  	$no_rekamedis=$_POST['no_rekamedis'];
						  	$nik=$_POST['nik'];
						  	$pembiayaan=$_POST['pembiayaan'];
							$id_obat=$_POST['id_obat'];
							$jumlah=$_POST['jumlah'];

						// Insert user data into table
						$input = mysqli_query($koneksi, "INSERT INTO tabel_trnobatpasien 
							(no_rekamedis,nik,pembiayaan,id_obat,jumlah) 
							VALUES('$no_rekamedis','$nik','$pembiayaan','$id_obat','$jumlah')"); 
						  		
						echo "<script>alert('data keuangan obat pasien akan diproses');window.location=''</script>";
						
					  }
					?>

					</form>
		</div>
	</div>

<br>
<br>




<div class="container-fluid" class="col-md-12">
	<div class="agile-grids">	
			<div class="table-responsive"> 
				<table class="table table-bordered">
				<?php

					$host       = "localhost";
					$user       = "root";
					$password   = "";
					$database   = "medkesne_rsudroom";
					$koneksiroom    = mysqli_connect($host, $user, $password, $database);
					$no = $_GET['kode'];

					$ambildata=mysqli_query($koneksiroom, "SELECT tabel_trnruangpasien.no_rekamedis, tabel_trnruangpasien.id_data, tabel_trnruangpasien.jumlah, data_ruangan.harga FROM tabel_trnruangpasien JOIN data_ruangan ON data_ruangan.id_data = tabel_trnruangpasien.id_data where no_rekamedis='$no'");
					
					while($databiayaruangan = mysqli_fetch_array($ambildata)){

					?>

					<tr>
					 <th>BIAYA RUANGAN</th>
					 <th>Nomor Rekam Medis</th>
					 <th>Jumlah Hari</th>
					 <th>Harga</th>
					 <th>Total Biaya</th>
					</tr>
														
						
					<tr>
					 <td></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaruangan['no_rekamedis'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaruangan['jumlah'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaruangan['harga'];?></td>
					 <td></td>
					</tr>
				<?php } ?>
				</table>

				<table class="table table-bordered">
				<?php

					$host       = "localhost";
					$user       = "root";
					$password   = "";
					$database   = "medkesne_rsudobat";
					$koneksiobat    = mysqli_connect($host, $user, $password, $database);
					$no1 = $_GET['kode'];

					$ambildata1=mysqli_query($koneksiobat, "SELECT tabel_trnobatpasien.no_rekamedis, tabel_trnobatpasien.id_obat, tabel_trnobatpasien.jumlah, dataobat.harga_obt FROM tabel_trnobatpasien JOIN dataobat ON dataobat.id_obat = tabel_trnobatpasien.id_obat where no_rekamedis='$no1'");
					
					while($databiayaobat = mysqli_fetch_array($ambildata1)){

					?>

					<tr>
					 <th>BIAYA OBAT</th>
					 <th>Nomor Rekam Medis</th>
					 <th>Jumlah(qty)</th>
					 <th>Harga</th>
					 <th>Total Biaya</th>
					</tr>
														
						
					<tr>
					 <td></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaobat['no_rekamedis'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaobat['jumlah'];?></td>
					 <td bgcolor="#ffffff"><?php echo $databiayaobat['harga_obt'];?></td>
					 <td></td>
					</tr>
				<?php } ?>
				</table>
		</div>
	</div>
</div>







<style type="text/css">
	.container-fluid{
		margin-top: 20px;
		margin-bottom: 25px;
	}
	.th1{
		position: relative;
		top: -40px;
	}
</style>



				


