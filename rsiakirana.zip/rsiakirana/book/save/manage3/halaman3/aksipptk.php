<?php
$connect = mysqli_connect("localhost", "root", "", "medkesne_rsudkeu");  
$input = $_POST['addmore'];
foreach ($input as $output) {
    mysqli_query($connect,"INSERT INTO pptk VALUES ('','$output')");
}
header('location:/aksesadmin/manage1/adminrs.php?page=ipptk')
?>