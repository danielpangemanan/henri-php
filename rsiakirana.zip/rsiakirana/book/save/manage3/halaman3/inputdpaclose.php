
<br><br><br>
<div class="container">
		<div class="row">
		 <div class="col-md-8 col-sm-12">
	  					<!-- SECTION INPUT -->
	  					<form id="form" role="form" method="post" action="#">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.4s">
                                   <h4>Input Dana (DPA)</h4>
								   <br>&nbsp; <a href="#"> PERIODE INPUT DPA PERLU DIBUKA!!!</a>
								  <hr>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.8s">
													   <div class="col-md-6 col-sm-6">
															<label for="kode_dpa">Kode DPA</label>
															<input disabled value="" type="text" class="form-control" name="kode_dpa" placeholder="...." required>
													   </div>
													  
													  
													  <div class="col-md-6 col-sm-6">
															<label for="uraian_dpa">Uraian Anggaran</label>
															<input disabled value="" type="text" class="form-control" name="uraian_dpa" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="jumlah_dpa">Jumlah(Rp)</label>
															<input disabled value="" type="text" class="form-control" name="jumlah_dpa" placeholder="...." required>
													   </div>

													   <div class="col-md-6 col-sm-6">
															<label for="tanggal_dpa">Tanggal Input DPA</label>
															<input disabled value="" type="date" class="form-control" name="tanggal_dpa" placeholder="...." required>
														</div>
								  
								  						<div class="col-md-6 col-sm-6">
															<label for="tahun_dpa">Tahun Anggaran</label>
															<input disabled value="" type="year" class="form-control" name="tahun_dpa" placeholder="...." required>
														</div>

													 
											</form>
										</div>
													<div class="col-md-12 col-sm-12">
															<br>
															
														   <a href="/aksesadmin/halaman2/opendpa/index.php" >BUKA INPUT</a>
													   </div>
	  

</div>
</div>    
</div>
    