<br><br><br>
<!DOCTYPE>
<html>
<head>
  <title>PPTK-RSUD</title>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<body>
<div class="container">
  <div class="panel panel-default">
    <div class="panel-heading">Input Pejabat Pelaksana Teknis Kegiatan&nbsp;<a> Input PPTK Minimal 2 !!!</a></div>
	  
    <div class="panel-body">
    
       <form action="/aksesadmin/halaman9/halaman3/aksipptk.php" method="POST">
	        <div class="input-group control-group after-add-more">
	          <input type="text" name="addmore[]" class="form-control" placeholder="nama pptk...">
	          <div class="input-group-btn"> 
	            <button class="btn btn-danger"><i class="glyphicon glyphicon-plus"></i> Tambah PPTK</button>
	          </div>
	        </div>
	        <div class="control-group text-right">
	            <br>
	            <button class="btn btn-success" type="submit">Input</button>
				<br>
				<a href="/aksesadmin/keurs.php?page=pptk">Batal</a>
	        </div>
 		</form>

        <!-- Copy Fields -->
        <div class="copy hide">
          <div class="control-group input-group" style="margin-top:10px">
            <input required type="text" name="addmore[]" class="form-control" placeholder="nama pptk...">
            <div class="input-group-btn"> 
              <button class="btn btn-danger remove" type="button"><i class="glyphicon glyphicon-remove"></i> Hapus</button>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
      $(".add-more").click(function(){ 
          var html = $(".copy").html();
          $(".after-add-more").after(html);
      });
      $("body").on("click",".remove",function(){ 
          $(this).parents(".control-group").remove();
      });
    });
</script>
</body>
</html>