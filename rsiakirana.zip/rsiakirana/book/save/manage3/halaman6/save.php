
	

<?php
	require_once 'conn.php';

	if(ISSET($_POST['save'])){
		$jenis=$_POST['jenis'];
			
		mysqli_query($conn, "INSERT INTO `arsip` VALUES('', '$jenis')") or die(mysqli_error());
		
		
		echo "<script>alert('Arsip Berhasil di Buat');window.location='/aksesadmin/manage1/adminrs.php?page=arsip'</script>";
		
	}
?>

		